# Studio Lane BFF

**Backend for Frontend (BFF)** for Temenos Conversational Studio — the **only backend** for Studio Web/Admin UI.

Implements [ADR-005: Studio Lane BFF Responsibilities & Boundaries](./adr/ADR-005%20Studio%20Lane%20BFF%20Responsibilities%20&%20Boundar%202c22d8a35aea8054b4aedd3ec920c112.md).

## Overview

Studio BFF:
- Authenticates via **Temenos SSO** (Azure AD / Entra)
- Resolves **tenant** + **user**, enforces **Owner/Editor** roles
- Delegates **generative work** to Gen Public APIs (ADR-021)
- Delegates **build/preview/release** to Delivery services (ADR-014/15/16)
- Delegates **Fabric/Audit** to Control Plane
- **Never** calls LLMs directly or mutates working copy

Business users see **task planner + progress**, not raw code streams.

## Tech Stack

- **Framework**: FastAPI
- **Language**: Python 3.12+
- **ASGI Server**: uvicorn
- **Dependency Management**: Poetry
- **Database**: PostgreSQL (via asyncpg) with SQLAlchemy + Alembic
- **HTTP Client**: httpx (async)
- **Observability**: OpenTelemetry
- **Linting**: Ruff
- **Type Checking**: mypy
- **Testing**: pytest + pytest-cov + pytest-asyncio
- **Container**: Docker (AKS-ready)

## Architecture

```
studio-lane-bff/
├── services/
│   ├── studio_gateway_api/         # Main entry point, mounts all routers
│   ├── auth_rbac_service/          # SSO validation, tenant/user resolution, RBAC
│   ├── workspace_service/          # Workspaces, projects, folders, favorites, shares
│   ├── designsystem_service/       # Design systems CRUD
│   ├── conversation_service/       # Chat sessions, tasks, gen-runs (consolidated prompt-to-code/chat)
│   ├── preview_proxy_service/      # Preview orchestration (start/get/revert)
│   ├── build_proxy_service/        # Build orchestration (start/get)
│   ├── release_proxy_service/      # Release orchestration (start/get)
│   ├── fabric_proxy_service/       # Fabric API catalog (list/details/config)
│   └── audit_proxy_service/        # Audit event relay (write/ping)
├── shared/
│   ├── config.py                   # Pydantic Settings with env/Azure config
│   ├── context.py                  # RequestContext (tenantId, userId, roles)
│   ├── auth.py                     # JWT validation, get_request_context dependency
│   ├── rbac.py                     # require_role, require_all_roles helpers
│   ├── errors.py                   # Error types + normalization
│   ├── observability.py            # OTel tracing, structured logging
│   ├── clients_gen.py              # Gen Public APIs client
│   ├── clients_delivery.py         # Delivery services client
│   ├── clients_control.py          # Fabric + Audit clients
│   ├── models.py                   # Common Pydantic models
│   ├── db_models.py                # SQLAlchemy models
│   └── database.py                 # Async engine, session factory
├── alembic/                        # Database migrations
├── tests/                          # Test suite
├── pyproject.toml
└── README.md
```

## Services

| Service | Prefix | Purpose |
|---------|--------|---------|
| **studio_gateway_api** | `/` | Main entry point, mounts all routers, global error handling |
| **auth_rbac_service** | `/api/studio/auth` | SSO validation, `/whoami`, profile management |
| **workspace_service** | `/api/studio/workspaces` | Workspaces, projects, folders, favorites, shares |
| **designsystem_service** | `/api/studio/design-systems` | Design system CRUD with version locks |
| **conversation_service** | `/api/studio/conversations` | Sessions, messages, tasks, gen-runs |
| **preview_proxy_service** | `/api/studio/preview` | Start/get/revert preview (proxies to Delivery) |
| **build_proxy_service** | `/api/studio/builds` | Start/get builds (proxies to Delivery) |
| **release_proxy_service** | `/api/studio/releases` | Start/get releases (proxies to Delivery) |
| **fabric_proxy_service** | `/api/studio/fabric` | Fabric API catalog (proxies to Control Plane) |
| **audit_proxy_service** | `/api/studio/audit` | Audit event relay (proxies to Control Plane) |

All endpoints enforce **RBAC** (Owner/Editor/Viewer) and use `RequestContext` dependency.

## Local Development

### Prerequisites

- Python 3.12+
- Poetry 1.7+
- PostgreSQL 15+ (or use SQLite for testing)

### Setup

```bash
# Install dependencies
poetry install

# Activate virtual environment
poetry shell

# Setup database
export DATABASE_URL="postgresql+asyncpg://user:pass@localhost:5432/studio_lane"

# Run Alembic migrations
alembic upgrade head

# Run Studio Gateway API
cd services/studio_gateway_api
uvicorn main:app --reload --port 8080
```

### Environment Variables

Create a `.env` file in the root:

```env
# Database
DATABASE_URL=postgresql+asyncpg://user:pass@localhost:5432/studio_lane

# Downstream services
GEN_BASE_URL=http://localhost:8000
DELIVERY_BASE_URL=http://localhost:8001
FABRIC_BASE_URL=http://localhost:8002
AUDIT_BASE_URL=http://localhost:8003

# Azure AD / Temenos SSO
AZURE_AD_CLIENT_ID=your-client-id
AZURE_AD_AUTHORITY=https://login.microsoftonline.com/your-tenant
SSO_AUDIENCE=api://studio-lane-bff
SSO_JWKS_URL=https://login.microsoftonline.com/your-tenant/discovery/v2.0/keys

# Observability (optional)
OTEL_EXPORTER_OTLP_ENDPOINT=http://otel-collector:4317
LOG_LEVEL=INFO

# CORS
CORS_ORIGINS=http://localhost:3000,http://localhost:3001
```

### Pre-Commit Hooks

Install pre-commit hooks to run QA checks before each commit:

```bash
# Install pre-commit
poetry add --group dev pre-commit

# Install git hooks
pre-commit install

# Run manually on all files
pre-commit run --all-files
```

The hooks will automatically run:
- **ruff** (lint + format)
- **mypy** (type check on changed files)
- **pytest** (fast unit tests only, excluding tests marked with `@pytest.mark.slow`)

Slow tests (integration, e2e) run only in CI.

### Pytest Markers

Mark tests to control when they run:

```python
import pytest

# Fast unit test (runs in pre-commit)
@pytest.mark.unit
def test_parse_config():
    assert parse_config({}) is not None

# Slow integration test (CI only)
@pytest.mark.slow
async def test_full_database_migration():
    # Takes 30+ seconds
    await run_full_migration()
    assert migration_successful()
```

Run specific test types:
```bash
# Fast tests only (pre-commit default)
pytest -m "not slow"

# All tests (CI)
pytest

# Only slow tests
pytest -m slow
```

### Commands

```bash
# Lint
poetry run ruff check .

# Format
poetry run ruff format .

# Type check
poetry run mypy services shared

# Run tests
poetry run pytest

# Run tests with coverage
poetry run pytest --cov

# Generate Alembic migration
alembic revision --autogenerate -m "description"

# Apply migrations
alembic upgrade head

# Rollback migration
alembic downgrade -1
```

## API Documentation

Once running, access:

- **Gateway API**: http://localhost:8080
- **OpenAPI Docs**: http://localhost:8080/docs
- **ReDoc**: http://localhost:8080/redoc
- **Health Check**: http://localhost:8080/health

### Example: Create Workspace

```bash
curl -X POST http://localhost:8080/api/studio/workspaces/workspaces \
  -H "Authorization: Bearer YOUR_JWT_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "name": "My Workspace",
    "description": "A new workspace"
  }'
```

## Docker

### Build Gateway Image

```bash
docker build -t studio-gateway-api -f services/studio_gateway_api/Dockerfile .
```

### Run Gateway Container

```bash
docker run -p 8080:8080 \
  -e DATABASE_URL=postgresql+asyncpg://user:pass@host:5432/studio_lane \
  -e GEN_BASE_URL=http://gen-api:8000 \
  studio-gateway-api
```

### Docker Compose (Example)

```yaml
version: '3.8'
services:
  postgres:
    image: postgres:15
    environment:
      POSTGRES_USER: studio
      POSTGRES_PASSWORD: studio
      POSTGRES_DB: studio_lane
    ports:
      - "5432:5432"
  
  studio-gateway:
    build:
      context: .
      dockerfile: services/studio_gateway_api/Dockerfile
    ports:
      - "8080:8080"
    environment:
      DATABASE_URL: postgresql+asyncpg://studio:studio@postgres:5432/studio_lane
      GEN_BASE_URL: http://gen-api:8000
      DELIVERY_BASE_URL: http://delivery-api:8001
    depends_on:
      - postgres
```

## Database Migrations

Alembic manages schema migrations:

```bash
# Create new migration
alembic revision --autogenerate -m "add user_roles table"

# Apply migrations
alembic upgrade head

# Rollback one migration
alembic downgrade -1

# Show current revision
alembic current

# Show migration history
alembic history
```

## Testing

```bash
# Run all tests
poetry run pytest

# Run with coverage
poetry run pytest --cov

# Run specific test file
poetry run pytest tests/test_context.py

# Run with verbose output
poetry run pytest -v

# Run and show print statements
poetry run pytest -s
```

Test files:
- `tests/conftest.py` — Fixtures (mock DB, RequestContext, test client)
- `tests/test_context.py` — RequestContext and auth tests
- `tests/test_errors.py` — Error normalization tests
- `tests/test_gateway_api.py` — Gateway API tests
- `tests/test_workspace_service.py` — Workspace service tests

## CI/CD

Azure Pipelines runs:
- Ruff linting
- mypy type checking
- pytest with coverage
- Build Docker images
- Push to Azure Container Registry
- Deploy to dev AKS (via Terraform/Helm)

## Deployment

### Azure Kubernetes Service (AKS)

1. Build and push Docker image:
   ```bash
   docker build -t studiolane.azurecr.io/studio-gateway-api:latest \
     -f services/studio_gateway_api/Dockerfile .
   docker push studiolane.azurecr.io/studio-gateway-api:latest
   ```

2. Deploy via Helm or kubectl:
   ```bash
   kubectl apply -f k8s/studio-gateway-deployment.yaml
   ```

3. Set environment variables via ConfigMap and Secrets.

## Security

- **Authentication**: Temenos SSO (Azure AD / Entra) with JWT validation
- **Authorization**: RBAC (Owner/Editor/Viewer roles)
- **Secrets**: Azure Key Vault integration via `shared/config.py`
- **HTTPS**: Enforced in production via Azure Application Gateway

## Observability

- **Tracing**: OpenTelemetry (OTel) spans for all requests
- **Logging**: Structured JSON logs with tenantId/userId/correlationId
- **Metrics**: Custom metrics for downstream latency (Gen/Delivery/Control)

## Owners

- **Principal Architect**: Gautam V. (@vanani.gautamkumar)
- **ADR**: [ADR-005](./adr/ADR-005%20Studio%20Lane%20BFF%20Responsibilities%20&%20Boundar%202c22d8a35aea8054b4aedd3ec920c112.md)

## Branch Strategy

- `feature/*` → `dev` → `stg` → `main`
- All merges require PRs with approvals
- Protected branches: `dev`, `stg`, `main`
- Required checks: lint, type-check, test, sonarqube, fortify-sast

## License

Proprietary — Temenos AG
