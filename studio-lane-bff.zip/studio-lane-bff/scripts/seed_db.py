"""Cosmos DB seeding script for development and testing."""

import asyncio
from datetime import datetime, timezone

from shared.config import get_settings
from shared.cosmosdb import init_cosmosdb
from shared.document_models import (
    folder_to_document,
    project_to_document,
    user_profile_to_document,
    workspace_to_document,
)
from shared.models import (
    Folder,
    Project,
    ProjectStatus,
    UserProfile,
    Workspace,
)


async def seed_cosmosdb():
    """Seed Cosmos DB with sample data."""
    settings = get_settings()

    if not settings.cosmos_connection_string:
        print("ERROR: COSMOS_CONNECTION_STRING not set")
        return

    # Initialize Cosmos DB client
    cosmos_client = init_cosmosdb(
        connection_string=settings.cosmos_connection_string,
        database_name=settings.cosmos_database_name,
        container_config=settings.cosmos_container_config,
        partition_key_path=settings.cosmos_partition_key_path,
    )
    await cosmos_client.connect()

    try:
        # Sample data
        tenant_id = "tenant-001"
        user_id = "user-001"
        workspace_id = "workspace-001"
        folder_id = "folder-001"
        project_id = "project-001"

        # Create user profile
        user_profile = UserProfile(
            id=user_id,
            email="dev@temenos.com",
            full_name="Development User",
            created_at=datetime.now(timezone.utc),
            updated_at=datetime.now(timezone.utc),
        )
        user_doc = user_profile_to_document(user_profile, tenant_id)
        try:
            await cosmos_client.create_item(
                item=user_doc,
                container_name="users",
            )
            print(f"Created user profile: {user_id}")
        except Exception as e:
            print(f"User profile may already exist: {e}")

        # Create workspace
        workspace = Workspace(
            id=workspace_id,
            name="Development Workspace",
            description="Sample workspace for development",
            tenant_id=tenant_id,
            owner_id=user_id,
            created_at=datetime.now(timezone.utc),
            updated_at=datetime.now(timezone.utc),
        )
        workspace_doc = workspace_to_document(workspace, tenant_id)
        try:
            await cosmos_client.create_item(
                item=workspace_doc,
                container_name="workspaces",
            )
            print(f"Created workspace: {workspace_id}")
        except Exception as e:
            print(f"Workspace may already exist: {e}")

        # Create folder
        folder = Folder(
            id=folder_id,
            name="Sample Folder",
            workspace_id=workspace_id,
            user_id=user_id,
            tenant_id=tenant_id,
            created_at=datetime.now(timezone.utc),
            updated_at=datetime.now(timezone.utc),
        )
        folder_doc = folder_to_document(folder, tenant_id)
        try:
            await cosmos_client.create_item(
                item=folder_doc,
                container_name="workspaces",
            )
            print(f"Created folder: {folder_id}")
        except Exception as e:
            print(f"Folder may already exist: {e}")

        # Create project
        project = Project(
            id=project_id,
            name="Sample Project",
            description="A sample project for development",
            status=ProjectStatus.DRAFT,
            workspace_id=workspace_id,
            folder_id=folder_id,
            tenant_id=tenant_id,
            user_id=user_id,
            created_at=datetime.now(timezone.utc),
            updated_at=datetime.now(timezone.utc),
        )
        project_doc = project_to_document(project, tenant_id)
        try:
            await cosmos_client.create_item(
                item=project_doc,
                container_name="projects",
            )
            print(f"Created project: {project_id}")
        except Exception as e:
            print(f"Project may already exist: {e}")

        print("\nCosmos DB seeding completed!")

    finally:
        await cosmos_client.close()


if __name__ == "__main__":
    asyncio.run(seed_cosmosdb())

