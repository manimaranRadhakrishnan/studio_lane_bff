# ADR-005: Studio Lane BFF Responsibilities & Boundaries

**Status:** Accepted

**Owner:** Gautam (Principal Architect)

**Version:** 3.1

## 1. Problem

Conversational Studio is primarily used by **business users**.

We need a **server-side boundary** that:

- Hides multi-agent complexity, LLMs, builds, and storage
- Exposes **simple, safe APIs** for prompt→code, previews, and task progress
- Enforces tenant isolation and roles (Owner/Editor)

…without turning the web client into an unsafe orchestration layer.

## 2. Decision (What BFF Is)

We create a **Studio BFF monorepo (`studio-lane-bff`)** in Python/FastAPI that:

- Is the **only backend** the Studio Web/Admin UI talks to
- Authenticates via Temenos SSO, resolves tenant + user, then enforces RBAC
- Delegates:
    - **Generative work** to Gen Public APIs (ADR-021)
    - **Build/preview/release** to Delivery services (ADR-014/15/16)
    - **Policy/audit/Fabric** to Control Plane

Business users see **task planner + progress**, not raw code streams.

## 3. Responsibilities (MVP)

Studio BFF **must**:

1. **Auth & Tenant Resolution**
    - Validate Temenos SSO token
    - Resolve `tenantId`, `userId` from claims
    - Attach to each request as mandatory context
2. **Role Enforcement (Owner/Editor)**
    - Maintain Workspace/Project roles in app DB (Owner/Editor)
    - Optionally seed from Azure AD groups (e.g., `Temenos-Studio-Owner`, `Temenos-Studio-Editor`)
    - For client SSO later: map external groups → same roles
    - Enforce per-endpoint permissions in reusable middleware
3. **Session & Conversation Layer**
    - Manage `sessionId`, recent messages, and task IDs
    - Call **Gen Public APIs** for:
        - prompt→code
        - inline edits
        - context-aware chat
        - UI-builder prompts
    - Never assemble ContextGraph or call LLMs directly.
4. **Task Planner & Progress**
    - Expose **read-only task views**:
        - task list, status, agent, timestamps
    - Poll or receive progress events from Gen Lane, then forward to FE via:
        - SSE/WebSocket or thin polling endpoint
    - No code streaming; only status + structured results.
5. **Workspace / Project / Design System**
    - CRUD for workspaces, projects, design systems
    - Link to Git via Git connector
    - Expose file tree/read metadata via Code Index services
    - All code mutations go via Gen Lane.
6. **Preview / Build / Release Orchestration (Proxy)**
    - Start preview, query status, fetch preview URLs
    - Trigger builds & list artifacts
    - Request releases/promotions
    - For **preview revert**:
        - Expose endpoint to:
            - revert preview env to previous artifact
            - or pin to a previous WC / gen-run ID (Delivery + Gen handle data; BFF just orchestrates).
7. **Error Normalization & Observability**
    - Normalize errors (LLM, patch, build, policy) into stable API shapes
    - Emit OTel traces, structured logs, and metrics per endpoint

Anything outside this list is out of scope for the BFF.

## 4. Non-Responsibilities

Studio BFF **must not**:

- Call LLMs directly
- Patch or write Working Copy
- Build artifacts or manage runners
- Assemble retrieval context / ContextGraph
- Evaluate policies locally (only call Policy/Audit services)

It is **gateway + orchestration**, not a business-logic dumping ground.

## 5. Microservices in `studio-lane-bff` Monorepo

![highlevel arch-adr-005.drawio.png](ADR-005%20Studio%20Lane%20BFF%20Responsibilities%20&%20Boundar/highlevel_arch-adr-005.drawio.png)

These are **logical services**; they can share infra/runtime but are distinct domains.

| Microservice | Domain | Purpose |
| --- | --- | --- |
| `studio-gateway-api` | Boundary | Single entrypoint for Studio Web/Admin; routing + shared middleware |
| `auth-rbac-service` | Cross-cutting | Temenos SSO validation, tenant & user resolution, Owner/Editor checks |
| `workspace-service` | Studio | Workspaces, projects, role assignment, Git linkage metadata |
| `designsystem-service` | Studio | Design system CRUD, version locks, project linkage |
| `conversation-service` | Studio <> Gen | Sessions, chat history pointers, task planner & progress endpoints |
| `preview-proxy-service` | Studio <> Delivery | Start/inspect previews, revert preview env to previous artifact |
| `build-proxy-service` | Studio <> Delivery | Start builds, query build status/artifacts |
| `release-proxy-service` | Studio <> Delivery | Trigger release creation/promote/export flows |
| `fabric-proxy-service` | Studio <> Control | Fabric API catalog, manual mapping, config connection from Studio |
| `audit-proxy-service` | Studio <> Control | Write-only relay of important user actions to audit ledger |

**Proxies:**

These can be **thin app-layer modules** rather than separate deployables.

Infra (API Gateway / Ingress) routes traffic into `studio-gateway-api`; once inside, **proxies enforce auth/validation, emit traces, and then call downstream Delivery/Gen/Control services.**

## 6. Auth & Permission Model

- **Authentication:**
    - Temenos SSO (Azure AD / Entra) is the source of identity.
    - BFF validates JWT and pulls `sub`, `tenant`, `groups` claims.
- **Authorization / Roles:**
    - Studio maintains **WorkspaceRole** + **ProjectRole** tables (Owner/Editor).
    - Default mapping:
        - AAD group → default role for workspace/project
    - When client SSO is added:
        - External groups mapped to same roles through config, no code change.
- **Enforcement:**
    - Common RBAC middleware:
        - `requireRole("Owner")`
        - `requireRole("Owner|Editor")`
    - Applied to project/workspace routes and to privileged actions (e.g., release, DS changes).

## 7. Preview Revert Handling

From BFF perspective:

- Provide `/preview/revert` API:
    - Input: `projectId`, `envId`, `targetArtifactId` *or* `targetBuildId`
- BFF:
    - Validates user & role
    - Calls Delivery:
        - to **re-point env** to target artifact
        - or trigger **WC rollback** via Gen/Delivery (depending on ADR-017/Delivery strategy)
- Studio UI shows “Revert preview to build X” using this API.
- BFF does **not** manipulate artifacts directly.

## 8. Decision Log

| Date | Decision | Owner |
| --- | --- | --- |
| Nov 27 2025 | Studio BFF monorepo approved as sole backend for Studio Web/Admin | GV |
|  | BFF to remain LLM-free; all Gen via Public Gen APIs (ADR-021) |  |
|  | Owner/Editor roles managed in app DB; seeded from SSO groups when present |  |
| Dec 3 2025 | Preview revert supported via Delivery APIs; BFF only orchestrates | GV |
|  | Proxies implemented as app-layer modules behind shared gateway & middlewares |  |