"""Tests for event ingestion gen run handlers (completed: suggestedProjectName/suggestedProjectType)."""

from __future__ import annotations

from datetime import datetime, timezone
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from services.event_ingestion_service.handlers import gen_run_handler
from services.event_ingestion_service.models import GenRunCompletedEvent
from shared.models import GenRunStatus, JobProjection, Project, ProjectStatus


@pytest.fixture
def completed_event():
    return GenRunCompletedEvent(
        eventId="evt-1",
        genRunId="gen-1",
        tenantId="tenant-1",
        projectId="proj-1",
        status="succeeded",
        patchSetId="patch-1",
        changeSummary="Done",
        followups=["Add feature"],
        suggestedProjectName="Login App",
        suggestedProjectType="web",
    )


@pytest.fixture
def existing_projection():
    return JobProjection(
        id="gen-1",
        tenant_id="tenant-1",
        project_id="proj-1",
        gen_run_id="gen-1",
        session_id="sess-1",
        status=GenRunStatus.RUNNING,
        progress_percent=50,
        current_task_id="task-1",
        tasks_completed=0,
        tasks_total=0,
        patch_set_id=None,
        error_message=None,
        created_at=datetime.now(timezone.utc),
        updated_at=datetime.now(timezone.utc),
        completed_at=None,
    )


@pytest.fixture
def existing_project():
    return Project(
        id="proj-1",
        name="Untitled",
        description=None,
        type=None,
        status=ProjectStatus.DRAFT,
        workspace_id="tenant-1",
        folder_id=None,
        tenant_id="tenant-1",
        user_id="user-1",
        created_at=datetime.now(timezone.utc),
        updated_at=datetime.now(timezone.utc),
        updated_by=None,
    )


@pytest.mark.asyncio
async def test_ingest_completed_updates_project_name_and_type_when_suggested(
    completed_event, existing_projection, existing_project
):
    """When gen.run.completed has suggestedProjectName and suggestedProjectType, Project is updated."""
    cosmos = AsyncMock()
    job_repo = AsyncMock()
    job_repo.get = AsyncMock(return_value=existing_projection)
    job_repo.update = AsyncMock()
    project_repo = AsyncMock()
    project_repo.get = AsyncMock(return_value=existing_project)
    project_repo.update = AsyncMock()

    with patch(
        "services.event_ingestion_service.handlers.gen_run_handler.check_idempotency",
        return_value=False,
    ), patch(
        "services.event_ingestion_service.handlers.gen_run_handler.get_job_repo",
        return_value=job_repo,
    ), patch(
        "services.event_ingestion_service.handlers.gen_run_handler.get_project_repo",
        return_value=project_repo,
    ), patch(
        "services.event_ingestion_service.handlers.gen_run_handler.get_chat_message_repo",
        return_value=AsyncMock(list=AsyncMock(return_value=[]), create=AsyncMock()),
    ), patch(
        "shared.ws_manager.get_ws_manager",
        return_value=MagicMock(broadcast=AsyncMock()),
    ):
        result = await gen_run_handler.ingest_completed(completed_event, cosmos)

    assert result == {"status": "processed"}
    project_repo.get.assert_called_once_with("proj-1")
    project_repo.update.assert_called_once()
    updated = project_repo.update.call_args[0][0]
    assert updated.name == "Login App"
    assert updated.type == "web"


@pytest.mark.asyncio
async def test_ingest_completed_omits_project_update_when_no_suggested():
    """When payload omits suggestedProjectName/suggestedProjectType, Project is not updated."""
    event = GenRunCompletedEvent(
        eventId="evt-2",
        genRunId="gen-2",
        tenantId="tenant-1",
        projectId="proj-1",
        status="succeeded",
        suggestedProjectName=None,
        suggestedProjectType=None,
    )
    cosmos = AsyncMock()
    job_repo = AsyncMock()
    job_repo.get = AsyncMock(return_value=None)
    job_repo.create = AsyncMock()
    project_repo = AsyncMock()

    with patch(
        "services.event_ingestion_service.handlers.gen_run_handler.check_idempotency",
        return_value=False,
    ), patch(
        "services.event_ingestion_service.handlers.gen_run_handler.get_job_repo",
        return_value=job_repo,
    ), patch(
        "services.event_ingestion_service.handlers.gen_run_handler.get_project_repo",
        return_value=project_repo,
    ), patch(
        "services.event_ingestion_service.handlers.gen_run_handler.get_chat_message_repo",
        return_value=AsyncMock(list=AsyncMock(return_value=[])),
    ):
        await gen_run_handler.ingest_completed(event, cosmos)

    project_repo.get.assert_not_called()
    project_repo.update.assert_not_called()
