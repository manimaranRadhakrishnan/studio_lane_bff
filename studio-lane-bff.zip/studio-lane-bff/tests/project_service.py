import uuid
from datetime import datetime, timezone
from typing import Generic, TypeVar

# Mock models for demonstration
class CreateProjectRequest:
    """Request model for creating a project."""

    def __init__(
        self,
        name: str,
        description: str,
        workspace_id: str,
        folder_id: str | None = None,
    ):
        self.name = name
        self.description = description
        self.workspace_id = workspace_id
        self.folder_id = folder_id


class RequestContext:
    """Request context containing tenant and user information."""

    def __init__(self, tenant_id: str, user_id: str):
        self.tenant_id = tenant_id
        self.user_id = user_id


class ProjectStatus:
    """Project status enum."""

    DRAFT = "draft"
    ACTIVE = "active"
    ARCHIVED = "archived"


class Project:
    """Project model."""

    def __init__(
        self,
        id: str,
        name: str,
        description: str,
        workspace_id: str,
        folder_id: str | None,
        status: str,
        tenant_id: str,
        user_id: str,
        created_at: datetime,
        updated_at: datetime,
        updated_by: str,
    ):
        self.id = id
        self.name = name
        self.description = description
        self.workspace_id = workspace_id
        self.folder_id = folder_id
        self.status = status
        self.tenant_id = tenant_id
        self.user_id = user_id
        self.created_at = created_at
        self.updated_at = updated_at
        self.updated_by = updated_by


T = TypeVar("T")


class BaseRepository(Generic[T]):
    """Base repository interface."""

    async def create(self, entity: T) -> T:
        """Create an entity."""
        raise NotImplementedError


class ProjectService:
    """Service for managing projects."""

    @staticmethod
    async def create_project(
        request: CreateProjectRequest,
        ctx: RequestContext,
        repo: BaseRepository[Project],
    ) -> Project:
        """Create a new project."""
        project = Project(
            id=str(uuid.uuid4()),
            name=request.name,
            description=request.description,
            workspace_id=request.workspace_id,
            folder_id=request.folder_id,
            status=ProjectStatus.DRAFT,
            tenant_id=ctx.tenant_id,
            user_id=ctx.user_id,
            created_at=datetime.now(timezone.utc),
            updated_at=datetime.now(timezone.utc),
            updated_by=ctx.user_id,  # API-owned field
        )
        return await repo.create(project)