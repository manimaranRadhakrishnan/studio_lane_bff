"""Tests for RequestContext and auth."""


from shared.auth import extract_roles_from_claims
from shared.context import RequestContext


def test_request_context_has_role():
    """Test RequestContext.has_role method."""
    ctx = RequestContext(
        tenant_id="tenant-1",
        user_id="user-1",
        roles={"Owner", "Editor"},
    )

    assert ctx.has_role("Owner")
    assert ctx.has_role("Editor")
    assert ctx.has_role("Owner", "Editor")
    assert not ctx.has_role("Viewer")


def test_request_context_has_all_roles():
    """Test RequestContext.has_all_roles method."""
    ctx = RequestContext(
        tenant_id="tenant-1",
        user_id="user-1",
        roles={"Owner", "Editor"},
    )

    assert ctx.has_all_roles("Owner")
    assert ctx.has_all_roles("Owner", "Editor")
    assert not ctx.has_all_roles("Owner", "Editor", "Viewer")


def test_extract_roles_from_claims_with_groups():
    """Test extracting roles from JWT claims with groups."""
    claims = {
        "groups": ["Temenos-Studio-Owner", "other-group"],
    }

    roles = extract_roles_from_claims(claims)
    assert "Owner" in roles


def test_extract_roles_from_claims_with_custom_roles():
    """Test extracting roles from JWT claims with custom roles."""
    claims = {
        "roles": ["Owner", "Editor"],
    }

    roles = extract_roles_from_claims(claims)
    assert "Owner" in roles
    assert "Editor" in roles


def test_extract_roles_empty_claims():
    """Test extracting roles from empty claims."""
    claims = {}
    roles = extract_roles_from_claims(claims)
    assert len(roles) == 0


