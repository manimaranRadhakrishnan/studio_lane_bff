from __future__ import annotations

import importlib
import inspect
import sys
import types
from typing import Any, Generic, TypeVar, cast

import pytest
from pydantic import BaseModel  # Pydantic v2
from fastapi import FastAPI
from fastapi.testclient import TestClient

pytestmark = pytest.mark.asyncio

T = TypeVar("T")


@pytest.fixture(scope="module")
def routes() -> Any:
    """
    Prepare lightweight stub modules to satisfy all imports used by
    services.project_git_link_service.routes.links, then import that module.

    This avoids ImportError from real modules and lets FastAPI accept response_model
    because we stub Pydantic BaseModel classes.
    """
    # ----- Build 'shared' stubs -----
    shared = types.ModuleType("shared")

    class RequestContext:
        pass

    def get_cosmosdb() -> None:
        return None

    def get_request_context() -> RequestContext:
        return RequestContext()

    def require_role(*_roles: str):
        # Return a dependency callable and attach the roles for assertability in tests
        def _dep() -> RequestContext:
            return RequestContext()

        setattr(_dep, "__roles__", tuple(_roles))
        return _dep

    shared.RequestContext = RequestContext
    shared.get_cosmosdb = get_cosmosdb
    shared.get_request_context = get_request_context
    shared.require_role = require_role

    shared_models = types.ModuleType("shared.models")

    class Project:
        pass

    class ProjectGitLink:
        pass

    shared_models.Project = Project
    shared_models.ProjectGitLink = ProjectGitLink

    shared_repository = types.ModuleType("shared.repository")

    class BaseRepository(Generic[T]):
        pass

    shared_repository.BaseRepository = BaseRepository

    shared_cosmosdb = types.ModuleType("shared.cosmosdb")

    class CosmosDBClient:
        pass

    shared_cosmosdb.CosmosDBClient = CosmosDBClient

    # Inject/override shared modules so imports resolve to our stubs
    sys.modules["shared"] = shared
    sys.modules["shared.models"] = shared_models
    sys.modules["shared.repository"] = shared_repository
    sys.modules["shared.cosmosdb"] = shared_cosmosdb

    # ----- Build service-local stubs that the routes import -----
    svc_models = types.ModuleType("services.project_git_link_service.models")

    # Pydantic v2 models so FastAPI accepts them as response_model / request types
    class CreateProjectGitLinkRequest(BaseModel):
        pass

    class ProjectGitLinkResponse(BaseModel):
        pass

    class SyncGitToWcRequest(BaseModel):
        pass

    class SyncGitToWcResponse(BaseModel):
        pass

    class UpdateProjectGitLinkRequest(BaseModel):
        pass

    svc_models.CreateProjectGitLinkRequest = CreateProjectGitLinkRequest
    svc_models.ProjectGitLinkResponse = ProjectGitLinkResponse
    svc_models.SyncGitToWcRequest = SyncGitToWcRequest
    svc_models.SyncGitToWcResponse = SyncGitToWcResponse
    svc_models.UpdateProjectGitLinkRequest = UpdateProjectGitLinkRequest

    sys.modules["services.project_git_link_service.models"] = svc_models

    svc_deps = types.ModuleType("services.project_git_link_service.dependencies")

    def get_project_git_link_repo() -> None:
        return None

    def get_project_repo() -> None:
        return None

    svc_deps.get_project_git_link_repo = get_project_git_link_repo
    svc_deps.get_project_repo = get_project_repo

    sys.modules["services.project_git_link_service.dependencies"] = svc_deps

    # Handlers package + submodule stub (so routes can import "from ..handlers import link_handler")
    handlers_pkg = types.ModuleType("services.project_git_link_service.handlers")
    link_handler_mod = types.ModuleType(
        "services.project_git_link_service.handlers.link_handler"
    )

    # Provide placeholder async functions—we will monkeypatch real fakes in tests
    async def _noop(*_args: Any, **_kwargs: Any) -> Any:
        return None

    link_handler_mod.create_or_update_project_git_link = _noop
    link_handler_mod.get_project_git_link = _noop
    link_handler_mod.update_project_git_link = _noop
    link_handler_mod.delete_project_git_link = _noop
    link_handler_mod.sync_git_to_wc = _noop

    # Register the package and the submodule
    sys.modules["services.project_git_link_service.handlers"] = handlers_pkg
    sys.modules["services.project_git_link_service.handlers.link_handler"] = link_handler_mod
    handlers_pkg.link_handler = link_handler_mod  # type: ignore[attr-defined]

    # Now import the REAL routes file with stubs in place
    routes_module = importlib.import_module(
        "services.project_git_link_service.routes.links"
    )
    return routes_module


# ------------------------
# Direct-call helper dummies
# ------------------------
def _dummy_ctx(routes: Any) -> Any:
    return cast(routes.RequestContext, object())


def _dummy_repo_git_link(routes: Any) -> Any:
    return cast(routes.BaseRepository[routes.ProjectGitLink], object())


def _dummy_repo_project(routes: Any) -> Any:
    return cast(routes.BaseRepository[routes.Project], object())


def _dummy_req_create(routes: Any) -> Any:
    return cast(routes.CreateProjectGitLinkRequest, object())


def _dummy_req_update(routes: Any) -> Any:
    return cast(routes.UpdateProjectGitLinkRequest, object())


def _dummy_req_sync(routes: Any) -> Any:
    return cast(routes.SyncGitToWcRequest, object())


# ------------------------
# Existing delegation tests (direct calls)
# ------------------------
async def test_create_or_update_calls_handler(
    routes: Any, monkeypatch: pytest.MonkeyPatch
) -> None:
    calls: dict[str, Any] = {}

    async def fake_handler(
        project_id: str,
        request: routes.CreateProjectGitLinkRequest,
        ctx: routes.RequestContext,
        repo: routes.BaseRepository[routes.ProjectGitLink],
        project_repo: routes.BaseRepository[routes.Project],
    ) -> dict[str, Any]:
        calls["project_id"] = project_id
        calls["request"] = request
        calls["ctx"] = ctx
        calls["repo"] = repo
        calls["project_repo"] = project_repo
        return {"ok": True, "action": "create_or_update"}

    monkeypatch.setattr(
        routes.link_handler, "create_or_update_project_git_link", fake_handler
    )

    result = await routes.create_or_update_project_git_link(
        project_id="P123",
        request=_dummy_req_create(routes),
        ctx=_dummy_ctx(routes),
        repo=_dummy_repo_git_link(routes),
        project_repo=_dummy_repo_project(routes),
    )

    assert result == {"ok": True, "action": "create_or_update"}
    assert calls["project_id"] == "P123"
    assert calls["request"] is not None
    assert calls["ctx"] is not None
    assert calls["repo"] is not None
    assert calls["project_repo"] is not None


async def test_get_calls_handler(routes: Any, monkeypatch: pytest.MonkeyPatch) -> None:
    calls: dict[str, Any] = {}

    async def fake_handler(
        project_id: str,
        ctx: routes.RequestContext,
        repo: routes.BaseRepository[routes.ProjectGitLink],
        project_repo: routes.BaseRepository[routes.Project],
    ) -> dict[str, Any]:
        calls["project_id"] = project_id
        calls["ctx"] = ctx
        calls["repo"] = repo
        calls["project_repo"] = project_repo
        return {"ok": True, "action": "get"}

    monkeypatch.setattr(routes.link_handler, "get_project_git_link", fake_handler)

    result = await routes.get_project_git_link(
        project_id="P234",
        ctx=_dummy_ctx(routes),
        repo=_dummy_repo_git_link(routes),
        project_repo=_dummy_repo_project(routes),
    )

    assert result == {"ok": True, "action": "get"}
    assert calls["project_id"] == "P234"


async def test_update_calls_handler(
    routes: Any, monkeypatch: pytest.MonkeyPatch
) -> None:
    calls: dict[str, Any] = {}

    async def fake_handler(
        project_id: str,
        request: routes.UpdateProjectGitLinkRequest,
        ctx: routes.RequestContext,
        repo: routes.BaseRepository[routes.ProjectGitLink],
        project_repo: routes.BaseRepository[routes.Project],
    ) -> dict[str, Any]:
        calls["project_id"] = project_id
        calls["request"] = request
        calls["ctx"] = ctx
        calls["repo"] = repo
        calls["project_repo"] = project_repo
        return {"ok": True, "action": "update"}

    monkeypatch.setattr(routes.link_handler, "update_project_git_link", fake_handler)

    result = await routes.update_project_git_link(
        project_id="P345",
        request=_dummy_req_update(routes),
        ctx=_dummy_ctx(routes),
        repo=_dummy_repo_git_link(routes),
        project_repo=_dummy_repo_project(routes),
    )

    assert result == {"ok": True, "action": "update"}
    assert calls["project_id"] == "P345"


async def test_delete_calls_handler(
    routes: Any, monkeypatch: pytest.MonkeyPatch
) -> None:
    calls: dict[str, Any] = {}

    async def fake_handler(
        project_id: str,
        ctx: routes.RequestContext,
        repo: routes.BaseRepository[routes.ProjectGitLink],
    ) -> None:
        calls["project_id"] = project_id
        calls["ctx"] = ctx
        calls["repo"] = repo
        return None

    monkeypatch.setattr(routes.link_handler, "delete_project_git_link", fake_handler)

    result = await routes.delete_project_git_link(
        project_id="P456",
        ctx=_dummy_ctx(routes),
        repo=_dummy_repo_git_link(routes),
    )

    assert result is None
    assert calls["project_id"] == "P456"


async def test_sync_git_to_wc_calls_handler(
    routes: Any, monkeypatch: pytest.MonkeyPatch
) -> None:
    calls: dict[str, Any] = {}

    async def fake_handler(
        request: routes.SyncGitToWcRequest,
        repo: routes.BaseRepository[routes.ProjectGitLink],
    ) -> dict[str, Any]:
        calls["request"] = request
        calls["repo"] = repo
        return {"ok": True, "action": "sync"}

    monkeypatch.setattr(routes.link_handler, "sync_git_to_wc", fake_handler)

    result = await routes.sync_git_to_wc(
        request=_dummy_req_sync(routes),
        repo=_dummy_repo_git_link(routes),
    )

    assert result == {"ok": True, "action": "sync"}
    assert calls["request"] is not None


# ------------------------
# NEW: Router metadata tests
# ------------------------
def test_router_has_expected_routes(routes: Any) -> None:
    # Collect (path, methods) from APIRouter
    path_methods = {(r.path, tuple(sorted(r.methods))) for r in routes.router.routes}

    assert ("/{project_id}/git-link", ("POST",)) in path_methods
    assert ("/{project_id}/git-link", ("GET",)) in path_methods
    assert ("/{project_id}/git-link", ("PATCH",)) in path_methods
    assert ("/{project_id}/git-link", ("DELETE",)) in path_methods
    assert ("/internal/git-sync:wc", ("POST",)) in path_methods


def test_route_metadata_status_and_models(routes: Any) -> None:
    # Map from endpoint function name to route object
    by_name = {getattr(r.endpoint, "__name__", ""): r for r in routes.router.routes}

    def effective_status(route_obj) -> int:
        # FastAPI leaves status_code=None for default 200 responses
        return 200 if route_obj.status_code is None else route_obj.status_code

    # POST create/update
    r = by_name["create_or_update_project_git_link"]
    assert effective_status(r) == 201
    assert r.response_model is routes.ProjectGitLinkResponse

    # GET
    r = by_name["get_project_git_link"]
    assert effective_status(r) == 200
    assert r.response_model is routes.ProjectGitLinkResponse

    # PATCH
    r = by_name["update_project_git_link"]
    assert effective_status(r) == 200
    assert r.response_model is routes.ProjectGitLinkResponse

    # DELETE
    r = by_name["delete_project_git_link"]
    assert effective_status(r) == 204
    assert r.response_model is None  # no body

    # internal sync
    r = by_name["sync_git_to_wc"]
    assert effective_status(r) == 200
    assert r.response_model is routes.SyncGitToWcResponse


# ------------------------
# NEW: Dependency wiring tests (roles / ctx)
# ------------------------
def test_require_role_attached_on_mutating_routes(routes: Any) -> None:
    # Inspect the default (Depends) for ctx and confirm roles for mutating endpoints
    def roles_for(fn: Any) -> tuple[str, ...] | None:
        sig = inspect.signature(fn)
        param = sig.parameters.get("ctx")
        if not param or not hasattr(param.default, "dependency"):
            return None
        dep = param.default.dependency  # the callable returned by require_role / get_request_context
        return getattr(dep, "__roles__", None)

    assert roles_for(routes.create_or_update_project_git_link) == ("Owner", "Editor")
    assert roles_for(routes.update_project_git_link) == ("Owner", "Editor")
    assert roles_for(routes.delete_project_git_link) == ("Owner", "Editor")
    # GET should not enforce roles (uses get_request_context instead)
    assert roles_for(routes.get_project_git_link) is None


# ------------------------
# NEW: HTTP-level smoke tests (TestClient, no AsyncClient)
# ------------------------
def test_http_post_create_or_update_201(routes: Any, monkeypatch: pytest.MonkeyPatch) -> None:
    async def fake_handler(*_a: Any, **_kw: Any) -> dict[str, Any]:
        return {"ok": True}

    monkeypatch.setattr(
        routes.link_handler, "create_or_update_project_git_link", fake_handler
    )

    app = FastAPI()
    app.include_router(routes.router, prefix="/projects")
    client = TestClient(app)

    resp = client.post("/projects/P1/git-link", json={})
    assert resp.status_code == 201
    # response_model is empty BaseModel -> {} body
    assert resp.json() == {}


def test_http_get_200(routes: Any, monkeypatch: pytest.MonkeyPatch) -> None:
    async def fake_handler(*_a: Any, **_kw: Any) -> dict[str, Any]:
        return {"ok": True}

    monkeypatch.setattr(routes.link_handler, "get_project_git_link", fake_handler)

    app = FastAPI()
    app.include_router(routes.router, prefix="/projects")
    client = TestClient(app)

    resp = client.get("/projects/P2/git-link")
    assert resp.status_code == 200
    assert resp.json() == {}


def test_http_patch_update_200(routes: Any, monkeypatch: pytest.MonkeyPatch) -> None:
    async def fake_handler(*_a: Any, **_kw: Any) -> dict[str, Any]:
        return {"ok": True}

    monkeypatch.setattr(routes.link_handler, "update_project_git_link", fake_handler)

    app = FastAPI()
    app.include_router(routes.router, prefix="/projects")
    client = TestClient(app)

    resp = client.patch("/projects/P3/git-link", json={})
    assert resp.status_code == 200
    assert resp.json() == {}


def test_http_delete_204(routes: Any, monkeypatch: pytest.MonkeyPatch) -> None:
    async def fake_handler(*_a: Any, **_kw: Any) -> None:
        return None

    monkeypatch.setattr(routes.link_handler, "delete_project_git_link", fake_handler)

    app = FastAPI()
    app.include_router(routes.router, prefix="/projects")
    client = TestClient(app)

    resp = client.delete("/projects/P4/git-link")
    assert resp.status_code == 204
    assert resp.content in (b"", b"null")  # FastAPI may send empty body for 204


def test_http_internal_sync_200(routes: Any, monkeypatch: pytest.MonkeyPatch) -> None:
    async def fake_handler(*_a: Any, **_kw: Any) -> dict[str, Any]:
        return {"ok": True}

    monkeypatch.setattr(routes.link_handler, "sync_git_to_wc", fake_handler)

    app = FastAPI()
    app.include_router(routes.router)  # internal route has absolute path
    client = TestClient(app)

    resp = client.post("/internal/git-sync:wc", json={})
    assert resp.status_code == 200
    assert resp.json() == {}