import uuid
from datetime import UTC, datetime
from types import SimpleNamespace

import pytest

# ⚠️ Update this import path based on your project structure.
from services.conversation_service.handlers.message_handler import (
    MessageHandler,
    message_handler,
)
from shared import NotFoundError
from shared.models import ChatMessage, ChatSession


class FakeRepo:
    """Generic fake repository to simulate get() and list()."""

    def __init__(self, get_result=None, list_result=None):
        self._get_result = get_result
        self._list_result = list_result or []
        self.filters_passed = None
        self.get_calls = []

    async def get(self, session_id):
        self.get_calls.append(session_id)
        return self._get_result

    async def list(self, filters=None):
        self.filters_passed = filters
        return self._list_result


def build_chat_message(session, *, role: str, content: str):
    """Create a ChatMessage while conditionally supplying required fields."""
    now = datetime.now(UTC)
    payload = {
        "id": str(uuid.uuid4()),
        "session_id": session.id,
        "role": role,
        "content": content,
        "created_at": now,
    }

    # Pydantic v2: ensure required fields are passed if the model has them
    fields = getattr(ChatMessage, "model_fields", {})
    if "project_id" in fields:
        payload["project_id"] = session.project_id
    if "workspace_id" in fields:
        payload["workspace_id"] = session.workspace_id
    if "updated_at" in fields:
        payload["updated_at"] = now

    return ChatMessage(**payload)


@pytest.mark.asyncio
async def test_list_messages_success():
    """Should list messages when session exists and belongs to the user."""
    handler = MessageHandler()

    session = ChatSession(
        id="session-123",
        project_id="proj",
        workspace_id="ws",
        user_id="user-1",
        title="Chat",
        created_at=datetime.now(UTC),
        updated_at=datetime.now(UTC),
    )

    messages = [
        build_chat_message(session, role="user", content="Hello"),
        build_chat_message(session, role="assistant", content="Hi!"),
    ]

    session_repo = FakeRepo(get_result=session)
    message_repo = FakeRepo(list_result=messages)

    ctx = SimpleNamespace(user_id="user-1")

    result = await handler.list_messages(
        session_id="session-123",
        ctx=ctx,
        session_repo=session_repo,
        message_repo=message_repo,
    )

    assert result == messages
    assert session_repo.get_calls == ["session-123"]
    assert message_repo.filters_passed == {"session_id": "session-123"}


@pytest.mark.asyncio
async def test_list_messages_session_not_found():
    """Should raise NotFoundError when session_repo returns None."""
    handler = MessageHandler()

    session_repo = FakeRepo(get_result=None)
    message_repo = FakeRepo()

    ctx = SimpleNamespace(user_id="user-1")

    with pytest.raises(NotFoundError):
        await handler.list_messages(
            session_id="no-session",
            ctx=ctx,
            session_repo=session_repo,
            message_repo=message_repo,
        )


@pytest.mark.asyncio
async def test_list_messages_wrong_user():
    """Should raise NotFoundError when session belongs to another user."""
    handler = MessageHandler()

    session = ChatSession(
        id="session-123",
        project_id="proj",
        workspace_id="ws",
        user_id="other-user",
        title="Chat",
        created_at=datetime.now(UTC),
        updated_at=datetime.now(UTC),
    )

    session_repo = FakeRepo(get_result=session)
    message_repo = FakeRepo()

    ctx = SimpleNamespace(user_id="user-1")

    with pytest.raises(NotFoundError):
        await handler.list_messages(
            session_id="session-123",
            ctx=ctx,
            session_repo=session_repo,
            message_repo=message_repo,
        )


def test_singleton_instance_exists():
    """Ensure the singleton instance is exposed."""
    assert isinstance(message_handler, MessageHandler)
