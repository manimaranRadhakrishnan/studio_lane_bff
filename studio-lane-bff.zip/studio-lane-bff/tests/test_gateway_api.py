"""Tests for Studio Gateway API."""



def test_health_endpoint(test_client):
    """Test health check endpoint."""
    response = test_client.get("/health")
    assert response.status_code == 200
    data = response.json()
    assert data["status"] == "healthy"
    assert data["service"] == "studio-gateway-api"


def test_root_endpoint(test_client):
    """Test root endpoint."""
    response = test_client.get("/")
    assert response.status_code == 200
    data = response.json()
    assert "service" in data
    assert "docs" in data


def test_openapi_docs(test_client):
    """Test OpenAPI docs are accessible."""
    response = test_client.get("/docs")
    assert response.status_code == 200


def test_correlation_id_added(test_client):
    """Test that correlation ID is added to response."""
    response = test_client.get("/health")
    assert "X-Correlation-ID" in response.headers


def test_cors_headers(test_client):
    """Test CORS headers are present."""
    response = test_client.options("/health")
    assert response.status_code == 200


