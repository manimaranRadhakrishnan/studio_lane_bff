# tests/test_session_handler.py
import uuid
from datetime import UTC, datetime
from types import SimpleNamespace

import pytest

# ⚠️ Update this import path to match your project layout.
# Example if your file is at services/conversation_service/handlers/session_handler.py:
MODULE_IMPORT_PATH = "services.conversation_service.handlers.session_handler"

# Dynamically import the module under test so only one line needs editing
session_module = __import__(MODULE_IMPORT_PATH, fromlist=["*"])

# Pull the things we need from the module-under-test
SessionHandler = session_module.SessionHandler
session_handler = session_module.session_handler
ChatSession = session_module.ChatSession
NotFoundError = session_module.NotFoundError


class FakeRepo:
    """A simple async repository stub matching the expected interface."""

    def __init__(self, get_result=None, list_result=None):
        self.created = None
        self.filters = None
        self.get_calls = []
        self._get_result = get_result
        self._list_result = list_result or []

    async def create(self, session):
        self.created = session
        # Emulate a repository that returns what it created
        return session

    async def list(self, filters=None):
        self.filters = filters
        return self._list_result

    async def get(self, session_id: str):
        self.get_calls.append(session_id)
        return self._get_result


@pytest.mark.asyncio
async def test_create_session_with_explicit_workspace_and_title():
    handler = SessionHandler()
    repo = FakeRepo()

    # Duck-typed request and ctx (no need to import your models)
    request = SimpleNamespace(
        workspace_id="workspace-123",
        project_id="project-abc",
        title="My Chat",
    )
    ctx = SimpleNamespace(
        tenant_id="tenant-xyz",
        user_id="user-001",
    )

    result = await handler.create_session(request=request, ctx=ctx, repo=repo)

    # Ensure repository create was called and a ChatSession was constructed
    assert isinstance(result, ChatSession)
    assert isinstance(repo.created, ChatSession)

    # Validate fields
    assert result.workspace_id == "workspace-123"
    assert result.project_id == "project-abc"
    assert result.user_id == "user-001"
    assert result.title == "My Chat"

    # Validate UUID format
    uuid_obj = uuid.UUID(result.id)
    assert str(uuid_obj) == result.id

    # Validate timestamps are UTC-aware and recent
    assert result.created_at.tzinfo == UTC
    assert result.updated_at.tzinfo == UTC
    now_utc = datetime.now(UTC)
    assert result.created_at <= result.updated_at <= now_utc
    # Ensure created_at is "recent" (within a reasonable window)
    assert (now_utc - result.created_at).total_seconds() < 5


@pytest.mark.asyncio
async def test_create_session_defaults_workspace_and_title():
    handler = SessionHandler()
    repo = FakeRepo()

    request = SimpleNamespace(
        workspace_id=None,
        project_id="project-abc",
        title=None,
    )
    ctx = SimpleNamespace(
        tenant_id="tenant-xyz",
        user_id="user-001",
    )

    result = await handler.create_session(request=request, ctx=ctx, repo=repo)

    assert isinstance(result, ChatSession)
    assert result.workspace_id == "tenant-xyz"  # falls back to tenant_id
    assert result.title == "New Chat"  # default title


@pytest.mark.asyncio
async def test_list_sessions_filters_by_user():
    handler = SessionHandler()
    # Provide a couple of sessions to be listed
    sessions = [
        ChatSession(
            id=str(uuid.uuid4()),
            project_id="p1",
            workspace_id="w",
            user_id="user-001",
            title="Chat 1",
            created_at=datetime.now(UTC),
            updated_at=datetime.now(UTC),
        ),
        ChatSession(
            id=str(uuid.uuid4()),
            project_id="p2",
            workspace_id="w",
            user_id="user-001",
            title="Chat 2",
            created_at=datetime.now(UTC),
            updated_at=datetime.now(UTC),
        ),
    ]
    repo = FakeRepo(list_result=sessions)

    ctx = SimpleNamespace(
        tenant_id="tenant-xyz",
        user_id="user-001",
    )

    result = await handler.list_sessions(ctx=ctx, repo=repo)
    assert result == sessions
    assert repo.filters == {"user_id": "user-001"}


@pytest.mark.asyncio
async def test_get_session_success():
    handler = SessionHandler()

    session = ChatSession(
        id=str(uuid.uuid4()),
        project_id="project-abc",
        workspace_id="workspace-123",
        user_id="user-001",
        title="T",
        created_at=datetime.now(UTC),
        updated_at=datetime.now(UTC),
    )
    repo = FakeRepo(get_result=session)

    ctx = SimpleNamespace(
        tenant_id="tenant-xyz",
        user_id="user-001",
    )

    result = await handler.get_session(session_id=session.id, ctx=ctx, repo=repo)
    assert result is session
    assert repo.get_calls == [session.id]


@pytest.mark.asyncio
async def test_get_session_not_found_raises_notfounderror():
    handler = SessionHandler()
    repo = FakeRepo(get_result=None)
    ctx = SimpleNamespace(tenant_id="t", user_id="u")

    with pytest.raises(NotFoundError) as excinfo:
        await handler.get_session(session_id="does-not-exist", ctx=ctx, repo=repo)

    assert "Session not found" in str(excinfo.value)


@pytest.mark.asyncio
async def test_get_session_wrong_user_raises_notfounderror():
    handler = SessionHandler()

    # Session belongs to a different user
    session = ChatSession(
        id=str(uuid.uuid4()),
        project_id="project-abc",
        workspace_id="workspace-123",
        user_id="other-user",
        title="T",
        created_at=datetime.now(UTC),
        updated_at=datetime.now(UTC),
    )
    repo = FakeRepo(get_result=session)
    ctx = SimpleNamespace(tenant_id="t", user_id="user-001")

    with pytest.raises(NotFoundError) as excinfo:
        await handler.get_session(session_id=session.id, ctx=ctx, repo=repo)

    assert "Session not found" in str(excinfo.value)


def test_singleton_instance_exposed():
    # Ensure the singleton is present and of correct type
    assert isinstance(session_handler, SessionHandler)
