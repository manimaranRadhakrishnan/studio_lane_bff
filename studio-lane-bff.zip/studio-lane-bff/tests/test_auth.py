"""Tests for auth service."""

import sys
from pathlib import Path

from fastapi.testclient import TestClient


sys.path.insert(0, str(Path(__file__).parent.parent.resolve()))

from services.studio_gateway_api.main import create_app


client = TestClient(create_app())

def test_health():
    """Test health endpoint."""
    response = client.get("/health")
    assert response.status_code == 200
    assert response.json()["status"] == "healthy"


def test_get_keycloak_config():
    """Test getting Keycloak config (public)."""
    response = client.get("/api/v1/studio/auth/keycloak/config")
    assert response.status_code == 200
    data = response.json()
    if "data" in data:
        data = data["data"]
    assert "keycloak_url" in data
    assert "realm" in data
    assert "client_id" in data
    assert "redirect_uri" in data
    assert "scopes" in data


