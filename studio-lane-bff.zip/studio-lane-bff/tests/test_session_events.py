"""Tests for session events endpoints."""

import uuid

import pytest
from fastapi.testclient import TestClient

from services.studio_gateway_api.main import create_app
from shared.auth import get_request_context
from shared.context import RequestContext
from shared.cosmosdb import get_cosmosdb
from tests.inmemory_cosmos import InMemoryCosmosDBClient


@pytest.fixture
def events_context() -> RequestContext:
    """Create a RequestContext for event operations."""
    return RequestContext(
        tenant_id="test-tenant",
        user_id="events-user",
        roles={"Owner", "Editor"},
        session_id="test-session",
        correlation_id=str(uuid.uuid4()),
    )


@pytest.fixture
def viewer_context() -> RequestContext:
    """Create a RequestContext with Viewer role."""
    return RequestContext(
        tenant_id="test-tenant",
        user_id="viewer-user",
        roles={"Viewer"},
        session_id="test-session",
        correlation_id=str(uuid.uuid4()),
    )


@pytest.fixture
def events_client(cosmos_client, events_context, monkeypatch):
    """Create test client for event operations."""
    monkeypatch.setenv("REQUIRE_AUTH_GLOBALLY", "false")

    app = create_app()

    async def override_get_cosmosdb():
        return cosmos_client

    async def override_get_request_context():
        return events_context

    app.dependency_overrides[get_cosmosdb] = override_get_cosmosdb
    app.dependency_overrides[get_request_context] = override_get_request_context

    with TestClient(app) as client:
        yield client


@pytest.fixture
def viewer_client(cosmos_client, viewer_context, monkeypatch):
    """Create test client with Viewer role."""
    monkeypatch.setenv("REQUIRE_AUTH_GLOBALLY", "false")

    app = create_app()

    async def override_get_cosmosdb():
        return cosmos_client

    async def override_get_request_context():
        return viewer_context

    app.dependency_overrides[get_cosmosdb] = override_get_cosmosdb
    app.dependency_overrides[get_request_context] = override_get_request_context

    with TestClient(app) as client:
        yield client


def test_create_session_event_success(events_client):
    """Test successfully creating a session event."""
    client = events_client

    # Create a session
    session_resp = client.post(
        "/api/v1/studio/conversations/sessions",
        json={
            "project_id": "project-123",
            "workspace_id": "workspace-123",
            "title": "Test Session",
        },
    )
    session_id = session_resp.json()["data"]["id"]

    # Create an event
    event_resp = client.post(
        f"/api/v1/studio/conversations/sessions/{session_id}/events",
        json={
            "event_type": "plan_created",
            "payload": {"plan_id": "plan-123", "tasks": 5},
        },
    )
    assert event_resp.status_code == 201
    data = event_resp.json()["data"]
    assert data["session_id"] == session_id
    assert data["event_type"] == "plan_created"
    assert data["payload"] == {"plan_id": "plan-123", "tasks": 5}
    assert "id" in data
    assert "created_at" in data


def test_list_session_events(events_client):
    """Test listing events for a session."""
    client = events_client

    # Create a session
    session_resp = client.post(
        "/api/v1/studio/conversations/sessions",
        json={
            "project_id": "project-123",
            "workspace_id": "workspace-123",
            "title": "Test Session",
        },
    )
    session_id = session_resp.json()["data"]["id"]

    # Create multiple events
    event_types = ["plan_created", "task_started", "task_completed", "code_generated"]
    for event_type in event_types:
        client.post(
            f"/api/v1/studio/conversations/sessions/{session_id}/events",
            json={"event_type": event_type, "payload": {"test": "data"}},
        )

    # List events
    list_resp = client.get(f"/api/v1/studio/conversations/sessions/{session_id}/events")
    assert list_resp.status_code == 200
    events = list_resp.json()["data"]
    assert len(events) == 4
    event_types_returned = [e["event_type"] for e in events]
    assert set(event_types_returned) == set(event_types)


def test_create_session_event_invalid_type(events_client):
    """Test creating event with invalid event type."""
    client = events_client

    # Create a session
    session_resp = client.post(
        "/api/v1/studio/conversations/sessions",
        json={
            "project_id": "project-123",
            "workspace_id": "workspace-123",
            "title": "Test Session",
        },
    )
    session_id = session_resp.json()["data"]["id"]

    # Try to create event with invalid type
    event_resp = client.post(
        f"/api/v1/studio/conversations/sessions/{session_id}/events",
        json={"event_type": "invalid_type", "payload": {}},
    )
    assert event_resp.status_code == 400
    assert "Invalid event_type" in event_resp.json()["error"]["message"]


def test_create_session_event_valid_types(events_client):
    """Test creating events with all valid event types."""
    client = events_client

    # Create a session
    session_resp = client.post(
        "/api/v1/studio/conversations/sessions",
        json={
            "project_id": "project-123",
            "workspace_id": "workspace-123",
            "title": "Test Session",
        },
    )
    session_id = session_resp.json()["data"]["id"]

    valid_types = ["plan_created", "task_started", "task_completed", "code_generated", "error"]
    for event_type in valid_types:
        event_resp = client.post(
            f"/api/v1/studio/conversations/sessions/{session_id}/events",
            json={"event_type": event_type, "payload": {"test": "data"}},
        )
        assert event_resp.status_code == 201
        assert event_resp.json()["data"]["event_type"] == event_type


def test_create_session_event_viewer_cannot_create(viewer_client):
    """Test that Viewer role cannot create events."""
    client = viewer_client

    # Create a session (viewer can create sessions)
    session_resp = client.post(
        "/api/v1/studio/conversations/sessions",
        json={
            "project_id": "project-123",
            "workspace_id": "workspace-123",
            "title": "Test Session",
        },
    )
    session_id = session_resp.json()["data"]["id"]

    # Try to create event (should fail)
    event_resp = client.post(
        f"/api/v1/studio/conversations/sessions/{session_id}/events",
        json={"event_type": "plan_created", "payload": {}},
    )
    assert event_resp.status_code == 403


def test_list_session_events_viewer_can_access(viewer_client):
    """Test that Viewer role can list events."""
    client = viewer_client

    # Create a session
    session_resp = client.post(
        "/api/v1/studio/conversations/sessions",
        json={
            "project_id": "project-123",
            "workspace_id": "workspace-123",
            "title": "Test Session",
        },
    )
    session_id = session_resp.json()["data"]["id"]

    # List events (should work even if empty)
    list_resp = client.get(f"/api/v1/studio/conversations/sessions/{session_id}/events")
    assert list_resp.status_code == 200
    assert isinstance(list_resp.json()["data"], list)


def test_list_session_events_not_found(events_client):
    """Test listing events for non-existent session."""
    client = events_client

    fake_session_id = str(uuid.uuid4())
    list_resp = client.get(f"/api/v1/studio/conversations/sessions/{fake_session_id}/events")
    assert list_resp.status_code == 404


def test_create_session_event_not_found(events_client):
    """Test creating event for non-existent session."""
    client = events_client

    fake_session_id = str(uuid.uuid4())
    event_resp = client.post(
        f"/api/v1/studio/conversations/sessions/{fake_session_id}/events",
        json={"event_type": "plan_created", "payload": {}},
    )
    assert event_resp.status_code == 404


