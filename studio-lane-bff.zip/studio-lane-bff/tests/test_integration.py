"""Integration tests for complete workflows."""

import pytest


def test_complete_project_workflow(test_client):
    """Test complete project creation and organization workflow."""
    # Create folder
    folder_response = test_client.post(
        "/api/v1/studio/workspaces/folders",
        json={"name": "Banking Apps"},
    )
    assert folder_response.status_code == 201
    folder_id = folder_response.json()["id"]

    # Create project
    project_response = test_client.post(
        "/api/v1/studio/workspaces/projects",
        json={"name": "Mobile Banking", "description": "Mobile banking application"},
    )
    assert project_response.status_code == 201
    project_id = project_response.json()["id"]

    # Move project to folder
    move_response = test_client.post(
        f"/api/v1/studio/workspaces/projects/{project_id}/move",
        json={"folder_id": folder_id},
    )
    assert move_response.status_code == 200
    assert move_response.json()["folder_id"] == folder_id

    # Add to favorites
    fav_response = test_client.post(f"/api/v1/studio/workspaces/projects/{project_id}/favorite")
    assert fav_response.status_code == 200
    assert fav_response.json()["favorited"] is True

    # Share project
    share_response = test_client.post(
        f"/api/v1/studio/workspaces/projects/{project_id}/share",
        json={"shared_with_email": "colleague@example.com", "permission": "edit"},
    )
    assert share_response.status_code == 201

    # List shares
    shares_response = test_client.get(f"/api/v1/studio/workspaces/projects/{project_id}/shares")
    assert shares_response.status_code == 200
    assert len(shares_response.json()) == 1


def test_folder_organization(test_client):
    """Test folder operations and project organization."""
    # Create multiple folders
    folder1 = test_client.post("/api/v1/studio/workspaces/folders", json={"name": "Frontend"}).json()
    folder2 = test_client.post("/api/v1/studio/workspaces/folders", json={"name": "Backend"}).json()

    # Create projects
    project1 = test_client.post("/api/v1/studio/workspaces/projects", json={"name": "React App"}).json()
    project2 = test_client.post("/api/v1/studio/workspaces/projects", json={"name": "API Service"}).json()

    # Move projects to folders
    test_client.post(f"/api/v1/studio/workspaces/projects/{project1['id']}/move", json={"folder_id": folder1["id"]})
    test_client.post(f"/api/v1/studio/workspaces/projects/{project2['id']}/move", json={"folder_id": folder2["id"]})

    # Rename folder
    rename_response = test_client.put(
        f"/api/v1/studio/workspaces/folders/{folder1['id']}",
        json={"name": "Frontend Apps"},
    )
    assert rename_response.status_code == 200
    assert rename_response.json()["name"] == "Frontend Apps"

    # Delete folder (should unassign projects)
    delete_response = test_client.delete(f"/api/v1/studio/workspaces/folders/{folder2['id']}")
    assert delete_response.status_code == 204

    # Project should still exist but without folder
    project_response = test_client.get(f"/api/v1/studio/workspaces/projects/{project2['id']}")
    assert project_response.status_code == 200
    assert project_response.json()["folder_id"] is None


