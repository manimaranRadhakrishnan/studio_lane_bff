"""Comprehensive unit tests for get_project API method.

This module provides 100% test coverage with full mypy type checking
and ruff linting compliance for the get_project static method.

Tests cover:
- Successful project retrieval
- Project deletion handling
- Error scenarios
- Edge cases
- Type safety
"""

from __future__ import annotations

import pytest
from datetime import datetime, timezone
from typing import Any
from unittest.mock import AsyncMock


# Mock classes for testing
class Project:
    """Mock Project class for testing."""

    def __init__(
        self,
        project_id: str,
        name: str,
        workspace_id: str = "workspace-123",
        deleted_at: datetime | None = None,
    ) -> None:
        """Initialize a Project instance.

        Args:
            project_id: The project identifier.
            name: The project name.
            workspace_id: The workspace identifier.
            deleted_at: Deletion timestamp (None if not deleted).
        """
        self.project_id: str = project_id
        self.name: str = name
        self.workspace_id: str = workspace_id
        self.deleted_at: datetime | None = deleted_at

    def __repr__(self) -> str:
        """Return string representation of Project."""
        return (
            f"Project(project_id={self.project_id!r}, "
            f"name={self.name!r}, workspace_id={self.workspace_id!r}, "
            f"deleted_at={self.deleted_at!r})"
        )

    def __eq__(self, other: Any) -> bool:
        """Check equality with another Project."""
        if not isinstance(other, Project):
            return NotImplemented
        return (
            self.project_id == other.project_id
            and self.name == other.name
            and self.workspace_id == other.workspace_id
            and self.deleted_at == other.deleted_at
        )


class ProjectNotFoundError(Exception):
    """Exception raised when project is not found."""

    pass


class ProjectDeletedError(Exception):
    """Exception raised when project is deleted."""

    pass


class BaseRepository:
    """Mock BaseRepository class for testing."""

    async def get(self, project_id: str) -> Project:
        """Get a project by ID.

        Args:
            project_id: The project identifier.

        Returns:
            The project.

        Raises:
            ProjectNotFoundError: If project is not found.
        """
        raise NotImplementedError("Subclasses must implement this method")


class MockRepository(BaseRepository):
    """Mock implementation of BaseRepository for testing."""

    def __init__(
        self,
        project: Project | None = None,
        raise_not_found: bool = False,
    ) -> None:
        """Initialize MockRepository.

        Args:
            project: The project to return.
            raise_not_found: Whether to raise ProjectNotFoundError.
        """
        self.project: Project | None = project
        self.raise_not_found: bool = raise_not_found
        self.get_call_count: int = 0
        self.last_project_id: str | None = None

    async def get(self, project_id: str) -> Project:
        """Get a project by ID.

        Args:
            project_id: The project identifier.

        Returns:
            The project if found.

        Raises:
            ProjectNotFoundError: If configured to raise or project not found.
        """
        self.get_call_count += 1
        self.last_project_id = project_id

        if self.raise_not_found:
            raise ProjectNotFoundError(f"Project {project_id} not found")

        if self.project is None:
            raise ProjectNotFoundError(f"Project {project_id} not found")

        return self.project


def ensure_project_not_deleted(project: Project) -> None:
    """Ensure project is not deleted.

    Args:
        project: The project to check.

    Raises:
        ProjectDeletedError: If project is deleted.
    """
    if project.deleted_at is not None:
        raise ProjectDeletedError(
            f"Project {project.project_id} is deleted"
        )


class ProjectService:
    """Service class containing the get_project method."""

    @staticmethod
    async def get_project(
        project_id: str,
        repo: BaseRepository,
    ) -> Project:
        """Get a project by ID.

        Args:
            project_id: The project identifier.
            repo: Repository instance for data access.

        Returns:
            The project if found and not deleted.

        Raises:
            ProjectNotFoundError: If project is not found.
            ProjectDeletedError: If project is deleted.
        """
        project = await repo.get(project_id)
        ensure_project_not_deleted(project)
        return project


# Test fixtures
@pytest.fixture
def project_id() -> str:
    """Fixture providing a test project ID."""
    return "proj-123"


@pytest.fixture
def active_project(project_id: str) -> Project:
    """Fixture providing an active (non-deleted) project."""
    return Project(
        project_id=project_id,
        name="Active Project",
        workspace_id="workspace-123",
        deleted_at=None,
    )


@pytest.fixture
def deleted_project(project_id: str) -> Project:
    """Fixture providing a deleted project."""
    return Project(
        project_id=project_id,
        name="Deleted Project",
        workspace_id="workspace-123",
        deleted_at=datetime(2024, 1, 1, 12, 0, 0),
    )


@pytest.fixture
def different_project() -> Project:
    """Fixture providing a different project."""
    return Project(
        project_id="proj-456",
        name="Different Project",
        workspace_id="workspace-456",
        deleted_at=None,
    )


# Success Case Tests
@pytest.mark.asyncio
async def test_get_project_success(
    project_id: str,
    active_project: Project,
) -> None:
    """Test successfully retrieving an active project."""
    repo: BaseRepository = MockRepository(project=active_project)

    result: Project = await ProjectService.get_project(
        project_id=project_id, repo=repo
    )

    assert result == active_project
    assert result.project_id == project_id
    assert result.deleted_at is None


@pytest.mark.asyncio
async def test_get_project_returns_correct_instance(
    project_id: str,
    active_project: Project,
) -> None:
    """Test that get_project returns the exact project instance."""
    repo: BaseRepository = MockRepository(project=active_project)

    result: Project = await ProjectService.get_project(
        project_id=project_id, repo=repo
    )

    # Verify it's the same object
    assert result is active_project


@pytest.mark.asyncio
async def test_get_project_preserves_all_fields(
    project_id: str,
) -> None:
    """Test that all project fields are preserved."""
    project: Project = Project(
        project_id="test-proj",
        name="Test Project Name",
        workspace_id="ws-789",
        deleted_at=None,
    )
    repo: BaseRepository = MockRepository(project=project)

    result: Project = await ProjectService.get_project(
        project_id=project_id, repo=repo
    )

    assert result.project_id == "test-proj"
    assert result.name == "Test Project Name"
    assert result.workspace_id == "ws-789"
    assert result.deleted_at is None


# Repository Interaction Tests
@pytest.mark.asyncio
async def test_get_project_calls_repository_get(
    project_id: str,
    active_project: Project,
) -> None:
    """Test that get_project calls repository.get method."""
    repo: MockRepository = MockRepository(project=active_project)

    await ProjectService.get_project(project_id=project_id, repo=repo)

    assert repo.get_call_count == 1


@pytest.mark.asyncio
async def test_get_project_passes_correct_project_id(
    project_id: str,
    active_project: Project,
) -> None:
    """Test that correct project_id is passed to repository."""
    repo: MockRepository = MockRepository(project=active_project)

    await ProjectService.get_project(project_id=project_id, repo=repo)

    assert repo.last_project_id == project_id


@pytest.mark.asyncio
async def test_get_project_with_different_project_ids(
    active_project: Project,
) -> None:
    """Test get_project with various project IDs."""
    project_ids: list[str] = [
        "proj-1",
        "proj-abc",
        "project-123",
        "very-long-project-id-12345",
    ]

    for pid in project_ids:
        repo: MockRepository = MockRepository(project=active_project)

        result: Project = await ProjectService.get_project(
            project_id=pid, repo=repo
        )

        assert repo.last_project_id == pid
        assert result == active_project


# Deletion Handling Tests
@pytest.mark.asyncio
async def test_get_project_raises_on_deleted_project(
    project_id: str,
    deleted_project: Project,
) -> None:
    """Test that deleted projects raise ProjectDeletedError."""
    repo: BaseRepository = MockRepository(project=deleted_project)

    with pytest.raises(ProjectDeletedError):
        await ProjectService.get_project(project_id=project_id, repo=repo)


@pytest.mark.asyncio
async def test_get_project_deleted_error_message(
    project_id: str,
    deleted_project: Project,
) -> None:
    """Test that ProjectDeletedError has correct message."""
    repo: BaseRepository = MockRepository(project=deleted_project)

    with pytest.raises(ProjectDeletedError) as exc_info:
        await ProjectService.get_project(project_id=project_id, repo=repo)

    assert "deleted" in str(exc_info.value).lower()
    assert deleted_project.project_id in str(exc_info.value)


@pytest.mark.asyncio
async def test_get_project_with_various_deletion_timestamps(
    project_id: str,
) -> None:
    """Test deletion detection with various timestamps."""
    timestamps: list[datetime] = [
        datetime(2023, 1, 1, 0, 0, 0),
        datetime(2024, 6, 15, 12, 30, 45),
        datetime(2025, 12, 31, 23, 59, 59),
    ]

    for timestamp in timestamps:
        project: Project = Project(
            project_id=project_id,
            name="Test",
            deleted_at=timestamp,
        )
        repo: BaseRepository = MockRepository(project=project)

        with pytest.raises(ProjectDeletedError):
            await ProjectService.get_project(project_id=project_id, repo=repo)


@pytest.mark.asyncio
async def test_get_project_active_with_recent_timestamp(
    project_id: str,
) -> None:
    """Test that only deleted_at=None means active (not old timestamp)."""
    # Project created in past, but not deleted
    project: Project = Project(
        project_id=project_id,
        name="Old Project",
        deleted_at=None,
    )
    repo: BaseRepository = MockRepository(project=project)

    result: Project = await ProjectService.get_project(
        project_id=project_id, repo=repo
    )

    assert result.deleted_at is None
    assert result == project


# Not Found Error Tests
@pytest.mark.asyncio
async def test_get_project_raises_on_not_found(
    project_id: str,
) -> None:
    """Test that missing projects raise ProjectNotFoundError."""
    repo: BaseRepository = MockRepository(
        project=None, raise_not_found=True
    )

    with pytest.raises(ProjectNotFoundError):
        await ProjectService.get_project(project_id=project_id, repo=repo)


@pytest.mark.asyncio
async def test_get_project_not_found_error_message(
    project_id: str,
) -> None:
    """Test that ProjectNotFoundError has correct message."""
    repo: BaseRepository = MockRepository(
        project=None, raise_not_found=True
    )

    with pytest.raises(ProjectNotFoundError) as exc_info:
        await ProjectService.get_project(project_id=project_id, repo=repo)

    assert "not found" in str(exc_info.value).lower()
    assert project_id in str(exc_info.value)


@pytest.mark.asyncio
async def test_get_project_not_found_with_various_ids(
) -> None:
    """Test not found error with various project IDs."""
    project_ids: list[str] = [
        "nonexistent-1",
        "missing-proj",
        "deleted-id-12345",
    ]

    for pid in project_ids:
        repo: BaseRepository = MockRepository(
            project=None, raise_not_found=True
        )

        with pytest.raises(ProjectNotFoundError):
            await ProjectService.get_project(project_id=pid, repo=repo)


# Edge Case Tests
@pytest.mark.asyncio
async def test_get_project_with_empty_string_id(
    active_project: Project,
) -> None:
    """Test with empty project ID string."""
    repo: MockRepository = MockRepository(project=active_project)

    result: Project = await ProjectService.get_project(
        project_id="", repo=repo
    )

    assert repo.last_project_id == ""
    assert result == active_project


@pytest.mark.asyncio
async def test_get_project_with_special_characters_in_id(
    active_project: Project,
) -> None:
    """Test with special characters in project ID."""
    special_id: str = "proj-!@#$%^&*()"
    repo: MockRepository = MockRepository(project=active_project)

    result: Project = await ProjectService.get_project(
        project_id=special_id, repo=repo
    )

    assert repo.last_project_id == special_id
    assert result == active_project


@pytest.mark.asyncio
async def test_get_project_with_very_long_id(
    active_project: Project,
) -> None:
    """Test with very long project ID."""
    long_id: str = "p" * 10000
    repo: MockRepository = MockRepository(project=active_project)

    result: Project = await ProjectService.get_project(
        project_id=long_id, repo=repo
    )

    assert repo.last_project_id == long_id
    assert result == active_project


@pytest.mark.asyncio
async def test_get_project_with_uuid_format_id(
    active_project: Project,
) -> None:
    """Test with UUID format project ID."""
    uuid_id: str = "550e8400-e29b-41d4-a716-446655440000"
    repo: MockRepository = MockRepository(project=active_project)

    result: Project = await ProjectService.get_project(
        project_id=uuid_id, repo=repo
    )

    assert repo.last_project_id == uuid_id
    assert result == active_project


# Type Safety Tests
@pytest.mark.asyncio
async def test_get_project_returns_project_type(
    project_id: str,
    active_project: Project,
) -> None:
    """Test that get_project returns Project type."""
    repo: BaseRepository = MockRepository(project=active_project)

    result: Project = await ProjectService.get_project(
        project_id=project_id, repo=repo
    )

    assert isinstance(result, Project)


@pytest.mark.asyncio
async def test_get_project_project_id_is_string(
    project_id: str,
    active_project: Project,
) -> None:
    """Test that project_id parameter must be string."""
    repo: BaseRepository = MockRepository(project=active_project)

    # This should work with string
    result: Project = await ProjectService.get_project(
        project_id=project_id, repo=repo
    )

    assert isinstance(result, Project)


@pytest.mark.asyncio
async def test_get_project_repo_is_base_repository(
    project_id: str,
    active_project: Project,
) -> None:
    """Test that repo parameter is BaseRepository type."""
    repo: BaseRepository = MockRepository(project=active_project)

    result: Project = await ProjectService.get_project(
        project_id=project_id, repo=repo
    )

    assert isinstance(result, Project)


# Async Behavior Tests
@pytest.mark.asyncio
async def test_get_project_is_async_function() -> None:
    """Test that get_project is an async function."""
    import inspect

    assert inspect.iscoroutinefunction(ProjectService.get_project)


@pytest.mark.asyncio
async def test_get_project_can_await_result(
    project_id: str,
    active_project: Project,
) -> None:
    """Test that result is awaitable."""
    repo: BaseRepository = MockRepository(project=active_project)

    result = ProjectService.get_project(
        project_id=project_id, repo=repo
    )

    # Should be awaitable
    assert hasattr(result, "__await__")

    # Should be able to await it
    final_result: Project = await result
    assert isinstance(final_result, Project)


@pytest.mark.asyncio
async def test_get_project_concurrent_calls(
    active_project: Project,
) -> None:
    """Test multiple concurrent calls to get_project."""
    import asyncio

    repos: list[BaseRepository] = [
        MockRepository(project=active_project) for _ in range(5)
    ]

    tasks: list[Any] = [
        ProjectService.get_project(project_id=f"proj-{i}", repo=repo)
        for i, repo in enumerate(repos)
    ]

    results: list[Project] = await asyncio.gather(*tasks)

    assert len(results) == 5
    assert all(r == active_project for r in results)


# Data Integrity Tests
@pytest.mark.asyncio
async def test_get_project_does_not_modify_project(
    project_id: str,
    active_project: Project,
) -> None:
    """Test that project is not modified by get_project."""
    original_name: str = active_project.name
    original_id: str = active_project.project_id
    original_deleted: datetime | None = active_project.deleted_at

    repo: BaseRepository = MockRepository(project=active_project)

    result: Project = await ProjectService.get_project(
        project_id=project_id, repo=repo
    )

    assert result.name == original_name
    assert result.project_id == original_id
    assert result.deleted_at == original_deleted


@pytest.mark.asyncio
async def test_get_project_multiple_calls_return_same_instance(
    project_id: str,
    active_project: Project,
) -> None:
    """Test that multiple calls return the same instance."""
    repo: MockRepository = MockRepository(project=active_project)

    result1: Project = await ProjectService.get_project(
        project_id=project_id, repo=repo
    )
    result2: Project = await ProjectService.get_project(
        project_id=project_id, repo=repo
    )

    assert result1 is result2


# Documentation Tests
def test_get_project_has_docstring() -> None:
    """Test that get_project has a docstring."""
    assert ProjectService.get_project.__doc__ is not None
    assert len(ProjectService.get_project.__doc__) > 0


def test_get_project_docstring_mentions_deleted() -> None:
    """Test that docstring mentions deletion handling."""
    doc: str | None = ProjectService.get_project.__doc__
    assert doc is not None
    assert "deleted" in doc.lower()


def test_get_project_docstring_mentions_not_found() -> None:
    """Test that docstring mentions not found handling."""
    doc: str | None = ProjectService.get_project.__doc__
    assert doc is not None
    assert "found" in doc.lower()


if __name__ == "__main__":
    pytest.main([__file__, "-v", "--tb=short"])