from __future__ import annotations

import re
import typing as t
from datetime import datetime, timezone, timedelta, timezone
from types import SimpleNamespace

import pytest
from fastapi import FastAPI
from fastapi.testclient import TestClient

# Import router and typed models from your code
from services.designsystem_service.router import (
    create_design_system,
    delete_design_system,
    get_design_system,
    list_design_systems,
    router,
    update_design_system,
    get_design_system_repo,  # for dependency override in HTTP smoke test
    get_request_context,     # for dependency override in HTTP smoke test
)
from services.designsystem_service.models import (
    CreateDesignSystemRequest,
    UpdateDesignSystemRequest,
)
from shared.models import DesignSystem
from shared import NotFoundError, RequestContext
from shared.repository import BaseRepository

# -----------------------------
# In-memory fake repository
# -----------------------------

class InMemoryDesignSystemRepo:
    """A minimal in-memory repo that mimics BaseRepository[DesignSystem]."""

    def __init__(self) -> None:
        self._items: dict[str, DesignSystem] = {}

    # Duck-typed async methods to match BaseRepository public surface.
    async def list(self) -> list[DesignSystem]:
        return list(self._items.values())

    async def create(self, item: DesignSystem) -> DesignSystem:
        self._items[item.id] = item
        return item

    async def get(self, item_id: str) -> DesignSystem | None:
        return self._items.get(item_id)

    async def update(self, item_id: str, **update_data: t.Any) -> DesignSystem:
        existing = self._items.get(item_id)
        if existing is None:
            raise KeyError(item_id)
        # Pydantic model: use model_copy/update (v2)
        updated = existing.model_copy(update=update_data)
        self._items[item_id] = updated
        return updated

    async def delete(self, item_id: str) -> None:
        if item_id not in self._items:
            raise KeyError(item_id)
        del self._items[item_id]


@pytest.fixture()
def repo() -> InMemoryDesignSystemRepo:
    return InMemoryDesignSystemRepo()


@pytest.fixture()
def ctx_owner() -> RequestContext:
    # Adjust fields if your RequestContext differs
    # Include roles to reflect "Owner" for clarity—even though we won’t execute require_role dependency.
    return RequestContext(
        tenant_id="tenant-123",
        user_id="user-456",
        roles=["Owner"],
    )


# ---------------------------------------------------------
# Unit tests calling the endpoint callables directly
# ---------------------------------------------------------

@pytest.mark.anyio
async def test_list_design_systems(repo: InMemoryDesignSystemRepo, ctx_owner: RequestContext) -> None:
    # Seed
    ds1 = DesignSystem(
        id="ds-1",
        name="DS One",
        version="1.0.0",
        description="first",
        project_id="proj-1",
        tenant_id=ctx_owner.tenant_id,
        created_by=ctx_owner.user_id,
        config={"tokens": {}},
        created_at=datetime.now(timezone.utc),
        updated_at=datetime.now(timezone.utc),
    )
    ds2 = ds1.model_copy(update={"id": "ds-2", "name": "DS Two"})
    await repo.create(ds1)
    await repo.create(ds2)

    result = await list_design_systems(
        ctx=ctx_owner,
        repo=t.cast(BaseRepository[DesignSystem], repo),
    )
    assert len(result) == 2
    names = {r.name for r in result}
    assert names == {"DS One", "DS Two"}


@pytest.mark.anyio
async def test_get_design_system_found(repo: InMemoryDesignSystemRepo, ctx_owner: RequestContext) -> None:
    ds = DesignSystem(
        id="ds-123",
        name="My DS",
        version="1.0.0",
        description="desc",
        project_id="proj-123",
        tenant_id=ctx_owner.tenant_id,
        created_by=ctx_owner.user_id,
        config={"tokens": {}},
        created_at=datetime.now(timezone.utc),
        updated_at=datetime.now(timezone.utc),
    )
    await repo.create(ds)

    got = await get_design_system(
        design_system_id="ds-123",
        repo=t.cast(BaseRepository[DesignSystem], repo),
    )
    assert got.id == "ds-123"
    assert got.name == "My DS"


@pytest.mark.anyio
async def test_get_design_system_not_found(repo: InMemoryDesignSystemRepo) -> None:
    with pytest.raises(NotFoundError):
        await get_design_system(
            design_system_id="does-not-exist",
            repo=t.cast(BaseRepository[DesignSystem], repo),
        )


@pytest.mark.anyio
async def test_create_design_system_sets_server_fields(repo: InMemoryDesignSystemRepo, ctx_owner: RequestContext) -> None:
    payload = CreateDesignSystemRequest(
        name="New DS",
        version="1.0.0",
        description="Hello",
        project_id="proj-1",
        config={"tokens": {"color": {"primary": "#000"}}},
    )
    created = await create_design_system(
        request=payload,
        ctx=ctx_owner,  # bypasses require_role because we call the underlying function
        repo=t.cast(BaseRepository[DesignSystem], repo),
    )

    # id is a UUID v4
    assert re.fullmatch(
        r"[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}", created.id
    )
    assert created.tenant_id == ctx_owner.tenant_id
    assert created.created_by == ctx_owner.user_id
    assert created.name == "New DS"
    assert created.version == "1.0.0"

    now = datetime.now(timezone.utc)
    assert isinstance(created.created_at, datetime)
    assert isinstance(created.updated_at, datetime)
    # Timestamps should be "recent"
    assert (now - created.created_at) < timedelta(seconds=5)
    assert (now - created.updated_at) < timedelta(seconds=5)



@pytest.mark.anyio
async def test_update_design_system_partial_and_timestamp(
    repo: InMemoryDesignSystemRepo, ctx_owner: RequestContext
) -> None:
    base = DesignSystem(
        id="ds-1",
        name="Base DS",
        version="1.0.0",
        description="old",
        project_id="proj-1",
        tenant_id=ctx_owner.tenant_id,
        created_by=ctx_owner.user_id,
        config={"tokens": {}},
        created_at=datetime.now(timezone.utc) - timedelta(days=1),
        updated_at=datetime.now(timezone.utc) - timedelta(days=1),
    )
    await repo.create(base)

    req = UpdateDesignSystemRequest(
        name="Updated DS",
        version=None,          # unchanged
        description="new desc",
        config={"tokens": {"color": {"primary": "#123"}}},
    )
    updated = await update_design_system(
        design_system_id="ds-1",
        request=req,
        ctx=ctx_owner,  # bypass role DI
        repo=t.cast(BaseRepository[DesignSystem], repo),
    )

    # Helper localized to this test: normalize any datetime to UTC-aware
    def to_utc_aware(dt: datetime) -> datetime:
        if dt.tzinfo is None:
            # Treat naive datetimes as UTC for comparison purposes
            return dt.replace(tzinfo=timezone.utc)
        return dt.astimezone(timezone.utc)

    assert updated.id == "ds-1"
    assert updated.name == "Updated DS"
    assert updated.version == "1.0.0"  # unchanged
    assert updated.description == "new desc"
    assert updated.config == {"tokens": {"color": {"primary": "#123"}}}
    # Normalize both before comparing to avoid naive vs aware TypeError
    assert to_utc_aware(updated.updated_at) > to_utc_aware(base.updated_at)


@pytest.mark.anyio
async def test_update_design_system_not_found(repo: InMemoryDesignSystemRepo, ctx_owner: RequestContext) -> None:
    req = UpdateDesignSystemRequest(name="X")
    with pytest.raises(NotFoundError):
        await update_design_system(
            design_system_id="missing",
            request=req,
            ctx=ctx_owner,
            repo=t.cast(BaseRepository[DesignSystem], repo),
        )


@pytest.mark.anyio
async def test_delete_design_system_success(repo: InMemoryDesignSystemRepo, ctx_owner: RequestContext) -> None:
    ds = DesignSystem(
        id="del-1",
        name="ToDelete",
        version="1.0.0",
        description="",
        project_id="proj",
        tenant_id=ctx_owner.tenant_id,
        created_by=ctx_owner.user_id,
        config={},
        created_at=datetime.now(timezone.utc),
        updated_at=datetime.now(timezone.utc),
    )
    await repo.create(ds)

    result = await delete_design_system(
        design_system_id="del-1",
        ctx=ctx_owner,
        repo=t.cast(BaseRepository[DesignSystem], repo),
    )
    assert result is None

    with pytest.raises(NotFoundError):
        await get_design_system("del-1", t.cast(BaseRepository[DesignSystem], repo))


@pytest.mark.anyio
async def test_delete_design_system_not_found(repo: InMemoryDesignSystemRepo, ctx_owner: RequestContext) -> None:
    with pytest.raises(NotFoundError):
        await delete_design_system(
            design_system_id="missing",
            ctx=ctx_owner,
            repo=t.cast(BaseRepository[DesignSystem], repo),
        )


# ---------------------------------------------------------
# HTTP smoke test (routing + DI override on simple GET)
#  - We avoid create/update/delete here due to require_role
# ---------------------------------------------------------

def test_http_list_design_systems_smoke(repo: InMemoryDesignSystemRepo, ctx_owner: RequestContext) -> None:
    app = FastAPI()
    app.include_router(router)

    # Seed the fake repo
    ds = DesignSystem(
        id="smoke-1",
        name="Smoke DS",
        version="1.0.0",
        description="",
        project_id="proj",
        tenant_id=ctx_owner.tenant_id,
        created_by=ctx_owner.user_id,
        config={},
        created_at=datetime.now(timezone.utc),
        updated_at=datetime.now(timezone.utc),
    )

    async def _seeded_repo() -> InMemoryDesignSystemRepo:
        # Seed on first use
        if not repo._items:
            await repo.create(ds)
        return repo

    # Override dependencies used by GET /design-systems
    app.dependency_overrides[get_design_system_repo] = _seeded_repo  # type: ignore[assignment]
    app.dependency_overrides[get_request_context] = lambda: ctx_owner

    client = TestClient(app)
    resp = client.get("/design-systems")
    assert resp.status_code == 200
    data = resp.json()
    assert isinstance(data, list)
    assert any(item["id"] == "smoke-1" for item in data)