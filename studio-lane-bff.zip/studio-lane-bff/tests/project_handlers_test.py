# tests/test_project_handler.py

import pytest
import uuid
from datetime import datetime, timezone
from types import SimpleNamespace

from shared import PermissionError, RequestContext
from shared.models import Project, ProjectStatus
from services.workspace_service.handlers.project_handler import ProjectHandler


class FakeRepo:
    """Fake repository for testing ProjectHandler."""

    def __init__(self):
        self.storage = {}
        self.last_update = None

    async def list(self, filters=None):
        return list(self.storage.values())

    async def create(self, project: Project):
        self.storage[project.id] = project
        return project

    async def get(self, project_id: str):
        if project_id not in self.storage:
            raise KeyError("Not found")
        return self.storage[project_id]

    async def update(self, project_id: str, **kwargs):
        proj = self.storage[project_id]
        for k, v in kwargs.items():
            setattr(proj, k, v)
        self.last_update = kwargs
        return proj


@pytest.fixture
def repo():
    return FakeRepo()


@pytest.fixture
def ctx():
    return RequestContext(tenant_id="tenant1", user_id="user1")


@pytest.fixture
def project(repo, ctx):
    proj = Project(
        id=str(uuid.uuid4()),
        name="Test Project",
        description="Desc",
        workspace_id="ws1",
        folder_id="f1",
        status=ProjectStatus.DRAFT,
        tenant_id=ctx.tenant_id,
        user_id=ctx.user_id,
        created_at=datetime.now(timezone.utc),
        updated_at=datetime.now(timezone.utc),
        updated_by=ctx.user_id,
        deleted_at="null",  # simulate not deleted
    )
    repo.storage[proj.id] = proj
    return proj


# ---- list_projects ----
@pytest.mark.asyncio
async def test_list_projects_filters_deleted(repo, project):
    project.deleted_at = "null"
    projects = await ProjectHandler.list_projects("ws1", repo)
    assert project in projects

    project.deleted_at = datetime.now(timezone.utc)
    projects = await ProjectHandler.list_projects("ws1", repo)
    assert project not in projects


# ---- create_project ----
@pytest.mark.asyncio
async def test_create_project(repo, ctx):
    req = SimpleNamespace(
        name="New Project",
        description="New Desc",
        workspace_id="ws1",
        folder_id="f1",
    )
    proj = await ProjectHandler.create_project(req, ctx, repo)
    assert proj.name == "New Project"
    assert proj.status == ProjectStatus.DRAFT
    assert proj.user_id == ctx.user_id
    assert proj.tenant_id == ctx.tenant_id
    assert proj.id in repo.storage


# ---- get_project ----
@pytest.mark.asyncio
async def test_get_project_success(repo, project):
    result = await ProjectHandler.get_project(project.id, repo)
    assert result == project


@pytest.mark.asyncio
async def test_get_project_deleted(repo, project):
    project.deleted_at = datetime.now(timezone.utc)
    with pytest.raises(Exception):  # ensure_project_not_deleted raises
        await ProjectHandler.get_project(project.id, repo)


# ---- update_project ----
@pytest.mark.asyncio
async def test_update_project_fields(repo, project, ctx):
    req = SimpleNamespace(name="Updated", description="Updated Desc", status="DRAFT")
    updated = await ProjectHandler.update_project(project.id, req, ctx, repo)
    assert updated.name == "Updated"
    assert updated.description == "Updated Desc"
    assert updated.status == ProjectStatus.DRAFT
    assert repo.last_update["updated_by"] == ctx.user_id


@pytest.mark.asyncio
async def test_update_project_deleted(repo, project, ctx):
    project.deleted_at = datetime.now(timezone.utc)
    req = SimpleNamespace(name="X", description="Y", status="DRAFT")
    with pytest.raises(Exception):
        await ProjectHandler.update_project(project.id, req, ctx, repo)


# ---- delete_project ----
@pytest.mark.asyncio
async def test_delete_project_success(repo, project, ctx):
    await ProjectHandler.delete_project(project.id, ctx, repo)
    assert isinstance(project.deleted_at, datetime)


@pytest.mark.asyncio
async def test_delete_project_not_owner(repo, project):
    ctx = RequestContext(tenant_id="tenant1", user_id="other")
    with pytest.raises(PermissionError):
        await ProjectHandler.delete_project(project.id, ctx, repo)


@pytest.mark.asyncio
async def test_delete_project_deleted(repo, project, ctx):
    project.deleted_at = datetime.now(timezone.utc)
    with pytest.raises(Exception):
        await ProjectHandler.delete_project(project.id, ctx, repo)


# ---- move_project ----
@pytest.mark.asyncio
async def test_move_project_success(repo, project, ctx):
    req = SimpleNamespace(folder_id="new_folder")
    moved = await ProjectHandler.move_project(project.id, req, ctx, repo)
    assert moved.folder_id == "new_folder"


@pytest.mark.asyncio
async def test_move_project_deleted(repo, project, ctx):
    project.deleted_at = datetime.now(timezone.utc)
    req = SimpleNamespace(folder_id="new_folder")
    with pytest.raises(Exception):
        await ProjectHandler.move_project(project.id, req, ctx, repo)

