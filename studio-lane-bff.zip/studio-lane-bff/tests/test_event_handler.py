import uuid
from datetime import UTC, datetime
from types import SimpleNamespace

import pytest
from fastapi import HTTPException

# ⚠️ Update this import path if needed
from services.conversation_service.handlers.event_handler import (
    EventHandler,
    event_handler,
)
from shared import NotFoundError
from shared.models import ChatSession, SessionEvent


class FakeRepo:
    """Generic async repository stub."""

    def __init__(self, get_result=None, list_result=None):
        self._get_result = get_result
        self._list_result = list_result or []
        self.created = None
        self.get_calls = []
        self.list_filters = None

    async def get(self, _id):
        self.get_calls.append(_id)
        return self._get_result

    async def list(self, filters=None):
        self.list_filters = filters
        return self._list_result

    async def create(self, obj):
        self.created = obj
        return obj


def build_session_event(session_id: str, event_type: str, payload: dict):
    """
    Build a SessionEvent instance while accommodating any required fields
    your Pydantic model might have (project_id, workspace_id, updated_at, etc.).
    """
    now = datetime.now(UTC)
    payload_dict = {
        "id": str(uuid.uuid4()),
        "session_id": session_id,
        "event_type": event_type,
        "payload": payload,
        "created_at": now,
    }

    # Future-proofing: include fields if your model defines them
    fields = getattr(SessionEvent, "model_fields", {})
    if "project_id" in fields:
        payload_dict["project_id"] = "proj"
    if "workspace_id" in fields:
        payload_dict["workspace_id"] = "ws"
    if "updated_at" in fields:
        payload_dict["updated_at"] = now

    return SessionEvent(**payload_dict)


@pytest.mark.asyncio
async def test_list_session_events_success():
    handler = EventHandler()

    session = ChatSession(
        id="sess-1",
        project_id="proj",
        workspace_id="ws",
        user_id="u1",
        title="Chat",
        created_at=datetime.now(UTC),
        updated_at=datetime.now(UTC),
    )

    events = [
        build_session_event("sess-1", "plan_created", {"plan": "P"}),
        build_session_event("sess-1", "task_started", {"task_id": "t1"}),
    ]

    session_repo = FakeRepo(get_result=session)
    event_repo = FakeRepo(list_result=events)

    ctx = SimpleNamespace(user_id="u1")

    result = await handler.list_session_events(
        session_id="sess-1",
        ctx=ctx,
        session_repo=session_repo,
        event_repo=event_repo,
    )

    assert result == events
    assert session_repo.get_calls == ["sess-1"]
    assert event_repo.list_filters == {"session_id": "sess-1"}


@pytest.mark.asyncio
async def test_list_session_events_not_found_none():
    handler = EventHandler()

    session_repo = FakeRepo(get_result=None)
    event_repo = FakeRepo()

    ctx = SimpleNamespace(user_id="u1")

    with pytest.raises(NotFoundError):
        await handler.list_session_events(
            session_id="missing",
            ctx=ctx,
            session_repo=session_repo,
            event_repo=event_repo,
        )


@pytest.mark.asyncio
async def test_list_session_events_wrong_user():
    handler = EventHandler()

    session = ChatSession(
        id="sess-1",
        project_id="proj",
        workspace_id="ws",
        user_id="other",
        title="Chat",
        created_at=datetime.now(UTC),
        updated_at=datetime.now(UTC),
    )

    session_repo = FakeRepo(get_result=session)
    event_repo = FakeRepo()
    ctx = SimpleNamespace(user_id="u1")

    with pytest.raises(NotFoundError):
        await handler.list_session_events(
            session_id="sess-1", ctx=ctx, session_repo=session_repo, event_repo=event_repo
        )


@pytest.mark.asyncio
async def test_create_session_event_success_for_all_valid_types():
    handler = EventHandler()

    session = ChatSession(
        id="sess-1",
        project_id="proj",
        workspace_id="ws",
        user_id="u1",
        title="Chat",
        created_at=datetime.now(UTC),
        updated_at=datetime.now(UTC),
    )
    session_repo = FakeRepo(get_result=session)
    event_repo = FakeRepo()

    ctx = SimpleNamespace(user_id="u1")

    valid_types = ["plan_created", "task_started", "task_completed", "code_generated", "error"]
    for et in valid_types:
        req = SimpleNamespace(event_type=et, payload={"k": "v"})
        created = await handler.create_session_event(
            session_id="sess-1",
            request=req,
            ctx=ctx,
            session_repo=session_repo,
            event_repo=event_repo,
        )
        # Repository should have been called to create
        assert event_repo.created is not None
        assert created is event_repo.created
        assert created.session_id == "sess-1"
        assert created.event_type == et
        assert getattr(created, "payload", None) == {"k": "v"}
        # created_at should be timezone aware
        assert created.created_at.tzinfo == UTC


@pytest.mark.asyncio
async def test_create_session_event_invalid_type_raises_http_400():
    handler = EventHandler()

    session = ChatSession(
        id="sess-1",
        project_id="proj",
        workspace_id="ws",
        user_id="u1",
        title="Chat",
        created_at=datetime.now(UTC),
        updated_at=datetime.now(UTC),
    )

    session_repo = FakeRepo(get_result=session)
    event_repo = FakeRepo()
    ctx = SimpleNamespace(user_id="u1")

    req = SimpleNamespace(event_type="unsupported_type", payload={"k": "v"})

    with pytest.raises(HTTPException) as excinfo:
        await handler.create_session_event(
            session_id="sess-1",
            request=req,
            ctx=ctx,
            session_repo=session_repo,
            event_repo=event_repo,
        )

    assert excinfo.value.status_code == 400
    assert "Invalid event_type" in excinfo.value.detail


@pytest.mark.asyncio
async def test_create_session_event_session_not_found_or_wrong_user():
    handler = EventHandler()

    # Case 1: session_repo returns None
    session_repo_none = FakeRepo(get_result=None)
    event_repo = FakeRepo()
    ctx = SimpleNamespace(user_id="u1")
    req = SimpleNamespace(event_type="plan_created", payload={})

    with pytest.raises(NotFoundError):
        await handler.create_session_event(
            session_id="missing",
            request=req,
            ctx=ctx,
            session_repo=session_repo_none,
            event_repo=event_repo,
        )

    # Case 2: session belongs to other user
    other_session = ChatSession(
        id="sess-1",
        project_id="proj",
        workspace_id="ws",
        user_id="other",
        title="Chat",
        created_at=datetime.now(UTC),
        updated_at=datetime.now(UTC),
    )
    session_repo_other = FakeRepo(get_result=other_session)

    with pytest.raises(NotFoundError):
        await handler.create_session_event(
            session_id="sess-1",
            request=req,
            ctx=ctx,
            session_repo=session_repo_other,
            event_repo=event_repo,
        )


def test_singleton_instance_exists():
    assert isinstance(event_handler, EventHandler)
