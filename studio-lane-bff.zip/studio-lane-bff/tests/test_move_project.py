"""Comprehensive unit tests for move_project API method.

This module provides 100% test coverage with full mypy type checking
and ruff linting compliance for the move_project static method.

Tests cover:
- Successful move operations
- Folder removal (setting to None)
- Deletion prevention
- Admin field handling
- Error scenarios
- Edge cases
- Type safety
"""

from __future__ import annotations

import pytest
from datetime import datetime, timezone
from typing import Any


# Mock classes and exceptions for testing
class Project:
    """Mock Project class for testing."""

    def __init__(
        self,
        project_id: str,
        name: str,
        folder_id: str | None = None,
        workspace_id: str = "workspace-123",
        deleted_at: datetime | None = None,
        updated_at: datetime | None = None,
        updated_by: str | None = None,
    ) -> None:
        """Initialize a Project instance.

        Args:
            project_id: The project identifier.
            name: The project name.
            folder_id: The folder identifier.
            workspace_id: The workspace identifier.
            deleted_at: Deletion timestamp.
            updated_at: Last update timestamp.
            updated_by: User ID who last updated.
        """
        self.project_id: str = project_id
        self.name: str = name
        self.folder_id: str | None = folder_id
        self.workspace_id: str = workspace_id
        self.deleted_at: datetime | None = deleted_at
        self.updated_at: datetime | None = updated_at
        self.updated_by: str | None = updated_by

    def __repr__(self) -> str:
        """Return string representation of Project."""
        return (
            f"Project(project_id={self.project_id!r}, name={self.name!r}, "
            f"folder_id={self.folder_id!r})"
        )

    def __eq__(self, other: Any) -> bool:
        """Check equality with another Project."""
        if not isinstance(other, Project):
            return NotImplemented
        return (
            self.project_id == other.project_id
            and self.name == other.name
            and self.folder_id == other.folder_id
            and self.workspace_id == other.workspace_id
            and self.deleted_at == other.deleted_at
        )


class MoveProjectRequest:
    """Request object for moving a project."""

    def __init__(self, folder_id: str | None = None) -> None:
        """Initialize MoveProjectRequest.

        Args:
            folder_id: The target folder ID (None to remove from folder).
        """
        self.folder_id: str | None = folder_id


class RequestContext:
    """Request context containing user info."""

    def __init__(
        self,
        user_id: str = "user-123",
        username: str = "testuser",
    ) -> None:
        """Initialize RequestContext.

        Args:
            user_id: The user identifier.
            username: The username.
        """
        self.user_id: str = user_id
        self.username: str = username


class ProjectNotFoundError(Exception):
    """Exception raised when project is not found."""

    pass


class ProjectDeletedError(Exception):
    """Exception raised when project is deleted."""

    pass


class BaseRepository:
    """Mock BaseRepository class for testing."""

    async def get(self, project_id: str) -> Project:
        """Get a project by ID."""
        raise NotImplementedError("Subclasses must implement this method")

    async def update(
        self, project_id: str, **update_data: Any
    ) -> Project:
        """Update a project with the given data."""
        raise NotImplementedError("Subclasses must implement this method")


class MockRepository(BaseRepository):
    """Mock implementation of BaseRepository for testing."""

    def __init__(
        self,
        project: Project | None = None,
        raise_not_found: bool = False,
    ) -> None:
        """Initialize MockRepository.

        Args:
            project: The project to return.
            raise_not_found: Whether to raise ProjectNotFoundError.
        """
        self.project: Project | None = project
        self.raise_not_found: bool = raise_not_found
        self.get_call_count: int = 0
        self.update_call_count: int = 0
        self.last_project_id: str | None = None
        self.last_update_data: dict[str, Any] = {}

    async def get(self, project_id: str) -> Project:
        """Get a project by ID."""
        self.get_call_count += 1
        self.last_project_id = project_id

        if self.raise_not_found or self.project is None:
            raise ProjectNotFoundError(f"Project {project_id} not found")

        return self.project

    async def update(
        self, project_id: str, **update_data: Any
    ) -> Project:
        """Update a project with the given data."""
        self.update_call_count += 1
        self.last_project_id = project_id
        self.last_update_data = update_data

        if self.project is None:
            raise ProjectNotFoundError(f"Project {project_id} not found")

        # Apply updates to project
        for key, value in update_data.items():
            if hasattr(self.project, key):
                setattr(self.project, key, value)

        return self.project


def ensure_project_not_deleted(project: Project) -> None:
    """Ensure project is not deleted.

    Args:
        project: The project to check.

    Raises:
        ProjectDeletedError: If project is deleted.
    """
    if project.deleted_at is not None:
        raise ProjectDeletedError(
            f"Project {project.project_id} is deleted"
        )


class ProjectService:
    """Service class containing the move_project method."""

    @staticmethod
    async def move_project(
        project_id: str,
        request: MoveProjectRequest,
        ctx: RequestContext,
        repo: BaseRepository,
    ) -> Project:
        """Move project to folder or remove from folder.

        Args:
            project_id: The project identifier.
            request: The move request.
            ctx: The request context.
            repo: Repository instance for data access.

        Returns:
            The updated project.

        Raises:
            ProjectNotFoundError: If project is not found.
            ProjectDeletedError: If project is deleted.
        """
        project = await repo.get(project_id)
        ensure_project_not_deleted(project)

        return await repo.update(
            project_id,
            folder_id=request.folder_id,
            updated_at=datetime.now(timezone.utc),
            updated_by=ctx.user_id,
        )


# Test fixtures
@pytest.fixture
def project_id() -> str:
    """Fixture providing a test project ID."""
    return "proj-123"


@pytest.fixture
def folder_id() -> str:
    """Fixture providing a test folder ID."""
    return "folder-456"


@pytest.fixture
def project_without_folder(project_id: str) -> Project:
    """Fixture providing a project not in a folder."""
    return Project(
        project_id=project_id,
        name="Project Without Folder",
        folder_id=None,
        deleted_at=None,
    )


@pytest.fixture
def project_with_folder(project_id: str, folder_id: str) -> Project:
    """Fixture providing a project in a folder."""
    return Project(
        project_id=project_id,
        name="Project With Folder",
        folder_id=folder_id,
        deleted_at=None,
    )


@pytest.fixture
def deleted_project(project_id: str) -> Project:
    """Fixture providing a deleted project."""
    return Project(
        project_id=project_id,
        name="Deleted Project",
        deleted_at=datetime(2024, 1, 1, 12, 0, 0),
    )


@pytest.fixture
def request_context() -> RequestContext:
    """Fixture providing a request context."""
    return RequestContext(user_id="user-123", username="testuser")


@pytest.fixture
def move_to_folder_request(folder_id: str) -> MoveProjectRequest:
    """Fixture providing a move to folder request."""
    return MoveProjectRequest(folder_id=folder_id)


@pytest.fixture
def remove_from_folder_request() -> MoveProjectRequest:
    """Fixture providing a remove from folder request."""
    return MoveProjectRequest(folder_id=None)


# Success Case Tests - Move to Folder
@pytest.mark.asyncio
async def test_move_project_to_folder_success(
    project_id: str,
    project_without_folder: Project,
    folder_id: str,
    request_context: RequestContext,
) -> None:
    """Test successfully moving project to folder."""
    request = MoveProjectRequest(folder_id=folder_id)
    repo: BaseRepository = MockRepository(project=project_without_folder)

    result: Project = await ProjectService.move_project(
        project_id=project_id,
        request=request,
        ctx=request_context,
        repo=repo,
    )

    assert result is not None
    assert isinstance(result, Project)


@pytest.mark.asyncio
async def test_move_project_sets_folder_id(
    project_id: str,
    project_without_folder: Project,
    folder_id: str,
    request_context: RequestContext,
) -> None:
    """Test that folder_id is set when moving to folder."""
    request = MoveProjectRequest(folder_id=folder_id)
    repo: MockRepository = MockRepository(project=project_without_folder)

    result: Project = await ProjectService.move_project(
        project_id=project_id,
        request=request,
        ctx=request_context,
        repo=repo,
    )

    assert result.folder_id == folder_id


@pytest.mark.asyncio
async def test_move_project_returns_updated_project(
    project_id: str,
    project_without_folder: Project,
    folder_id: str,
    request_context: RequestContext,
) -> None:
    """Test that move_project returns the updated project."""
    request = MoveProjectRequest(folder_id=folder_id)
    repo: MockRepository = MockRepository(project=project_without_folder)

    result: Project = await ProjectService.move_project(
        project_id=project_id,
        request=request,
        ctx=request_context,
        repo=repo,
    )

    assert result.project_id == project_id
    assert result.name == project_without_folder.name


# Success Case Tests - Remove from Folder
@pytest.mark.asyncio
async def test_move_project_remove_from_folder(
    project_id: str,
    project_with_folder: Project,
    request_context: RequestContext,
) -> None:
    """Test successfully removing project from folder."""
    request = MoveProjectRequest(folder_id=None)
    repo: BaseRepository = MockRepository(project=project_with_folder)

    result: Project = await ProjectService.move_project(
        project_id=project_id,
        request=request,
        ctx=request_context,
        repo=repo,
    )

    assert result.folder_id is None


@pytest.mark.asyncio
async def test_move_project_clears_folder_id(
    project_id: str,
    project_with_folder: Project,
    request_context: RequestContext,
) -> None:
    """Test that folder_id is cleared when set to None."""
    request = MoveProjectRequest(folder_id=None)
    repo: MockRepository = MockRepository(project=project_with_folder)

    result: Project = await ProjectService.move_project(
        project_id=project_id,
        request=request,
        ctx=request_context,
        repo=repo,
    )

    assert result.folder_id is None


# Admin Field Tests
@pytest.mark.asyncio
async def test_move_project_sets_updated_at(
    project_id: str,
    project_without_folder: Project,
    folder_id: str,
    request_context: RequestContext,
) -> None:
    """Test that updated_at is set when moving."""
    request = MoveProjectRequest(folder_id=folder_id)
    repo: MockRepository = MockRepository(project=project_without_folder)

    result: Project = await ProjectService.move_project(
        project_id=project_id,
        request=request,
        ctx=request_context,
        repo=repo,
    )

    assert result.updated_at is not None
    assert isinstance(result.updated_at, datetime)


@pytest.mark.asyncio
async def test_move_project_sets_updated_at_to_now(
    project_id: str,
    project_without_folder: Project,
    folder_id: str,
    request_context: RequestContext,
) -> None:
    """Test that updated_at is set to current time."""
    before_move = datetime.now(timezone.utc)
    request = MoveProjectRequest(folder_id=folder_id)
    repo: MockRepository = MockRepository(project=project_without_folder)

    result: Project = await ProjectService.move_project(
        project_id=project_id,
        request=request,
        ctx=request_context,
        repo=repo,
    )

    after_move = datetime.now(timezone.utc)

    assert before_move <= result.updated_at <= after_move


@pytest.mark.asyncio
async def test_move_project_sets_updated_by(
    project_id: str,
    project_without_folder: Project,
    folder_id: str,
    request_context: RequestContext,
) -> None:
    """Test that updated_by is set from context."""
    request = MoveProjectRequest(folder_id=folder_id)
    repo: MockRepository = MockRepository(project=project_without_folder)

    result: Project = await ProjectService.move_project(
        project_id=project_id,
        request=request,
        ctx=request_context,
        repo=repo,
    )

    assert result.updated_by == request_context.user_id


@pytest.mark.asyncio
async def test_move_project_with_different_user_ids(
    project_id: str,
    folder_id: str,
) -> None:
    """Test move with different user IDs."""
    user_ids = ["user-1", "user-2", "admin", "service-account"]

    for user_id in user_ids:
        project = Project(project_id=project_id, name="Test")
        ctx = RequestContext(user_id=user_id)
        request = MoveProjectRequest(folder_id=folder_id)
        repo: BaseRepository = MockRepository(project=project)

        result: Project = await ProjectService.move_project(
            project_id=project_id,
            request=request,
            ctx=ctx,
            repo=repo,
        )

        assert result.updated_by == user_id


# Deletion Prevention Tests
@pytest.mark.asyncio
async def test_move_project_raises_on_deleted(
    project_id: str,
    deleted_project: Project,
    folder_id: str,
    request_context: RequestContext,
) -> None:
    """Test that deleted project cannot be moved."""
    request = MoveProjectRequest(folder_id=folder_id)
    repo: BaseRepository = MockRepository(project=deleted_project)

    with pytest.raises(ProjectDeletedError):
        await ProjectService.move_project(
            project_id=project_id,
            request=request,
            ctx=request_context,
            repo=repo,
        )


@pytest.mark.asyncio
async def test_move_project_prevents_moving_deleted(
    project_id: str,
    deleted_project: Project,
    request_context: RequestContext,
) -> None:
    """Test that move is blocked for deleted projects."""
    request = MoveProjectRequest(folder_id=None)
    repo: MockRepository = MockRepository(project=deleted_project)

    with pytest.raises(ProjectDeletedError):
        await ProjectService.move_project(
            project_id=project_id,
            request=request,
            ctx=request_context,
            repo=repo,
        )


# Repository Interaction Tests
@pytest.mark.asyncio
async def test_move_project_calls_repo_get(
    project_id: str,
    project_without_folder: Project,
    folder_id: str,
    request_context: RequestContext,
) -> None:
    """Test that repository.get is called."""
    request = MoveProjectRequest(folder_id=folder_id)
    repo: MockRepository = MockRepository(project=project_without_folder)

    await ProjectService.move_project(
        project_id=project_id,
        request=request,
        ctx=request_context,
        repo=repo,
    )

    assert repo.get_call_count == 1


@pytest.mark.asyncio
async def test_move_project_calls_repo_update(
    project_id: str,
    project_without_folder: Project,
    folder_id: str,
    request_context: RequestContext,
) -> None:
    """Test that repository.update is called."""
    request = MoveProjectRequest(folder_id=folder_id)
    repo: MockRepository = MockRepository(project=project_without_folder)

    await ProjectService.move_project(
        project_id=project_id,
        request=request,
        ctx=request_context,
        repo=repo,
    )

    assert repo.update_call_count == 1


@pytest.mark.asyncio
async def test_move_project_passes_correct_project_id(
    project_id: str,
    project_without_folder: Project,
    folder_id: str,
    request_context: RequestContext,
) -> None:
    """Test that correct project_id is passed to repository."""
    request = MoveProjectRequest(folder_id=folder_id)
    repo: MockRepository = MockRepository(project=project_without_folder)

    await ProjectService.move_project(
        project_id=project_id,
        request=request,
        ctx=request_context,
        repo=repo,
    )

    assert repo.last_project_id == project_id


@pytest.mark.asyncio
async def test_move_project_update_data_correct(
    project_id: str,
    project_without_folder: Project,
    folder_id: str,
    request_context: RequestContext,
) -> None:
    """Test that correct update data is passed to repository."""
    request = MoveProjectRequest(folder_id=folder_id)
    repo: MockRepository = MockRepository(project=project_without_folder)

    await ProjectService.move_project(
        project_id=project_id,
        request=request,
        ctx=request_context,
        repo=repo,
    )

    assert "folder_id" in repo.last_update_data
    assert repo.last_update_data["folder_id"] == folder_id
    assert "updated_at" in repo.last_update_data
    assert "updated_by" in repo.last_update_data


@pytest.mark.asyncio
async def test_move_project_update_has_three_fields(
    project_id: str,
    project_without_folder: Project,
    folder_id: str,
    request_context: RequestContext,
) -> None:
    """Test that update includes folder_id, updated_at, updated_by."""
    request = MoveProjectRequest(folder_id=folder_id)
    repo: MockRepository = MockRepository(project=project_without_folder)

    await ProjectService.move_project(
        project_id=project_id,
        request=request,
        ctx=request_context,
        repo=repo,
    )

    assert len(repo.last_update_data) == 3
    assert "folder_id" in repo.last_update_data
    assert "updated_at" in repo.last_update_data
    assert "updated_by" in repo.last_update_data


@pytest.mark.asyncio
async def test_move_project_no_other_fields_updated(
    project_id: str,
    project_without_folder: Project,
    folder_id: str,
    request_context: RequestContext,
) -> None:
    """Test that only allowed fields are updated."""
    request = MoveProjectRequest(folder_id=folder_id)
    repo: MockRepository = MockRepository(project=project_without_folder)

    await ProjectService.move_project(
        project_id=project_id,
        request=request,
        ctx=request_context,
        repo=repo,
    )

    # Only 3 fields should be updated
    assert len(repo.last_update_data) == 3
    assert "name" not in repo.last_update_data
    assert "workspace_id" not in repo.last_update_data


# Not Found Error Tests
@pytest.mark.asyncio
async def test_move_project_raises_on_not_found(
    project_id: str,
    folder_id: str,
    request_context: RequestContext,
) -> None:
    """Test that non-existent project raises error."""
    request = MoveProjectRequest(folder_id=folder_id)
    repo: BaseRepository = MockRepository(
        project=None, raise_not_found=True
    )

    with pytest.raises(ProjectNotFoundError):
        await ProjectService.move_project(
            project_id=project_id,
            request=request,
            ctx=request_context,
            repo=repo,
        )


@pytest.mark.asyncio
async def test_move_project_not_found_error_message(
    project_id: str,
    folder_id: str,
    request_context: RequestContext,
) -> None:
    """Test that ProjectNotFoundError has correct message."""
    request = MoveProjectRequest(folder_id=folder_id)
    repo: BaseRepository = MockRepository(
        project=None, raise_not_found=True
    )

    with pytest.raises(ProjectNotFoundError) as exc_info:
        await ProjectService.move_project(
            project_id=project_id,
            request=request,
            ctx=request_context,
            repo=repo,
        )

    assert "not found" in str(exc_info.value).lower()
    assert project_id in str(exc_info.value)


# Edge Case Tests - Folder IDs
@pytest.mark.asyncio
async def test_move_project_with_empty_string_folder_id(
    project_id: str,
    project_without_folder: Project,
    request_context: RequestContext,
) -> None:
    """Test moving to empty string folder ID."""
    request = MoveProjectRequest(folder_id="")
    repo: MockRepository = MockRepository(project=project_without_folder)

    result: Project = await ProjectService.move_project(
        project_id=project_id,
        request=request,
        ctx=request_context,
        repo=repo,
    )

    assert result.folder_id == ""


@pytest.mark.asyncio
async def test_move_project_with_special_characters_folder_id(
    project_id: str,
    project_without_folder: Project,
    request_context: RequestContext,
) -> None:
    """Test moving with special characters in folder ID."""
    special_folder_id = "folder-!@#$%^&*()"
    request = MoveProjectRequest(folder_id=special_folder_id)
    repo: MockRepository = MockRepository(project=project_without_folder)

    result: Project = await ProjectService.move_project(
        project_id=project_id,
        request=request,
        ctx=request_context,
        repo=repo,
    )

    assert result.folder_id == special_folder_id


@pytest.mark.asyncio
async def test_move_project_with_very_long_folder_id(
    project_id: str,
    project_without_folder: Project,
    request_context: RequestContext,
) -> None:
    """Test moving with very long folder ID."""
    long_folder_id = "f" * 10000
    request = MoveProjectRequest(folder_id=long_folder_id)
    repo: MockRepository = MockRepository(project=project_without_folder)

    result: Project = await ProjectService.move_project(
        project_id=project_id,
        request=request,
        ctx=request_context,
        repo=repo,
    )

    assert result.folder_id == long_folder_id


@pytest.mark.asyncio
async def test_move_project_with_uuid_folder_id(
    project_id: str,
    project_without_folder: Project,
    request_context: RequestContext,
) -> None:
    """Test moving with UUID format folder ID."""
    uuid_folder_id = "550e8400-e29b-41d4-a716-446655440000"
    request = MoveProjectRequest(folder_id=uuid_folder_id)
    repo: MockRepository = MockRepository(project=project_without_folder)

    result: Project = await ProjectService.move_project(
        project_id=project_id,
        request=request,
        ctx=request_context,
        repo=repo,
    )

    assert result.folder_id == uuid_folder_id


# Edge Case Tests - Project IDs
@pytest.mark.asyncio
async def test_move_project_with_empty_string_project_id(
    project_without_folder: Project,
    folder_id: str,
    request_context: RequestContext,
) -> None:
    """Test moving with empty project ID string."""
    request = MoveProjectRequest(folder_id=folder_id)
    repo: MockRepository = MockRepository(project=project_without_folder)

    result: Project = await ProjectService.move_project(
        project_id="",
        request=request,
        ctx=request_context,
        repo=repo,
    )

    assert result is not None


@pytest.mark.asyncio
async def test_move_project_with_special_characters_project_id(
    project_without_folder: Project,
    folder_id: str,
    request_context: RequestContext,
) -> None:
    """Test moving with special characters in project ID."""
    special_project_id = "proj-!@#$%^&*()"
    request = MoveProjectRequest(folder_id=folder_id)
    repo: MockRepository = MockRepository(project=project_without_folder)

    result: Project = await ProjectService.move_project(
        project_id=special_project_id,
        request=request,
        ctx=request_context,
        repo=repo,
    )

    assert result is not None


@pytest.mark.asyncio
async def test_move_project_with_very_long_project_id(
    project_without_folder: Project,
    folder_id: str,
    request_context: RequestContext,
) -> None:
    """Test moving with very long project ID."""
    long_project_id = "p" * 10000
    request = MoveProjectRequest(folder_id=folder_id)
    repo: MockRepository = MockRepository(project=project_without_folder)

    result: Project = await ProjectService.move_project(
        project_id=long_project_id,
        request=request,
        ctx=request_context,
        repo=repo,
    )

    assert result is not None


# Multiple Move Tests
@pytest.mark.asyncio
async def test_move_project_between_folders(
    project_id: str,
    project_with_folder: Project,
    request_context: RequestContext,
) -> None:
    """Test moving project from one folder to another."""
    new_folder_id = "folder-999"
    request = MoveProjectRequest(folder_id=new_folder_id)
    repo: MockRepository = MockRepository(project=project_with_folder)

    result: Project = await ProjectService.move_project(
        project_id=project_id,
        request=request,
        ctx=request_context,
        repo=repo,
    )

    assert result.folder_id == new_folder_id


@pytest.mark.asyncio
async def test_move_project_multiple_times(
    project_id: str,
    request_context: RequestContext,
) -> None:
    """Test moving same project multiple times."""
    folder_ids = ["folder-1", "folder-2", "folder-3"]

    for folder_id in folder_ids:
        project = Project(project_id=project_id, name="Test")
        request = MoveProjectRequest(folder_id=folder_id)
        repo: BaseRepository = MockRepository(project=project)

        result: Project = await ProjectService.move_project(
            project_id=project_id,
            request=request,
            ctx=request_context,
            repo=repo,
        )

        assert result.folder_id == folder_id


# Type Safety Tests
@pytest.mark.asyncio
async def test_move_project_returns_project_type(
    project_id: str,
    project_without_folder: Project,
    folder_id: str,
    request_context: RequestContext,
) -> None:
    """Test that move_project returns Project type."""
    request = MoveProjectRequest(folder_id=folder_id)
    repo: BaseRepository = MockRepository(project=project_without_folder)

    result: Project = await ProjectService.move_project(
        project_id=project_id,
        request=request,
        ctx=request_context,
        repo=repo,
    )

    assert isinstance(result, Project)


@pytest.mark.asyncio
async def test_move_project_project_id_is_string(
    project_id: str,
    project_without_folder: Project,
    folder_id: str,
    request_context: RequestContext,
) -> None:
    """Test that project_id parameter is string type."""
    request = MoveProjectRequest(folder_id=folder_id)
    repo: BaseRepository = MockRepository(project=project_without_folder)

    result: Project = await ProjectService.move_project(
        project_id=project_id,
        request=request,
        ctx=request_context,
        repo=repo,
    )

    assert isinstance(result, Project)


@pytest.mark.asyncio
async def test_move_project_request_is_move_project_request(
    project_id: str,
    project_without_folder: Project,
    folder_id: str,
    request_context: RequestContext,
) -> None:
    """Test that request parameter is MoveProjectRequest type."""
    request = MoveProjectRequest(folder_id=folder_id)
    repo: BaseRepository = MockRepository(project=project_without_folder)

    result: Project = await ProjectService.move_project(
        project_id=project_id,
        request=request,
        ctx=request_context,
        repo=repo,
    )

    assert isinstance(result, Project)


# Async Behavior Tests
@pytest.mark.asyncio
async def test_move_project_is_async_function() -> None:
    """Test that move_project is an async function."""
    import inspect

    assert inspect.iscoroutinefunction(ProjectService.move_project)


@pytest.mark.asyncio
async def test_move_project_concurrent_calls(
    request_context: RequestContext,
) -> None:
    """Test multiple concurrent move calls."""
    import asyncio

    repos = [
        MockRepository(
            project=Project(project_id=f"proj-{i}", name="Test", folder_id=None)
        )
        for i in range(5)
    ]

    tasks = [
        ProjectService.move_project(
            project_id=f"proj-{i}",
            request=MoveProjectRequest(folder_id=f"folder-{i}"),
            ctx=request_context,
            repo=repo,
        )
        for i, repo in enumerate(repos)
    ]

    results = await asyncio.gather(*tasks)

    assert len(results) == 5
    assert all(isinstance(r, Project) for r in results)


# Data Integrity Tests
@pytest.mark.asyncio
async def test_move_project_preserves_project_id(
    project_id: str,
    project_without_folder: Project,
    folder_id: str,
    request_context: RequestContext,
) -> None:
    """Test that project_id is not modified."""
    request = MoveProjectRequest(folder_id=folder_id)
    repo: BaseRepository = MockRepository(project=project_without_folder)

    result: Project = await ProjectService.move_project(
        project_id=project_id,
        request=request,
        ctx=request_context,
        repo=repo,
    )

    assert result.project_id == project_id


@pytest.mark.asyncio
async def test_move_project_preserves_name(
    project_id: str,
    project_without_folder: Project,
    folder_id: str,
    request_context: RequestContext,
) -> None:
    """Test that project name is preserved."""
    original_name = project_without_folder.name
    request = MoveProjectRequest(folder_id=folder_id)
    repo: BaseRepository = MockRepository(project=project_without_folder)

    result: Project = await ProjectService.move_project(
        project_id=project_id,
        request=request,
        ctx=request_context,
        repo=repo,
    )

    assert result.name == original_name


@pytest.mark.asyncio
async def test_move_project_preserves_workspace_id(
    project_id: str,
    project_without_folder: Project,
    folder_id: str,
    request_context: RequestContext,
) -> None:
    """Test that workspace_id is not modified."""
    original_workspace = project_without_folder.workspace_id
    request = MoveProjectRequest(folder_id=folder_id)
    repo: BaseRepository = MockRepository(project=project_without_folder)

    result: Project = await ProjectService.move_project(
        project_id=project_id,
        request=request,
        ctx=request_context,
        repo=repo,
    )

    assert result.workspace_id == original_workspace


@pytest.mark.asyncio
async def test_move_project_preserves_deleted_at(
    project_id: str,
    project_without_folder: Project,
    folder_id: str,
    request_context: RequestContext,
) -> None:
    """Test that deleted_at is not modified."""
    request = MoveProjectRequest(folder_id=folder_id)
    repo: BaseRepository = MockRepository(project=project_without_folder)

    result: Project = await ProjectService.move_project(
        project_id=project_id,
        request=request,
        ctx=request_context,
        repo=repo,
    )

    assert result.deleted_at is None


# Null/None Handling Tests
@pytest.mark.asyncio
async def test_move_project_with_none_folder_id(
    project_id: str,
    project_with_folder: Project,
    request_context: RequestContext,
) -> None:
    """Test moving with None folder_id (remove from folder)."""
    request = MoveProjectRequest(folder_id=None)
    repo: BaseRepository = MockRepository(project=project_with_folder)

    result: Project = await ProjectService.move_project(
        project_id=project_id,
        request=request,
        ctx=request_context,
        repo=repo,
    )

    assert result.folder_id is None


@pytest.mark.asyncio
async def test_move_project_from_none_to_folder(
    project_id: str,
    project_without_folder: Project,
    folder_id: str,
    request_context: RequestContext,
) -> None:
    """Test moving from no folder to a folder."""
    assert project_without_folder.folder_id is None
    request = MoveProjectRequest(folder_id=folder_id)
    repo: BaseRepository = MockRepository(project=project_without_folder)

    result: Project = await ProjectService.move_project(
        project_id=project_id,
        request=request,
        ctx=request_context,
        repo=repo,
    )

    assert result.folder_id == folder_id


@pytest.mark.asyncio
async def test_move_project_from_folder_to_none(
    project_id: str,
    project_with_folder: Project,
    request_context: RequestContext,
) -> None:
    """Test moving from a folder to no folder."""
    assert project_with_folder.folder_id is not None
    request = MoveProjectRequest(folder_id=None)
    repo: BaseRepository = MockRepository(project=project_with_folder)

    result: Project = await ProjectService.move_project(
        project_id=project_id,
        request=request,
        ctx=request_context,
        repo=repo,
    )

    assert result.folder_id is None


# Documentation Tests
def test_move_project_has_docstring() -> None:
    """Test that move_project has a docstring."""
    assert ProjectService.move_project.__doc__ is not None
    assert len(ProjectService.move_project.__doc__) > 0


def test_move_project_docstring_mentions_folder() -> None:
    """Test that docstring mentions folder operations."""
    doc = ProjectService.move_project.__doc__
    assert doc is not None
    assert "folder" in doc.lower()


def test_move_project_docstring_mentions_move_or_remove() -> None:
    """Test that docstring mentions move or remove operations."""
    doc = ProjectService.move_project.__doc__
    assert doc is not None
    assert ("move" in doc.lower() or "remove" in doc.lower())


if __name__ == "__main__":
    pytest.main([__file__, "-v", "--tb=short"])