"""Tests for project delete endpoint."""

import uuid
from datetime import datetime, timezone

import pytest
from fastapi.testclient import TestClient

from services.studio_gateway_api.main import create_app
from shared.auth import get_request_context
from shared.context import RequestContext
from shared.cosmosdb import get_cosmosdb
from shared.models import Project, ProjectStatus
from tests.inmemory_cosmos import InMemoryCosmosDBClient


@pytest.fixture
def owner_context() -> RequestContext:
    """Create a RequestContext with Owner role."""
    return RequestContext(
        tenant_id="test-tenant",
        user_id="owner-user",
        roles={"Owner"},
        session_id="test-session",
        correlation_id=str(uuid.uuid4()),
    )


@pytest.fixture
def project_owner_context() -> RequestContext:
    """Create a RequestContext for project owner."""
    return RequestContext(
        tenant_id="test-tenant",
        user_id="project-owner",
        roles={"Owner"},
        session_id="test-session",
        correlation_id=str(uuid.uuid4()),
    )


@pytest.fixture
def other_user_context() -> RequestContext:
    """Create a RequestContext for different user."""
    return RequestContext(
        tenant_id="test-tenant",
        user_id="other-user",
        roles={"Owner"},
        session_id="test-session",
        correlation_id=str(uuid.uuid4()),
    )


@pytest.fixture
def delete_client(cosmos_client, project_owner_context, monkeypatch):
    """Create test client with project owner context."""
    monkeypatch.setenv("REQUIRE_AUTH_GLOBALLY", "false")

    app = create_app()

    async def override_get_cosmosdb():
        return cosmos_client

    async def override_get_request_context():
        return project_owner_context

    app.dependency_overrides[get_cosmosdb] = override_get_cosmosdb
    app.dependency_overrides[get_request_context] = override_get_request_context

    with TestClient(app) as client:
        yield client, cosmos_client, project_owner_context


@pytest.fixture
def other_user_client(cosmos_client, other_user_context, monkeypatch):
    """Create test client with different user context."""
    monkeypatch.setenv("REQUIRE_AUTH_GLOBALLY", "false")

    app = create_app()

    async def override_get_cosmosdb():
        return cosmos_client

    async def override_get_request_context():
        return other_user_context

    app.dependency_overrides[get_cosmosdb] = override_get_cosmosdb
    app.dependency_overrides[get_request_context] = override_get_request_context

    with TestClient(app) as client:
        yield client


def test_delete_project_success(delete_client):
    """Test successfully deleting a project (soft delete)."""
    client, cosmos, ctx = delete_client

    # Create a project
    create_resp = client.post(
        "/api/v1/studio/workspaces/projects",
        json={
            "name": "Test Project",
            "description": "Test Description",
            "workspace_id": "workspace-123",
        },
    )
    assert create_resp.status_code == 201
    project_id = create_resp.json()["data"]["id"]

    # Delete the project
    delete_resp = client.delete(f"/api/v1/studio/workspaces/projects/{project_id}")
    assert delete_resp.status_code == 204

    # Verify project is soft deleted (not found via get)
    get_resp = client.get(f"/api/v1/studio/workspaces/projects/{project_id}")
    assert get_resp.status_code == 404

    # Verify project is filtered from list
    list_resp = client.get("/api/v1/studio/workspaces/workspace-123/projects")
    assert list_resp.status_code == 200
    projects = list_resp.json()["data"]
    assert len(projects) == 0


def test_delete_project_not_found(delete_client):
    """Test deleting a non-existent project."""
    client, _, _ = delete_client

    fake_id = str(uuid.uuid4())
    delete_resp = client.delete(f"/api/v1/studio/workspaces/projects/{fake_id}")
    assert delete_resp.status_code == 404


def test_delete_project_already_deleted(delete_client):
    """Test deleting an already deleted project."""
    client, cosmos, ctx = delete_client

    # Create and delete a project
    create_resp = client.post(
        "/api/v1/studio/workspaces/projects",
        json={
            "name": "Test Project",
            "description": "Test Description",
            "workspace_id": "workspace-123",
        },
    )
    project_id = create_resp.json()["data"]["id"]
    client.delete(f"/api/v1/studio/workspaces/projects/{project_id}")

    # Try to delete again
    delete_resp = client.delete(f"/api/v1/studio/workspaces/projects/{project_id}")
    assert delete_resp.status_code == 404


def test_delete_project_other_user(delete_client, other_user_client):
    """Test that only project owner can delete project."""
    client, _, _ = delete_client
    other_client = other_user_client

    # Create a project as project owner
    create_resp = client.post(
        "/api/v1/studio/workspaces/projects",
        json={
            "name": "Test Project",
            "description": "Test Description",
            "workspace_id": "workspace-123",
        },
    )
    project_id = create_resp.json()["data"]["id"]

    # Try to delete as different user (should fail)
    delete_resp = other_client.delete(f"/api/v1/studio/workspaces/projects/{project_id}")
    assert delete_resp.status_code == 403 or delete_resp.status_code == 404


def test_list_projects_excludes_deleted(delete_client):
    """Test that list_projects excludes soft-deleted projects."""
    client, _, _ = delete_client

    # Create multiple projects
    project_ids = []
    for i in range(3):
        create_resp = client.post(
            "/api/v1/studio/workspaces/projects",
            json={
                "name": f"Project {i}",
                "description": f"Description {i}",
                "workspace_id": "workspace-123",
            },
        )
        project_ids.append(create_resp.json()["data"]["id"])

    # List projects (should have 3)
    list_resp = client.get("/api/v1/studio/workspaces/workspace-123/projects")
    assert len(list_resp.json()["data"]) == 3

    # Delete one project
    client.delete(f"/api/v1/studio/workspaces/projects/{project_ids[0]}")

    # List projects (should have 2)
    list_resp = client.get("/api/v1/studio/workspaces/workspace-123/projects")
    assert len(list_resp.json()["data"]) == 2
    remaining_ids = [p["id"] for p in list_resp.json()["data"]]
    assert project_ids[0] not in remaining_ids
    assert project_ids[1] in remaining_ids
    assert project_ids[2] in remaining_ids


def test_update_project_after_delete_fails(delete_client):
    """Test that updating a deleted project fails."""
    client, _, _ = delete_client

    # Create and delete a project
    create_resp = client.post(
        "/api/v1/studio/workspaces/projects",
        json={
            "name": "Test Project",
            "description": "Test Description",
            "workspace_id": "workspace-123",
        },
    )
    project_id = create_resp.json()["data"]["id"]
    client.delete(f"/api/v1/studio/workspaces/projects/{project_id}")

    # Try to update
    update_resp = client.patch(
        f"/api/v1/studio/workspaces/projects/{project_id}",
        json={"name": "Updated Name"},
    )
    assert update_resp.status_code == 404


