"""
Comprehensive unit tests for get_profile method.
Standalone runner - no external dependencies required.
Tests all code paths with 100% coverage.
"""

import asyncio
from datetime import datetime, timezone
from typing import Optional
from unittest.mock import AsyncMock, MagicMock

# ============================================================================
# Mock Classes
# ============================================================================


class UserProfile:
    """Mock UserProfile class."""

    def __init__(
        self,
        id: str,
        email: str,
        created_at: datetime,
        updated_at: datetime,
    ):
        self.id = id
        self.email = email
        self.created_at = created_at
        self.updated_at = updated_at

    def __eq__(self, other):
        if not isinstance(other, UserProfile):
            return False
        return (
            self.id == other.id
            and self.email == other.email
            and self.created_at == other.created_at
            and self.updated_at == other.updated_at
        )

    def __repr__(self):
        return f"UserProfile(id={self.id}, email={self.email})"


class RequestContext:
    """Mock RequestContext class."""

    def __init__(self, user_id: str):
        self.user_id = user_id


class BaseRepository:
    """Mock BaseRepository class."""

    async def get(self, user_id: str) -> Optional[UserProfile]:
        """Retrieve a user profile by ID."""
        pass

    async def create(self, profile: UserProfile) -> UserProfile:
        """Create a new user profile."""
        pass


# ============================================================================
# Function Under Test
# ============================================================================


async def get_profile(
    ctx: RequestContext,
    repo: BaseRepository,
) -> UserProfile:
    """Get current user profile."""
    # Try to get existing profile
    profile = await repo.get(ctx.user_id)

    if profile:
        return profile

    # Create new profile if doesn't exist
    # In production, profile should be created during first login
    new_profile = UserProfile(
        id=ctx.user_id,
        email=f"{ctx.user_id}@temenos.com",  # Placeholder
        created_at=datetime.now(timezone.utc),
        updated_at=datetime.now(timezone.utc),
    )
    return await repo.create(new_profile)


# ============================================================================
# Test Utilities
# ============================================================================


class TestResult:
    def __init__(self, name: str, passed: bool, error: str = None):
        self.name = name
        self.passed = passed
        self.error = error

    def __str__(self):
        status = "✓ PASS" if self.passed else "✗ FAIL"
        msg = f"{status}: {self.name}"
        if self.error:
            msg += f"\n  Error: {self.error}"
        return msg


class TestRunner:
    def __init__(self):
        self.results = []
        self.passed_count = 0
        self.failed_count = 0

    async def run_test(self, test_name: str, test_func):
        """Run a single test and track results."""
        try:
            await test_func()
            result = TestResult(test_name, True)
            self.passed_count += 1
        except AssertionError as e:
            result = TestResult(test_name, False, str(e))
            self.failed_count += 1
        except Exception as e:
            result = TestResult(test_name, False, f"Unexpected error: {str(e)}")
            self.failed_count += 1

        self.results.append(result)
        print(result)

    def print_summary(self):
        """Print test summary."""
        total = self.passed_count + self.failed_count
        print("\n" + "="*70)
        print(f"Test Summary: {self.passed_count}/{total} tests passed")
        print("="*70)
        if self.failed_count > 0:
            print(f"\n⚠️  {self.failed_count} test(s) failed")
            return False
        else:
            print("\n✓ All tests passed!")
            return True


# ============================================================================
# Test Cases - Existing Profile Retrieval
# ============================================================================


async def test_get_profile_returns_existing_profile():
    """Test that an existing profile is returned without creating a new one."""
    ctx = RequestContext(user_id="user123")
    repo = AsyncMock(spec=BaseRepository)

    existing_profile = UserProfile(
        id="user123",
        email="user123@example.com",
        created_at=datetime(2024, 1, 1, 10, 0, 0),
        updated_at=datetime(2024, 1, 1, 10, 0, 0),
    )
    repo.get.return_value = existing_profile

    result = await get_profile(ctx, repo)

    assert result == existing_profile, "Should return existing profile"
    assert result.id == "user123", "Profile ID should match"
    assert result.email == "user123@example.com", "Profile email should match"
    assert repo.get.called, "repo.get should be called"
    assert not repo.create.called, "repo.create should not be called"


async def test_get_profile_existing_profile_preserves_data():
    """Test that existing profile data is preserved exactly."""
    ctx = RequestContext(user_id="user456")
    repo = AsyncMock(spec=BaseRepository)

    original_profile = UserProfile(
        id="user456",
        email="original@custom.com",
        created_at=datetime(2023, 6, 15, 14, 30, 45),
        updated_at=datetime(2024, 1, 20, 9, 15, 30),
    )
    repo.get.return_value = original_profile

    result = await get_profile(ctx, repo)

    assert result.id == original_profile.id, "ID should match"
    assert result.email == original_profile.email, "Email should match"
    assert result.created_at == original_profile.created_at, "created_at should match"
    assert result.updated_at == original_profile.updated_at, "updated_at should match"


async def test_get_profile_calls_get_with_correct_user_id():
    """Test that get is called with the correct user ID."""
    test_user_id = "test_user_xyz"
    ctx = RequestContext(user_id=test_user_id)
    repo = AsyncMock(spec=BaseRepository)

    existing_profile = UserProfile(
        id=test_user_id,
        email="test@test.com",
        created_at=datetime.now(timezone.utc),
        updated_at=datetime.now(timezone.utc),
    )
    repo.get.return_value = existing_profile

    await get_profile(ctx, repo)

    # Verify get was called with correct user_id
    assert repo.get.called, "repo.get should be called"
    call_args = repo.get.call_args
    assert call_args[0][0] == test_user_id, "get should be called with correct user_id"


async def test_get_profile_existing_profile_no_create_call():
    """Test that create is not called when profile exists."""
    ctx = RequestContext(user_id="user123")
    repo = AsyncMock(spec=BaseRepository)

    existing_profile = UserProfile(
        id="user123",
        email="user123@example.com",
        created_at=datetime.now(timezone.utc),
        updated_at=datetime.now(timezone.utc),
    )
    repo.get.return_value = existing_profile

    result = await get_profile(ctx, repo)

    assert result is not None, "Result should not be None"
    assert not repo.create.called, "repo.create should not be called"


# ============================================================================
# Test Cases - New Profile Creation
# ============================================================================


async def test_get_profile_creates_new_profile_when_not_found():
    """Test that a new profile is created when no existing profile is found."""
    ctx = RequestContext(user_id="user123")
    repo = AsyncMock(spec=BaseRepository)

    repo.get.return_value = None
    new_profile = UserProfile(
        id="user123",
        email="user123@temenos.com",
        created_at=datetime(2024, 1, 1, 10, 0, 0),
        updated_at=datetime(2024, 1, 1, 10, 0, 0),
    )
    repo.create.return_value = new_profile

    result = await get_profile(ctx, repo)

    assert result is not None, "Result should not be None"
    assert result.id == "user123", "Profile ID should be correct"
    assert result.email == "user123@temenos.com", "Profile email should be correct"
    assert repo.create.called, "repo.create should be called"


async def test_get_profile_new_profile_correct_id():
    """Test that the new profile is created with the correct user ID."""
    ctx = RequestContext(user_id="new_user_abc")
    repo = AsyncMock(spec=BaseRepository)

    repo.get.return_value = None
    created_profile = UserProfile(
        id="new_user_abc",
        email="new_user_abc@temenos.com",
        created_at=datetime.now(timezone.utc),
        updated_at=datetime.now(timezone.utc),
    )
    repo.create.return_value = created_profile

    result = await get_profile(ctx, repo)

    assert result.id == "new_user_abc", "Profile ID should match context user_id"


async def test_get_profile_new_profile_email_format():
    """Test that the new profile has the correct email format."""
    ctx = RequestContext(user_id="john_doe")
    repo = AsyncMock(spec=BaseRepository)

    repo.get.return_value = None
    created_profile = UserProfile(
        id="john_doe",
        email="john_doe@temenos.com",
        created_at=datetime.now(timezone.utc),
        updated_at=datetime.now(timezone.utc),
    )
    repo.create.return_value = created_profile

    result = await get_profile(ctx, repo)

    assert result.email == "john_doe@temenos.com", "Email should follow format: {user_id}@temenos.com"
    assert "@temenos.com" in result.email, "Email should contain @temenos.com domain"
    assert result.email.startswith("john_doe"), "Email should start with user_id"


async def test_get_profile_new_profile_has_timestamps():
    """Test that the new profile has created_at and updated_at timestamps."""
    ctx = RequestContext(user_id="user123")
    repo = AsyncMock(spec=BaseRepository)

    repo.get.return_value = None
    now = datetime(2024, 1, 15, 12, 0, 0)
    created_profile = UserProfile(
        id="user123",
        email="user123@temenos.com",
        created_at=now,
        updated_at=now,
    )
    repo.create.return_value = created_profile

    result = await get_profile(ctx, repo)

    assert result.created_at is not None, "created_at should not be None"
    assert result.updated_at is not None, "updated_at should not be None"
    assert isinstance(result.created_at, datetime), "created_at should be datetime"
    assert isinstance(result.updated_at, datetime), "updated_at should be datetime"


async def test_get_profile_timestamps_equal_for_new_profile():
    """Test that created_at and updated_at are equal for new profiles."""
    ctx = RequestContext(user_id="user123")
    repo = AsyncMock(spec=BaseRepository)

    repo.get.return_value = None
    now = datetime.now(timezone.utc)
    created_profile = UserProfile(
        id="user123",
        email="user123@temenos.com",
        created_at=now,
        updated_at=now,
    )
    repo.create.return_value = created_profile

    result = await get_profile(ctx, repo)

    assert result.created_at == result.updated_at, "created_at should equal updated_at for new profile"


async def test_get_profile_get_called_before_create():
    """Test that repo.get is called before repo.create."""
    ctx = RequestContext(user_id="user123")
    repo = AsyncMock(spec=BaseRepository)

    repo.get.return_value = None
    created_profile = UserProfile(
        id="user123",
        email="user123@temenos.com",
        created_at=datetime.now(timezone.utc),
        updated_at=datetime.now(timezone.utc),
    )
    repo.create.return_value = created_profile

    await get_profile(ctx, repo)

    assert repo.get.called, "repo.get should be called"
    assert repo.create.called, "repo.create should be called"
    # Note: We can't directly check call order with AsyncMock in simple way,
    # but logic ensures it through the if statement


async def test_get_profile_returns_created_profile():
    """Test that the profile returned from create is returned to the caller."""
    ctx = RequestContext(user_id="user123")
    repo = AsyncMock(spec=BaseRepository)

    repo.get.return_value = None
    created_profile = UserProfile(
        id="user123",
        email="user123@temenos.com",
        created_at=datetime.now(timezone.utc),
        updated_at=datetime.now(timezone.utc),
    )
    repo.create.return_value = created_profile

    result = await get_profile(ctx, repo)

    assert result is created_profile, "Should return the profile from repo.create"


# ============================================================================
# Test Cases - Edge Cases and Special Scenarios
# ============================================================================


async def test_get_profile_special_characters_in_user_id():
    """Test that special characters in user_id are handled correctly."""
    special_user_id = "user@domain.com"
    ctx = RequestContext(user_id=special_user_id)
    repo = AsyncMock(spec=BaseRepository)

    repo.get.return_value = None
    created_profile = UserProfile(
        id=special_user_id,
        email=f"{special_user_id}@temenos.com",
        created_at=datetime.now(timezone.utc),
        updated_at=datetime.now(timezone.utc),
    )
    repo.create.return_value = created_profile

    result = await get_profile(ctx, repo)

    assert result.email == f"{special_user_id}@temenos.com", "Special characters should be preserved in email"


async def test_get_profile_numeric_user_id():
    """Test that numeric user IDs are handled correctly."""
    numeric_user_id = "12345"
    ctx = RequestContext(user_id=numeric_user_id)
    repo = AsyncMock(spec=BaseRepository)

    repo.get.return_value = None
    created_profile = UserProfile(
        id=numeric_user_id,
        email=f"{numeric_user_id}@temenos.com",
        created_at=datetime.now(timezone.utc),
        updated_at=datetime.now(timezone.utc),
    )
    repo.create.return_value = created_profile

    result = await get_profile(ctx, repo)

    assert result.id == "12345", "Numeric user_id should be preserved"
    assert result.email == "12345@temenos.com", "Numeric user_id should be used in email"


async def test_get_profile_empty_string_user_id():
    """Test that empty string user IDs are handled."""
    ctx = RequestContext(user_id="")
    repo = AsyncMock(spec=BaseRepository)

    repo.get.return_value = None
    created_profile = UserProfile(
        id="",
        email="@temenos.com",
        created_at=datetime.now(timezone.utc),
        updated_at=datetime.now(timezone.utc),
    )
    repo.create.return_value = created_profile

    result = await get_profile(ctx, repo)

    assert result.id == "", "Empty user_id should be preserved"
    assert result.email == "@temenos.com", "Empty user_id should result in @temenos.com email"


async def test_get_profile_very_long_user_id():
    """Test that very long user IDs are handled correctly."""
    long_user_id = "a" * 1000
    ctx = RequestContext(user_id=long_user_id)
    repo = AsyncMock(spec=BaseRepository)

    repo.get.return_value = None
    created_profile = UserProfile(
        id=long_user_id,
        email=f"{long_user_id}@temenos.com",
        created_at=datetime.now(timezone.utc),
        updated_at=datetime.now(timezone.utc),
    )
    repo.create.return_value = created_profile

    result = await get_profile(ctx, repo)

    assert result.id == long_user_id, "Long user_id should be preserved"
    assert len(result.email) > 1000, "Long user_id should result in long email"


async def test_get_profile_multiple_calls_same_existing_user():
    """Test multiple calls for the same user that exists."""
    ctx = RequestContext(user_id="user123")
    repo = AsyncMock(spec=BaseRepository)

    existing_profile = UserProfile(
        id="user123",
        email="user123@example.com",
        created_at=datetime.now(timezone.utc),
        updated_at=datetime.now(timezone.utc),
    )
    repo.get.return_value = existing_profile

    result1 = await get_profile(ctx, repo)
    result2 = await get_profile(ctx, repo)

    assert result1 == result2, "Multiple calls should return same profile"
    assert repo.get.call_count == 2, "repo.get should be called twice"
    assert repo.create.call_count == 0, "repo.create should not be called"


async def test_get_profile_multiple_calls_different_users():
    """Test multiple calls for different users."""
    repo = AsyncMock(spec=BaseRepository)

    user1_profile = UserProfile(
        id="user1",
        email="user1@example.com",
        created_at=datetime.now(timezone.utc),
        updated_at=datetime.now(timezone.utc),
    )
    user2_profile = UserProfile(
        id="user2",
        email="user2@temenos.com",
        created_at=datetime.now(timezone.utc),
        updated_at=datetime.now(timezone.utc),
    )

    # Set side effects for sequential calls
    repo.get.side_effect = [user1_profile, user2_profile]

    ctx1 = RequestContext(user_id="user1")
    ctx2 = RequestContext(user_id="user2")

    result1 = await get_profile(ctx1, repo)
    result2 = await get_profile(ctx2, repo)

    assert result1.id == "user1", "First result should have user1 ID"
    assert result2.id == "user2", "Second result should have user2 ID"
    assert result1 != result2, "Results should be different"


async def test_get_profile_none_return_triggers_create():
    """Test that None return from get triggers profile creation."""
    ctx = RequestContext(user_id="user123")
    repo = AsyncMock(spec=BaseRepository)

    repo.get.return_value = None
    repo.create.return_value = UserProfile(
        id="user123",
        email="user123@temenos.com",
        created_at=datetime.now(timezone.utc),
        updated_at=datetime.now(timezone.utc),
    )

    result = await get_profile(ctx, repo)

    assert result is not None, "Result should not be None"
    assert repo.get.called, "repo.get should be called"
    assert repo.create.called, "repo.create should be called"


async def test_get_profile_return_type_existing():
    """Test that the return type is always UserProfile (existing)."""
    ctx = RequestContext(user_id="user123")
    repo = AsyncMock(spec=BaseRepository)

    existing_profile = UserProfile(
        id="user123",
        email="user123@example.com",
        created_at=datetime.now(timezone.utc),
        updated_at=datetime.now(timezone.utc),
    )
    repo.get.return_value = existing_profile

    result = await get_profile(ctx, repo)

    assert isinstance(result, UserProfile), "Return type should be UserProfile"


async def test_get_profile_return_type_new():
    """Test that the return type is UserProfile even when creating new."""
    ctx = RequestContext(user_id="user123")
    repo = AsyncMock(spec=BaseRepository)

    repo.get.return_value = None
    created_profile = UserProfile(
        id="user123",
        email="user123@temenos.com",
        created_at=datetime.now(timezone.utc),
        updated_at=datetime.now(timezone.utc),
    )
    repo.create.return_value = created_profile

    result = await get_profile(ctx, repo)

    assert isinstance(result, UserProfile), "Return type should be UserProfile"


# ============================================================================
# Integration Tests
# ============================================================================


async def test_integration_existing_user_workflow():
    """Integration test: Existing user retrieval workflow."""
    repo = AsyncMock(spec=BaseRepository)

    user_profile = UserProfile(
        id="integration_user",
        email="integration_user@company.com",
        created_at=datetime(2024, 1, 1, 10, 0, 0),
        updated_at=datetime(2024, 1, 1, 10, 0, 0),
    )
    repo.get.return_value = user_profile
    ctx = RequestContext(user_id="integration_user")

    result = await get_profile(ctx, repo)

    assert result == user_profile, "Should return the exact profile"
    assert result.id == "integration_user", "ID should match"
    assert not repo.create.called, "repo.create should not be called for existing user"


async def test_integration_new_user_workflow():
    """Integration test: New user creation workflow."""
    repo = AsyncMock(spec=BaseRepository)

    repo.get.return_value = None
    ctx = RequestContext(user_id="new_user")
    new_profile = UserProfile(
        id="new_user",
        email="new_user@temenos.com",
        created_at=datetime.now(timezone.utc),
        updated_at=datetime.now(timezone.utc),
    )
    repo.create.return_value = new_profile

    result = await get_profile(ctx, repo)

    assert result == new_profile, "Should return the new profile"
    assert result.id == "new_user", "ID should be correct"
    assert result.email == "new_user@temenos.com", "Email should be correct"
    assert repo.get.called, "repo.get should be called"
    assert repo.create.called, "repo.create should be called"


async def test_integration_sequential_calls():
    """Integration test: Sequential calls with different outcomes."""
    repo = AsyncMock(spec=BaseRepository)

    existing_profile = UserProfile(
        id="user1",
        email="user1@example.com",
        created_at=datetime.now(timezone.utc),
        updated_at=datetime.now(timezone.utc),
    )
    new_profile = UserProfile(
        id="user2",
        email="user2@temenos.com",
        created_at=datetime.now(timezone.utc),
        updated_at=datetime.now(timezone.utc),
    )

    # Setup mock for sequential calls
    repo.get.side_effect = [existing_profile, None]
    repo.create.return_value = new_profile

    # First call: existing user
    ctx1 = RequestContext(user_id="user1")
    result1 = await get_profile(ctx1, repo)

    # Second call: new user
    ctx2 = RequestContext(user_id="user2")
    result2 = await get_profile(ctx2, repo)

    assert result1 == existing_profile, "First result should be existing profile"
    assert result2 == new_profile, "Second result should be new profile"
    assert result1.id != result2.id, "User IDs should be different"


# ============================================================================
# Main Test Runner
# ============================================================================


async def main():
    """Run all tests."""
    runner = TestRunner()

    # Test list - all test functions
    tests = [
        # Existing profile tests
        ("test_get_profile_returns_existing_profile", test_get_profile_returns_existing_profile),
        ("test_get_profile_existing_profile_preserves_data", test_get_profile_existing_profile_preserves_data),
        ("test_get_profile_calls_get_with_correct_user_id", test_get_profile_calls_get_with_correct_user_id),
        ("test_get_profile_existing_profile_no_create_call", test_get_profile_existing_profile_no_create_call),

        # New profile creation tests
        ("test_get_profile_creates_new_profile_when_not_found", test_get_profile_creates_new_profile_when_not_found),
        ("test_get_profile_new_profile_correct_id", test_get_profile_new_profile_correct_id),
        ("test_get_profile_new_profile_email_format", test_get_profile_new_profile_email_format),
        ("test_get_profile_new_profile_has_timestamps", test_get_profile_new_profile_has_timestamps),
        ("test_get_profile_timestamps_equal_for_new_profile", test_get_profile_timestamps_equal_for_new_profile),
        ("test_get_profile_get_called_before_create", test_get_profile_get_called_before_create),
        ("test_get_profile_returns_created_profile", test_get_profile_returns_created_profile),

        # Edge cases
        ("test_get_profile_special_characters_in_user_id", test_get_profile_special_characters_in_user_id),
        ("test_get_profile_numeric_user_id", test_get_profile_numeric_user_id),
        ("test_get_profile_empty_string_user_id", test_get_profile_empty_string_user_id),
        ("test_get_profile_very_long_user_id", test_get_profile_very_long_user_id),
        ("test_get_profile_multiple_calls_same_existing_user", test_get_profile_multiple_calls_same_existing_user),
        ("test_get_profile_multiple_calls_different_users", test_get_profile_multiple_calls_different_users),
        ("test_get_profile_none_return_triggers_create", test_get_profile_none_return_triggers_create),
        ("test_get_profile_return_type_existing", test_get_profile_return_type_existing),
        ("test_get_profile_return_type_new", test_get_profile_return_type_new),

        # Integration tests
        ("test_integration_existing_user_workflow", test_integration_existing_user_workflow),
        ("test_integration_new_user_workflow", test_integration_new_user_workflow),
        ("test_integration_sequential_calls", test_integration_sequential_calls),
    ]

    print("\n" + "="*70)
    print("Running Unit Tests for get_profile()")
    print("="*70 + "\n")

    # Run all tests
    for test_name, test_func in tests:
        await runner.run_test(test_name, test_func)

    # Print summary
    success = runner.print_summary()
    return 0 if success else 1


if __name__ == "__main__":
    exit_code = asyncio.run(main())
    exit(exit_code)