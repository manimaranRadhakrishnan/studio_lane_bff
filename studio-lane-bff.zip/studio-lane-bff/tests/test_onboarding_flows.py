"""Tests for onboarding and create flows: ensure project (Untitled), standalone gen-runs."""

import uuid
from unittest.mock import AsyncMock, MagicMock, patch

import pytest
from fastapi.testclient import TestClient

from services.studio_gateway_api.main import create_app
from shared.auth import get_request_context
from shared.context import RequestContext
from shared.cosmosdb import get_cosmosdb
from tests.inmemory_cosmos import InMemoryCosmosDBClient


@pytest.fixture
def onboarding_context() -> RequestContext:
    """RequestContext for onboarding/create flow tests."""
    return RequestContext(
        tenant_id="tenant-onboarding",
        user_id="user-1",
        roles={"Owner", "Editor"},
        session_id=str(uuid.uuid4()),
        correlation_id=str(uuid.uuid4()),
    )


@pytest.fixture
def onboarding_client(cosmos_client, onboarding_context, monkeypatch):
    """Test client with onboarding context."""
    monkeypatch.setenv("REQUIRE_AUTH_GLOBALLY", "false")
    app = create_app()

    async def override_get_cosmosdb():
        return cosmos_client

    async def override_get_request_context():
        return onboarding_context

    app.dependency_overrides[get_cosmosdb] = override_get_cosmosdb
    app.dependency_overrides[get_request_context] = override_get_request_context

    with TestClient(app) as client:
        yield client


def test_create_project_ensure_untitled_returns_existing_or_creates(onboarding_client):
    """
    Onboarding/create flow: POST /projects with name='Untitled' (ensure semantics).
    First call creates a project; second call with same tenant returns same or latest Untitled.
    """
    client = onboarding_client

    # First call: create Untitled project
    r1 = client.post("/api/v1/studio/projects", json={"name": "Untitled"})
    assert r1.status_code == 201
    data1 = r1.json().get("data") or r1.json()
    assert data1["name"] == "Untitled"
    assert "id" in data1
    project_id_1 = data1["id"]

    # Second call (ensure semantics): BFF returns existing latest Untitled or creates new
    r2 = client.post("/api/v1/studio/projects", json={"name": "Untitled"})
    assert r2.status_code == 201
    data2 = r2.json().get("data") or r2.json()
    assert data2["name"] == "Untitled"
    assert "id" in data2
    # Ensure semantics: same project returned when one already exists for tenant
    assert data2["id"] == project_id_1, "ensure semantics should return existing Untitled"


def test_list_projects_empty_then_after_create(onboarding_client):
    """GET /projects: empty when no projects; after creating one, list returns it."""
    client = onboarding_client

    list_empty = client.get("/api/v1/studio/projects")
    assert list_empty.status_code == 200
    payload = list_empty.json().get("data") if isinstance(list_empty.json(), dict) else list_empty.json()
    projects = payload if isinstance(payload, list) else []
    assert len(projects) == 0

    client.post("/api/v1/studio/projects", json={"name": "Untitled"})

    list_after = client.get("/api/v1/studio/projects")
    assert list_after.status_code == 200
    payload_after = list_after.json().get("data") if isinstance(list_after.json(), dict) else list_after.json()
    projects_after = payload_after if isinstance(payload_after, list) else []
    assert len(projects_after) >= 1
    names = [p.get("name") for p in projects_after]
    assert "Untitled" in names
