"""Tests for message persistence in chat endpoints."""

import uuid
from unittest.mock import AsyncMock, MagicMock, patch

import pytest
from fastapi.testclient import TestClient

from services.studio_gateway_api.main import create_app
from shared.auth import get_request_context
from shared.context import RequestContext
from shared.cosmosdb import get_cosmosdb
from tests.inmemory_cosmos import InMemoryCosmosDBClient


@pytest.fixture
def chat_context() -> RequestContext:
    """Create a RequestContext for chat operations."""
    return RequestContext(
        tenant_id="test-tenant",
        user_id="chat-user",
        roles={"Owner", "Editor"},
        session_id="test-session",
        correlation_id=str(uuid.uuid4()),
    )


@pytest.fixture
def chat_client(cosmos_client, chat_context, monkeypatch):
    """Create test client for chat operations."""
    monkeypatch.setenv("REQUIRE_AUTH_GLOBALLY", "false")

    app = create_app()

    async def override_get_cosmosdb():
        return cosmos_client

    async def override_get_request_context():
        return chat_context

    app.dependency_overrides[get_cosmosdb] = override_get_cosmosdb
    app.dependency_overrides[get_request_context] = override_get_request_context

    with TestClient(app) as client:
        yield client


def test_chat_persists_messages(chat_client):
    """Test that chat endpoint persists user and assistant messages."""
    client = chat_client

    # Create a session
    session_resp = client.post(
        "/api/v1/studio/conversations/sessions",
        json={
            "project_id": "project-123",
            "workspace_id": "workspace-123",
            "title": "Test Session",
        },
    )
    assert session_resp.status_code == 201
    session_id = session_resp.json()["data"]["id"]

    # Mock GenAI client response
    mock_gen_response = {
        "response": "This is a test response from GenAI",
        "genRunId": "gen-run-123",
    }

    with patch("services.conversation_service.handlers.gen_run_handler.GenClient") as mock_gen_client_class:
        mock_client_instance = MagicMock()
        mock_client_instance.prompt_to_code = AsyncMock(return_value=mock_gen_response)
        mock_client_instance.close = AsyncMock()
        mock_gen_client_class.return_value = mock_client_instance

        # Send gen run request (consolidated chat/prompt-to-code)
        chat_resp = client.post(
            f"/api/v1/studio/conversations/sessions/{session_id}/gen-runs",
            json={
                "prompt_text": "Hello, this is a test message",
                "project_id": "project-123",
            },
        )
        assert chat_resp.status_code == 200

    # Verify messages were persisted
    messages_resp = client.get(f"/api/v1/studio/conversations/sessions/{session_id}/messages")
    assert messages_resp.status_code == 200
    messages = messages_resp.json()["data"]

    # Should have user message and assistant message
    assert len(messages) == 2
    user_messages = [m for m in messages if m["role"] == "user"]
    assistant_messages = [m for m in messages if m["role"] == "assistant"]
    assert len(user_messages) == 1
    assert len(assistant_messages) == 1
    assert user_messages[0]["content"] == "Hello, this is a test message"
    assert assistant_messages[0]["content"] == "This is a test response from GenAI"


def test_gen_runs_persists_messages(chat_client):
    """Test that gen-runs endpoint persists user prompt and assistant response."""
    client = chat_client

    # Create a session
    session_resp = client.post(
        "/api/v1/studio/conversations/sessions",
        json={
            "project_id": "project-123",
            "workspace_id": "workspace-123",
            "title": "Test Session",
        },
    )
    session_id = session_resp.json()["data"]["id"]

    # Mock GenAI client response
    mock_gen_response = {
        "response": "Generated code here",
        "genRunId": "gen-run-456",
    }

    with patch("services.conversation_service.handlers.gen_run_handler.GenClient") as mock_gen_client_class:
        mock_client_instance = MagicMock()
        mock_client_instance.prompt_to_code = AsyncMock(return_value=mock_gen_response)
        mock_client_instance.close = AsyncMock()
        mock_gen_client_class.return_value = mock_client_instance

        # Send gen-runs request
        prompt_resp = client.post(
            f"/api/v1/studio/conversations/sessions/{session_id}/gen-runs",
            json={
                "prompt_text": "Create a button component",
                "project_id": "project-123",
            },
        )
        assert prompt_resp.status_code == 200

    # Verify messages were persisted
    messages_resp = client.get(f"/api/v1/studio/conversations/sessions/{session_id}/messages")
    assert messages_resp.status_code == 200
    messages = messages_resp.json()["data"]

    # Should have user prompt and assistant response
    assert len(messages) == 2
    user_messages = [m for m in messages if m["role"] == "user"]
    assistant_messages = [m for m in messages if m["role"] == "assistant"]
    assert len(user_messages) == 1
    assert len(assistant_messages) == 1
    assert user_messages[0]["content"] == "Create a button component"
    assert assistant_messages[0]["content"] == "Generated code here"


def test_chat_updates_session_timestamp(chat_client):
    """Test that chat endpoint updates session updated_at timestamp."""
    client = chat_client

    # Create a session
    session_resp = client.post(
        "/api/v1/studio/conversations/sessions",
        json={
            "project_id": "project-123",
            "workspace_id": "workspace-123",
            "title": "Test Session",
        },
    )
    session_id = session_resp.json()["data"]["id"]
    original_updated_at = session_resp.json()["data"]["updated_at"]

    # Mock GenAI client
    mock_gen_response = {"response": "Test response"}

    with patch("services.conversation_service.handlers.gen_run_handler.GenClient") as mock_gen_client_class:
        mock_client_instance = MagicMock()
        mock_client_instance.prompt_to_code = AsyncMock(return_value=mock_gen_response)
        mock_client_instance.close = AsyncMock()
        mock_gen_client_class.return_value = mock_client_instance

        # Send gen-runs request
        client.post(
            f"/api/v1/studio/conversations/sessions/{session_id}/gen-runs",
            json={"prompt_text": "Test", "project_id": "project-123"},
        )

    # Get session and verify updated_at changed
    get_session_resp = client.get(f"/api/v1/studio/conversations/sessions/{session_id}")
    assert get_session_resp.status_code == 200
    # Note: In fast tests, timestamps might be same, but we verify the field exists
    assert "updated_at" in get_session_resp.json()["data"]


def test_chat_handles_genai_error_gracefully(chat_client):
    """Test that chat endpoint handles GenAI errors gracefully."""
    client = chat_client

    # Create a session
    session_resp = client.post(
        "/api/v1/studio/conversations/sessions",
        json={
            "project_id": "project-123",
            "workspace_id": "workspace-123",
            "title": "Test Session",
        },
    )
    session_id = session_resp.json()["data"]["id"]

    # Mock GenAI client to raise error
    with patch("services.conversation_service.handlers.gen_run_handler.GenClient") as mock_gen_client_class:
        mock_client_instance = MagicMock()
        mock_client_instance.prompt_to_code = AsyncMock(side_effect=Exception("GenAI error"))
        mock_client_instance.close = AsyncMock()
        mock_gen_client_class.return_value = mock_client_instance

        # Send gen-runs request (should still persist user message even if GenAI fails)
        chat_resp = client.post(
            f"/api/v1/studio/conversations/sessions/{session_id}/gen-runs",
            json={"prompt_text": "Test message", "project_id": "project-123"},
        )
        # Should return error status
        assert chat_resp.status_code >= 400

    # User message should still be persisted
    messages_resp = client.get(f"/api/v1/studio/conversations/sessions/{session_id}/messages")
    if messages_resp.status_code == 200:
        messages = messages_resp.json()["data"]
        user_messages = [m for m in messages if m["role"] == "user"]
        # User message may or may not be persisted depending on error handling
        # This test verifies the endpoint doesn't crash


# ----- Standalone gen-runs (no session_id): onboarding / create flow -----


def test_standalone_gen_runs_creates_session_and_starts_run(chat_client):
    """When session_id is not given, BFF creates a session and starts gen run (onboarding/create flow)."""
    client = chat_client

    mock_gen_response = {
        "response": "Generated UI from prompt",
        "genRunId": "gen-run-standalone-1",
    }

    with patch("services.conversation_service.handlers.gen_run_handler.GenClient") as mock_gen_client_class:
        mock_client_instance = MagicMock()
        mock_client_instance.prompt_to_code = AsyncMock(return_value=mock_gen_response)
        mock_client_instance.close = AsyncMock()
        mock_gen_client_class.return_value = mock_client_instance

        # No session_id in path — BFF must create session then start gen run
        resp = client.post(
            "/api/v1/studio/conversations/gen-runs",
            json={
                "prompt_text": "Create a login screen with email and password",
                "project_id": "project-onboarding-1",
            },
        )
    assert resp.status_code == 200
    data = resp.json().get("data") or resp.json()
    assert data.get("genRunId") == "gen-run-standalone-1"

    # Session should have been created; list sessions and find one for this project
    sessions_resp = client.get("/api/v1/studio/conversations/sessions")
    assert sessions_resp.status_code == 200
    sessions = sessions_resp.json().get("data") or sessions_resp.json()
    project_sessions = [s for s in sessions if s.get("project_id") == "project-onboarding-1"]
    assert len(project_sessions) >= 1
    session_id = project_sessions[0]["id"]

    # Messages should be persisted in the created session
    messages_resp = client.get(f"/api/v1/studio/conversations/sessions/{session_id}/messages")
    assert messages_resp.status_code == 200
    messages = messages_resp.json().get("data") or messages_resp.json()
    user_messages = [m for m in messages if m.get("role") == "user"]
    assistant_messages = [m for m in messages if m.get("role") == "assistant"]
    assert len(user_messages) >= 1
    assert user_messages[0]["content"] == "Create a login screen with email and password"
    assert len(assistant_messages) >= 1
    assert assistant_messages[0]["content"] == "Generated UI from prompt"


def test_standalone_gen_runs_requires_project_id(chat_client):
    """Standalone gen-runs returns 400 when project_id is missing."""
    client = chat_client

    resp = client.post(
        "/api/v1/studio/conversations/gen-runs",
        json={"prompt_text": "Build a button"},
    )
    assert resp.status_code == 400
    assert "project_id" in (resp.json().get("detail") or str(resp.json())).lower()


