"""Comprehensive unit tests for list_projects API.

This module provides 100% test coverage with full mypy type checking
and ruff linting compliance for the list_projects static method.

Fixed version: Uses module-level async test functions instead of class methods
to avoid pytest-asyncio signature validation issues.
"""

from __future__ import annotations

import asyncio
import inspect
import pytest
from datetime import datetime, timezone
from typing import Any
from enum import Enum


class ProjectStatus(str, Enum):
    """Project status enumeration."""

    ACTIVE = "active"
    INACTIVE = "inactive"
    ARCHIVED = "archived"


class Project:
    """Mock Project class for testing."""

    def __init__(
        self,
        project_id: str,
        name: str,
        description: str = "Default description",
        status: ProjectStatus = ProjectStatus.ACTIVE,
        workspace_id: str = "workspace-123",
        deleted_at: datetime | None = None,
        updated_at: datetime | None = None,
        updated_by: str | None = None,
    ) -> None:
        """Initialize a Project instance.

        Args:
            project_id: The project identifier.
            name: The project name.
            description: The project description.
            status: The project status.
            workspace_id: The workspace identifier.
            deleted_at: Deletion timestamp.
            updated_at: Last update timestamp.
            updated_by: User ID who last updated.
        """
        self.project_id: str = project_id
        self.name: str = name
        self.description: str = description
        self.status: ProjectStatus = status
        self.workspace_id: str = workspace_id
        self.deleted_at: datetime | None = deleted_at
        self.updated_at: datetime | None = updated_at
        self.updated_by: str | None = updated_by

    def __repr__(self) -> str:
        """Return string representation of Project."""
        return (
            f"Project(project_id={self.project_id!r}, name={self.name!r}, "
            f"description={self.description!r}, status={self.status!r})"
        )

    def __eq__(self, other: Any) -> bool:
        """Check equality with another Project."""
        if not isinstance(other, Project):
            return NotImplemented
        return (
            self.project_id == other.project_id
            and self.name == other.name
            and self.description == other.description
            and self.status == other.status
            and self.workspace_id == other.workspace_id
            and self.deleted_at == other.deleted_at
        )


class UpdateProjectRequest:
    """Request object for updating a project."""

    def __init__(
        self,
        name: str | None = None,
        description: str | None = None,
        status: str | ProjectStatus | None = None,
    ) -> None:
        """Initialize UpdateProjectRequest.

        Args:
            name: New project name (optional).
            description: New project description (optional).
            status: New project status (optional).
        """
        self.name: str | None = name
        self.description: str | None = description
        self.status: str | ProjectStatus | None = status


class RequestContext:
    """Request context containing user info."""

    def __init__(
        self,
        user_id: str = "user-123",
        username: str = "testuser",
    ) -> None:
        """Initialize RequestContext.

        Args:
            user_id: The user identifier.
            username: The username.
        """
        self.user_id: str = user_id
        self.username: str = username


class ProjectNotFoundError(Exception):
    """Exception raised when project is not found."""

    pass


class ProjectDeletedError(Exception):
    """Exception raised when project is deleted."""

    pass


class BaseRepository:
    """Mock BaseRepository class for testing."""

    async def get(self, project_id: str) -> Project:
        """Get a project by ID."""
        raise NotImplementedError("Subclasses must implement this method")

    async def update(
        self, project_id: str, **update_data: Any
    ) -> Project:
        """Update a project with the given data."""
        raise NotImplementedError("Subclasses must implement this method")


class MockRepository(BaseRepository):
    """Mock implementation of BaseRepository for testing."""

    def __init__(
        self,
        project: Project | None = None,
        raise_not_found: bool = False,
    ) -> None:
        """Initialize MockRepository.

        Args:
            project: The project to return.
            raise_not_found: Whether to raise ProjectNotFoundError.
        """
        self.project: Project | None = project
        self.raise_not_found: bool = raise_not_found
        self.get_call_count: int = 0
        self.update_call_count: int = 0
        self.last_project_id: str | None = None
        self.last_update_data: dict[str, Any] = {}

# Mock classes for testing
class Project:
    """Mock Project class for testing."""

    def __init__(
        self,
        workspace_id: str,
        project_id: str,
        name: str,
        deleted_at: datetime | None = None,
    ) -> None:
        """Initialize a Project instance.

        Args:
            workspace_id: The workspace identifier.
            project_id: The project identifier.
            name: The project name.
            deleted_at: Deletion timestamp (None if not deleted).
        """
        self.workspace_id: str = workspace_id
        self.project_id: str = project_id
        self.name: str = name
        self.deleted_at: datetime | None = deleted_at

    def __repr__(self) -> str:
        """Return string representation of Project."""
        return (
            f"Project(workspace_id={self.workspace_id!r}, "
            f"project_id={self.project_id!r}, name={self.name!r}, "
            f"deleted_at={self.deleted_at!r})"
        )

    def __eq__(self, other: Any) -> bool:
        """Check equality with another Project."""
        if not isinstance(other, Project):
            return NotImplemented
        return (
            self.workspace_id == other.workspace_id
            and self.project_id == other.project_id
            and self.name == other.name
            and self.deleted_at == other.deleted_at
        )


class BaseRepository:
    """Mock BaseRepository class for testing."""

    async def list(self, filters: dict[str, Any] | None = None) -> list[Project]:
        """List projects with optional filters.

        Args:
            filters: Dictionary of filter conditions.

        Returns:
            List of projects matching filters.
        """
        raise NotImplementedError("Subclasses must implement this method")


class MockRepository(BaseRepository):
    """Mock implementation of BaseRepository for testing."""

    def __init__(self, projects: list[Project] | None = None) -> None:
        """Initialize MockRepository.

        Args:
            projects: List of projects to return.
        """
        self.projects: list[Project] = projects or []
        self.list_call_count: int = 0
        self.last_filters: dict[str, Any] | None = None

    async def list(
        self, filters: dict[str, Any] | None = None
    ) -> list[Project]:
        """List projects with optional filters.

        Args:
            filters: Dictionary of filter conditions.

        Returns:
            List of all projects (filters applied externally in test).
        """
        self.list_call_count += 1
        self.last_filters = filters
        return self.projects.copy()


class ProjectService:
    """Service class containing the list_projects method."""

    @staticmethod
    async def list_projects(
        workspace_id: str,
        repo: BaseRepository,
    ) -> list[Project]:
        """List all projects in a workspace (excludes soft-deleted projects).

        Args:
            workspace_id: The workspace identifier.
            repo: Repository instance for data access.

        Returns:
            List of non-deleted projects in the workspace.
        """
        projects = await repo.list(filters={"workspace_id": workspace_id})
        return [p for p in projects if p.deleted_at is None]


# Test fixtures
@pytest.fixture
def workspace_id() -> str:
    """Fixture providing a test workspace ID."""
    return "workspace-123"


@pytest.fixture
def project_active() -> Project:
    """Fixture providing an active (non-deleted) project."""
    return Project(
        workspace_id="workspace-123",
        project_id="proj-1",
        name="Active Project",
        deleted_at=None,
    )


@pytest.fixture
def project_deleted() -> Project:
    """Fixture providing a deleted project."""
    return Project(
        workspace_id="workspace-123",
        project_id="proj-2",
        name="Deleted Project",
        deleted_at=datetime(2024, 1, 1, 12, 0, 0),
    )


@pytest.fixture
def project_active_2() -> Project:
    """Fixture providing another active project."""
    return Project(
        workspace_id="workspace-123",
        project_id="proj-3",
        name="Another Active Project",
        deleted_at=None,
    )


@pytest.fixture
def project_different_workspace() -> Project:
    """Fixture providing a project from different workspace."""
    return Project(
        workspace_id="workspace-456",
        project_id="proj-4",
        name="Different Workspace Project",
        deleted_at=None,
    )


# Basic Functionality Tests
@pytest.mark.asyncio
async def test_list_projects_empty_result(workspace_id: str) -> None:
    """Test listing projects when repository returns empty list."""
    repo: BaseRepository = MockRepository(projects=[])

    result: list[Project] = await ProjectService.list_projects(
        workspace_id=workspace_id, repo=repo
    )

    assert result == []
    assert isinstance(result, list)


@pytest.mark.asyncio
async def test_list_projects_single_active(
    workspace_id: str,
    project_active: Project,
) -> None:
    """Test listing projects with single active project."""
    repo: BaseRepository = MockRepository(projects=[project_active])

    result: list[Project] = await ProjectService.list_projects(
        workspace_id=workspace_id, repo=repo
    )

    assert len(result) == 1
    assert result[0] == project_active


@pytest.mark.asyncio
async def test_list_projects_single_deleted(
    workspace_id: str,
    project_deleted: Project,
) -> None:
    """Test listing projects filters out single deleted project."""
    repo: BaseRepository = MockRepository(projects=[project_deleted])

    result: list[Project] = await ProjectService.list_projects(
        workspace_id=workspace_id, repo=repo
    )

    assert result == []


@pytest.mark.asyncio
async def test_list_projects_mixed_active_deleted(
    workspace_id: str,
    project_active: Project,
    project_deleted: Project,
    project_active_2: Project,
) -> None:
    """Test listing projects filters deleted projects from mixed list."""
    repo: BaseRepository = MockRepository(
        projects=[project_active, project_deleted, project_active_2]
    )

    result: list[Project] = await ProjectService.list_projects(
        workspace_id=workspace_id, repo=repo
    )

    assert len(result) == 2
    assert project_active in result
    assert project_active_2 in result
    assert project_deleted not in result


# Filtering Tests
@pytest.mark.asyncio
async def test_list_projects_passes_correct_filter(
    workspace_id: str,
    project_active: Project,
) -> None:
    """Test that list_projects passes workspace_id filter to repository."""
    repo: MockRepository = MockRepository(projects=[project_active])

    await ProjectService.list_projects(
        workspace_id=workspace_id, repo=repo
    )

    assert repo.last_filters is not None
    assert repo.last_filters["workspace_id"] == workspace_id


@pytest.mark.asyncio
async def test_list_projects_different_workspace_ids(
    project_active: Project,
    project_deleted: Project,
) -> None:
    """Test filtering with different workspace IDs."""
    ws_id_1: str = "workspace-1"
    ws_id_2: str = "workspace-2"

    repo_1: MockRepository = MockRepository(projects=[project_active])
    repo_2: MockRepository = MockRepository(projects=[project_deleted])

    result_1: list[Project] = await ProjectService.list_projects(
        workspace_id=ws_id_1, repo=repo_1
    )
    result_2: list[Project] = await ProjectService.list_projects(
        workspace_id=ws_id_2, repo=repo_2
    )

    assert repo_1.last_filters is not None
    assert repo_1.last_filters["workspace_id"] == ws_id_1
    assert repo_2.last_filters is not None
    assert repo_2.last_filters["workspace_id"] == ws_id_2
    assert len(result_1) == 1
    assert len(result_2) == 0


@pytest.mark.asyncio
async def test_repository_list_called_once(
    workspace_id: str,
) -> None:
    """Test that repository.list is called exactly once."""
    repo: MockRepository = MockRepository(projects=[])

    await ProjectService.list_projects(
        workspace_id=workspace_id, repo=repo
    )

    assert repo.list_call_count == 1


# Deleted_at Handling Tests
@pytest.mark.asyncio
async def test_deleted_at_none_included(workspace_id: str) -> None:
    """Test that projects with deleted_at=None are included."""
    project: Project = Project(
        workspace_id=workspace_id,
        project_id="proj-1",
        name="Test",
        deleted_at=None,
    )
    repo: BaseRepository = MockRepository(projects=[project])

    result: list[Project] = await ProjectService.list_projects(
        workspace_id=workspace_id, repo=repo
    )

    assert len(result) == 1
    assert result[0].deleted_at is None


@pytest.mark.asyncio
async def test_deleted_at_with_datetime_excluded(workspace_id: str) -> None:
    """Test that projects with datetime in deleted_at are excluded."""
    project: Project = Project(
        workspace_id=workspace_id,
        project_id="proj-1",
        name="Test",
        deleted_at=datetime(2024, 6, 15, 10, 30, 45),
    )
    repo: BaseRepository = MockRepository(projects=[project])

    result: list[Project] = await ProjectService.list_projects(
        workspace_id=workspace_id, repo=repo
    )

    assert len(result) == 0


@pytest.mark.asyncio
async def test_deleted_at_various_timestamps(workspace_id: str) -> None:
    """Test filtering with various deletion timestamps."""
    timestamps: list[datetime] = [
        datetime(2023, 1, 1, 0, 0, 0),
        datetime(2024, 6, 15, 12, 30, 45),
        datetime(2025, 12, 31, 23, 59, 59),
    ]

    for timestamp in timestamps:
        project: Project = Project(
            workspace_id=workspace_id,
            project_id=f"proj-{timestamp.timestamp()}",
            name="Test",
            deleted_at=timestamp,
        )
        repo: BaseRepository = MockRepository(projects=[project])

        result: list[Project] = await ProjectService.list_projects(
            workspace_id=workspace_id, repo=repo
        )

        assert len(result) == 0


# Return Type Tests
@pytest.mark.asyncio
async def test_returns_list_type(
    workspace_id: str,
    project_active: Project,
) -> None:
    """Test that list_projects returns a list type."""
    repo: BaseRepository = MockRepository(projects=[project_active])

    result: list[Project] = await ProjectService.list_projects(
        workspace_id=workspace_id, repo=repo
    )

    assert isinstance(result, list)


@pytest.mark.asyncio
async def test_returns_project_instances(
    workspace_id: str,
    project_active: Project,
    project_active_2: Project,
) -> None:
    """Test that list_projects returns Project instances."""
    repo: BaseRepository = MockRepository(
        projects=[project_active, project_active_2]
    )

    result: list[Project] = await ProjectService.list_projects(
        workspace_id=workspace_id, repo=repo
    )

    assert all(isinstance(p, Project) for p in result)


@pytest.mark.asyncio
async def test_return_list_is_copy(
    workspace_id: str,
    project_active: Project,
) -> None:
    """Test that returned list is independent copy."""
    original_projects: list[Project] = [project_active]
    repo: MockRepository = MockRepository(projects=original_projects)

    result: list[Project] = await ProjectService.list_projects(
        workspace_id=workspace_id, repo=repo
    )

    # Modify returned list should not affect original
    result.append(
        Project(
            workspace_id=workspace_id,
            project_id="new",
            name="New",
            deleted_at=None,
        )
    )

    # Verify original is unchanged
    assert len(original_projects) == 1


# Edge Case Tests
@pytest.mark.asyncio
async def test_empty_workspace_id(
    project_active: Project,
) -> None:
    """Test with empty workspace ID string."""
    repo: MockRepository = MockRepository(projects=[project_active])

    result: list[Project] = await ProjectService.list_projects(
        workspace_id="", repo=repo
    )

    assert repo.last_filters is not None
    assert repo.last_filters["workspace_id"] == ""


@pytest.mark.asyncio
async def test_special_characters_in_workspace_id(
    project_active: Project,
) -> None:
    """Test with special characters in workspace ID."""
    special_id: str = "workspace-!@#$%^&*()"
    repo: MockRepository = MockRepository(projects=[project_active])

    result: list[Project] = await ProjectService.list_projects(
        workspace_id=special_id, repo=repo
    )

    assert repo.last_filters is not None
    assert repo.last_filters["workspace_id"] == special_id


@pytest.mark.asyncio
async def test_very_long_workspace_id(
    project_active: Project,
) -> None:
    """Test with very long workspace ID."""
    long_id: str = "w" * 10000
    repo: MockRepository = MockRepository(projects=[project_active])

    result: list[Project] = await ProjectService.list_projects(
        workspace_id=long_id, repo=repo
    )

    assert repo.last_filters is not None
    assert repo.last_filters["workspace_id"] == long_id


@pytest.mark.asyncio
async def test_large_number_of_projects() -> None:
    """Test with large number of projects."""
    workspace_id: str = "workspace-large"
    projects: list[Project] = []

    # Create 1000 projects, half active, half deleted
    for i in range(1000):
        is_deleted: bool = i % 2 == 0
        projects.append(
            Project(
                workspace_id=workspace_id,
                project_id=f"proj-{i}",
                name=f"Project {i}",
                deleted_at=datetime(2024, 1, 1) if is_deleted else None,
            )
        )

    repo: BaseRepository = MockRepository(projects=projects)

    result: list[Project] = await ProjectService.list_projects(
        workspace_id=workspace_id, repo=repo
    )

    assert len(result) == 500
    assert all(p.deleted_at is None for p in result)


# Async Behavior Tests
@pytest.mark.asyncio
async def test_is_async_function() -> None:
    """Test that list_projects is an async function."""
    assert inspect.iscoroutinefunction(ProjectService.list_projects)


@pytest.mark.asyncio
async def test_can_await_result(
    workspace_id: str,
    project_active: Project,
) -> None:
    """Test that result is awaitable."""
    repo: BaseRepository = MockRepository(projects=[project_active])

    result = ProjectService.list_projects(
        workspace_id=workspace_id, repo=repo
    )

    # Should be awaitable
    assert hasattr(result, "__await__")

    # Should be able to await it
    final_result: list[Project] = await result
    assert len(final_result) == 1


@pytest.mark.asyncio
async def test_concurrent_calls(
    project_active: Project,
) -> None:
    """Test multiple concurrent calls to list_projects."""
    repos: list[BaseRepository] = [
        MockRepository(projects=[project_active]) for _ in range(5)
    ]

    tasks: list[Any] = [
        ProjectService.list_projects(
            workspace_id=f"workspace-{i}", repo=repo
        )
        for i, repo in enumerate(repos)
    ]

    results: list[list[Project]] = await asyncio.gather(*tasks)

    assert len(results) == 5
    assert all(len(r) == 1 for r in results)


# Type Annotation Tests
@pytest.mark.asyncio
async def test_workspace_id_string_type(
    project_active: Project,
) -> None:
    """Test that workspace_id must be string."""
    repo: BaseRepository = MockRepository(projects=[project_active])

    # This should work with string
    result: list[Project] = await ProjectService.list_projects(
        workspace_id="workspace-123", repo=repo
    )
    assert isinstance(result, list)


@pytest.mark.asyncio
async def test_repo_base_repository_type(
    workspace_id: str,
    project_active: Project,
) -> None:
    """Test that repo parameter is BaseRepository type."""
    repo: BaseRepository = MockRepository(projects=[project_active])

    # Should accept BaseRepository subclass
    result: list[Project] = await ProjectService.list_projects(
        workspace_id=workspace_id, repo=repo
    )
    assert isinstance(result, list)


# Data Integrity Tests
@pytest.mark.asyncio
async def test_projects_not_modified(
    workspace_id: str,
    project_active: Project,
) -> None:
    """Test that projects in result are not modified."""
    original_name: str = project_active.name
    original_deleted_at: datetime | None = project_active.deleted_at

    repo: BaseRepository = MockRepository(projects=[project_active])

    result: list[Project] = await ProjectService.list_projects(
        workspace_id=workspace_id, repo=repo
    )

    assert result[0].name == original_name
    assert result[0].deleted_at == original_deleted_at


@pytest.mark.asyncio
async def test_all_project_fields_preserved(
    workspace_id: str,
) -> None:
    """Test that all project fields are preserved in result."""
    project: Project = Project(
        workspace_id=workspace_id,
        project_id="test-123",
        name="Test Project Name",
        deleted_at=None,
    )
    repo: BaseRepository = MockRepository(projects=[project])

    result: list[Project] = await ProjectService.list_projects(
        workspace_id=workspace_id, repo=repo
    )

    result_project: Project = result[0]
    assert result_project.workspace_id == workspace_id
    assert result_project.project_id == "test-123"
    assert result_project.name == "Test Project Name"
    assert result_project.deleted_at is None


# Documentation Tests
def test_has_docstring() -> None:
    """Test that list_projects has a docstring."""
    assert ProjectService.list_projects.__doc__ is not None
    assert len(ProjectService.list_projects.__doc__) > 0


def test_docstring_mentions_soft_deleted() -> None:
    """Test that docstring mentions soft-deleted projects."""
    doc: str | None = ProjectService.list_projects.__doc__
    assert doc is not None
    assert "deleted" in doc.lower() or "soft" in doc.lower()



if __name__ == "__main__":
    pytest.main([__file__, "-v", "--tb=short"])