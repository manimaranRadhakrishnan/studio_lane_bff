"""Pytest configuration and fixtures."""

import uuid
from collections.abc import AsyncGenerator

import pytest
from fastapi.testclient import TestClient

from services.studio_gateway_api.main import create_app
from shared.config import Settings
from shared.context import RequestContext
from shared.auth import get_request_context
from shared.cosmosdb import get_cosmosdb

from tests.inmemory_cosmos import InMemoryCosmosDBClient


@pytest.fixture
def mock_settings() -> Settings:
    """Mock settings for testing."""
    return Settings(
        studio_env="test",
        gen_base_url="http://localhost:8080",
        delivery_base_url="http://localhost:8081",
        fabric_base_url="http://localhost:8082",
        audit_base_url="http://localhost:8083",
    )


@pytest.fixture
async def cosmos_client() -> AsyncGenerator[InMemoryCosmosDBClient, None]:
    """Create in-memory Cosmos client for tests."""
    client = InMemoryCosmosDBClient()
    yield client


@pytest.fixture
def mock_request_context() -> RequestContext:
    """Mock RequestContext for testing."""
    return RequestContext(
        tenant_id="test-tenant",
        user_id="test-user",
        roles={"Owner", "Editor"},
        session_id="test-session",
        correlation_id=str(uuid.uuid4()),
    )


@pytest.fixture
def test_client(cosmos_client, mock_request_context, monkeypatch):
    """Create test client for the gateway API."""
    # Disable auth requirement for tests
    monkeypatch.setenv("REQUIRE_AUTH_GLOBALLY", "false")

    app = create_app()

    async def override_get_cosmosdb():
        return cosmos_client

    async def override_get_request_context():
        return mock_request_context

    app.dependency_overrides[get_cosmosdb] = override_get_cosmosdb
    app.dependency_overrides[get_request_context] = override_get_request_context

    with TestClient(app) as client:
        yield client


