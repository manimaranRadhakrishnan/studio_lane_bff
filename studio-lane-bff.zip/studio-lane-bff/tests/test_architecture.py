"""Architectural fitness functions - enforce design rules."""
import ast
from pathlib import Path


def test_no_direct_db_access_in_routers():
    """Routers must use repository pattern, not direct DB access."""
    services_dir = Path("services")
    violations: list[str] = []

    if not services_dir.exists():
        return  # Skip if services dir doesn't exist

    for py_file in services_dir.rglob("router.py"):
        with py_file.open(encoding="utf-8") as f:
            try:
                tree = ast.parse(f.read(), filename=str(py_file))
                for node in ast.walk(tree):
                    if isinstance(node, ast.Import):
                        for alias in node.names:
                            if "sqlalchemy" in alias.name.lower():
                                violations.append(
                                    f"{py_file}: Direct SQLAlchemy import in router - use repository pattern"
                                )
                    elif isinstance(node, ast.ImportFrom) and node.module and "sqlalchemy" in node.module.lower():
                            violations.append(
                                f"{py_file}: Direct SQLAlchemy import in router - use repository pattern"
                            )
            except SyntaxError:
                pass  # Skip files with syntax errors

    assert not violations, "\n".join(violations)


def test_all_endpoints_have_tenant_isolation():
    """All POST/PUT/DELETE endpoints should have tenant_id dependency."""
    services_dir = Path("services")
    violations: list[str] = []

    if not services_dir.exists():
        return

    for py_file in services_dir.rglob("*.py"):
        if "__pycache__" in str(py_file):
            continue

        with py_file.open(encoding="utf-8") as f:
            content = f.read()
            try:
                tree = ast.parse(content, filename=str(py_file))

                for node in ast.walk(tree):
                    if isinstance(node, ast.FunctionDef):
                        # Check if it's a FastAPI route decorator
                        has_mutating_decorator = False
                        for decorator in node.decorator_list:
                            if isinstance(decorator, ast.Call) and isinstance(decorator.func, ast.Attribute):
                                method_name = decorator.func.attr
                                if method_name in ["post", "put", "delete", "patch"]:
                                    has_mutating_decorator = True
                                    break

                        if has_mutating_decorator:
                            # Check if function has tenant_id parameter
                            has_tenant_param = any(
                                arg.arg == "tenant_id" for arg in node.args.args
                            )

                            if not has_tenant_param:
                                violations.append(
                                    f"{py_file}:{node.lineno} - Endpoint '{node.name}' missing tenant_id parameter"
                                )
            except SyntaxError:
                pass

    assert not violations, "\n".join(violations)


def test_pydantic_models_used_everywhere():
    """All FastAPI endpoints must use Pydantic models for request/response."""
    services_dir = Path("services")
    violations: list[str] = []

    if not services_dir.exists():
        return

    for py_file in services_dir.rglob("*.py"):
        if "__pycache__" in str(py_file) or "test_" in py_file.name:
            continue

        with py_file.open(encoding="utf-8") as f:
            content = f.read()
            try:
                tree = ast.parse(content, filename=str(py_file))

                for node in ast.walk(tree):
                    if isinstance(node, ast.FunctionDef):
                        # Check if it's a FastAPI route
                        is_route = False
                        for decorator in node.decorator_list:
                            if isinstance(decorator, ast.Call) and isinstance(decorator.func, ast.Attribute) and decorator.func.attr in ["get", "post", "put", "delete", "patch"]:
                                is_route = True
                                break

                        if is_route and node.returns is None:
                                violations.append(
                                    f"{py_file}:{node.lineno} - Route '{node.name}' missing return type annotation"
                                )
            except SyntaxError:
                pass

    assert not violations, "\n".join(violations)


def test_no_any_type_hints():
    """No functions should use 'Any' type hints."""
    violations: list[str] = []

    for py_file in Path().rglob("*.py"):
        if "__pycache__" in str(py_file) or "test_" in py_file.name or ".venv" in str(py_file):
            continue

        with py_file.open(encoding="utf-8") as f:
            content = f.read()

            # Simple regex check for Any type hints
            if "from typing import" in content and "Any" in content:
                lines = content.split("\n")
                for i, line in enumerate(lines, 1):
                    if ": Any" in line or "-> Any" in line or "[Any" in line:
                        violations.append(
                            f"{py_file}:{i} - Uses 'Any' type hint - use specific types"
                        )

    assert not violations, "\n".join(violations)


def test_async_await_for_io_operations():
    """All I/O operations should use async/await."""
    services_dir = Path("services")
    violations: list[str] = []

    if not services_dir.exists():
        return

    for py_file in services_dir.rglob("*.py"):
        if "__pycache__" in str(py_file):
            continue

        with py_file.open(encoding="utf-8") as f:
            content = f.read()
            try:
                tree = ast.parse(content, filename=str(py_file))

                for node in ast.walk(tree):
                    if isinstance(node, ast.FunctionDef) and not isinstance(node, ast.AsyncFunctionDef):
                        # Check if function has FastAPI route decorator
                        has_route_decorator = any(
                            isinstance(d, ast.Call) and
                            isinstance(getattr(d, "func", None), ast.Attribute) and
                            getattr(getattr(d, "func", None), "attr", None) in
                            ["get", "post", "put", "delete", "patch"]
                            for d in node.decorator_list
                        )

                        if has_route_decorator:
                            violations.append(
                                f"{py_file}:{node.lineno} - Route '{node.name}' should be async"
                            )
            except SyntaxError:
                pass

    assert not violations, "\n".join(violations)


