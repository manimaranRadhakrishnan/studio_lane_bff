"""Tests for prompt library service."""

import uuid
from datetime import datetime, timezone

import pytest
from fastapi.testclient import TestClient

from services.studio_gateway_api.main import create_app
from shared.auth import get_request_context
from shared.context import RequestContext
from shared.cosmosdb import get_cosmosdb
from tests.inmemory_cosmos import InMemoryCosmosDBClient


@pytest.fixture
def viewer_context() -> RequestContext:
    """Create a RequestContext with Viewer role only."""
    return RequestContext(
        tenant_id="test-tenant",
        user_id="viewer-user",
        roles={"Viewer"},
        session_id="test-session",
        correlation_id=str(uuid.uuid4()),
    )


@pytest.fixture
def owner_context() -> RequestContext:
    """Create a RequestContext with Owner role."""
    return RequestContext(
        tenant_id="test-tenant",
        user_id="owner-user",
        roles={"Owner"},
        session_id="test-session",
        correlation_id=str(uuid.uuid4()),
    )


@pytest.fixture
def editor_context() -> RequestContext:
    """Create a RequestContext with Editor role."""
    return RequestContext(
        tenant_id="test-tenant",
        user_id="editor-user",
        roles={"Editor"},
        session_id="test-session",
        correlation_id=str(uuid.uuid4()),
    )


@pytest.fixture
def other_tenant_context() -> RequestContext:
    """Create a RequestContext for a different tenant."""
    return RequestContext(
        tenant_id="other-tenant",
        user_id="other-user",
        roles={"Owner", "Editor"},
        session_id="test-session",
        correlation_id=str(uuid.uuid4()),
    )


@pytest.fixture
def context_client_with_roles(cosmos_client, owner_context, monkeypatch):
    """Create test client with Owner role by default."""
    monkeypatch.setenv("REQUIRE_AUTH_GLOBALLY", "false")

    app = create_app()

    async def override_get_cosmosdb():
        return cosmos_client

    async def override_get_request_context():
        return owner_context

    app.dependency_overrides[get_cosmosdb] = override_get_cosmosdb
    app.dependency_overrides[get_request_context] = override_get_request_context

    with TestClient(app) as client:
        yield client, app


@pytest.fixture
def context_client_viewer(cosmos_client, viewer_context, monkeypatch):
    """Create test client with Viewer role."""
    monkeypatch.setenv("REQUIRE_AUTH_GLOBALLY", "false")

    app = create_app()

    async def override_get_cosmosdb():
        return cosmos_client

    async def override_get_request_context():
        return viewer_context

    app.dependency_overrides[get_cosmosdb] = override_get_cosmosdb
    app.dependency_overrides[get_request_context] = override_get_request_context

    with TestClient(app) as client:
        yield client, app


@pytest.fixture
def context_client_editor(cosmos_client, editor_context, monkeypatch):
    """Create test client with Editor role."""
    monkeypatch.setenv("REQUIRE_AUTH_GLOBALLY", "false")

    app = create_app()

    async def override_get_cosmosdb():
        return cosmos_client

    async def override_get_request_context():
        return editor_context

    app.dependency_overrides[get_cosmosdb] = override_get_cosmosdb
    app.dependency_overrides[get_request_context] = override_get_request_context

    with TestClient(app) as client:
        yield client, app


@pytest.fixture
def context_client_other_tenant(cosmos_client, other_tenant_context, monkeypatch):
    """Create test client with different tenant."""
    monkeypatch.setenv("REQUIRE_AUTH_GLOBALLY", "false")

    app = create_app()

    async def override_get_cosmosdb():
        return cosmos_client

    async def override_get_request_context():
        return other_tenant_context

    app.dependency_overrides[get_cosmosdb] = override_get_cosmosdb
    app.dependency_overrides[get_request_context] = override_get_request_context

    with TestClient(app) as client:
        yield client, app


# ==================== List Prompt Library Items Tests ====================


def test_list_contexts_empty(context_client_with_roles):
    """Test listing prompt library items when none exist."""
    client, _ = context_client_with_roles
    response = client.get("/api/v1/studio/prompt-library/")
    assert response.status_code == 200
    data = response.json()
    items = data.get("data", data) if isinstance(data, dict) else data
    assert isinstance(items, list)
    assert items == []


def test_list_contexts_with_pagination(context_client_with_roles):
    """Test listing prompt library items (multiple items)."""
    client, _ = context_client_with_roles

    # Create multiple items
    for i in range(5):
        resp = client.post(
            "/api/v1/studio/prompt-library/",
            json={
                "title": f"Item {i}",
                "content": f"Content {i}",
                "tags": [f"tag{i}"],
            },
        )
        assert resp.status_code == 201

    # List all (envelope wraps list as data)
    response = client.get("/api/v1/studio/prompt-library/")
    assert response.status_code == 200
    data = response.json()
    items = data.get("data", data) if isinstance(data, dict) else data
    assert isinstance(items, list)
    assert len(items) == 5


def test_list_contexts_default_pagination(context_client_with_roles):
    """Test listing prompt library items (single item)."""
    client, _ = context_client_with_roles

    # Create an item
    client.post(
        "/api/v1/studio/prompt-library/",
        json={"title": "Test Item", "content": "Test Content", "tags": []},
    )

    # List
    response = client.get("/api/v1/studio/prompt-library/")
    assert response.status_code == 200
    data = response.json()
    items = data.get("data", data) if isinstance(data, dict) else data
    assert isinstance(items, list)
    assert len(items) == 1


def test_list_contexts_viewer_can_access(context_client_viewer):
    """Test that viewers can list prompt library items (read access is open)."""
    client, _ = context_client_viewer

    response = client.get("/api/v1/studio/prompt-library/")
    assert response.status_code == 200
    data = response.json()
    items = data.get("data", data) if isinstance(data, dict) else data
    assert isinstance(items, list)


def test_list_contexts_tenant_isolation(context_client_with_roles, context_client_other_tenant):
    """Test that prompt library items are isolated by tenant."""
    # Create item in first tenant
    client1, _ = context_client_with_roles
    resp = client1.post(
        "/api/v1/studio/prompt-library/",
        json={"title": "Tenant 1 Item", "content": "Content", "tags": []},
    )
    assert resp.status_code == 201

    # List in first tenant
    resp = client1.get("/api/v1/studio/prompt-library/")
    assert resp.status_code == 200
    data1 = resp.json()
    items1 = data1.get("data", data1) if isinstance(data1, dict) else data1
    assert len(items1) == 1

    # List in second tenant (should be empty)
    client2, _ = context_client_other_tenant
    resp = client2.get("/api/v1/studio/prompt-library/")
    assert resp.status_code == 200
    data2 = resp.json()
    items2 = data2.get("data", data2) if isinstance(data2, dict) else data2
    assert len(items2) == 0


# ==================== Create Context Tests ====================


def test_create_context_success(context_client_with_roles):
    """Test successfully creating a prompt library item."""
    client, _ = context_client_with_roles

    response = client.post(
        "/api/v1/studio/prompt-library/",
        json={
            "title": "Test Item",
            "content": "Test Content",
            "tags": ["tag1", "tag2"],
        },
    )

    assert response.status_code == 201
    raw = response.json()
    data = raw.get("data", raw)
    assert data["title"] == "Test Item"
    assert data["content"] == "Test Content"
    assert data["tags"] == ["tag1", "tag2"]
    assert "id" in data
    assert data["tenant_id"] == "test-tenant"
    assert data["version"] == 1
    assert data["created_by"] == "owner-user"
    assert "created_at" in data
    assert "updated_at" in data


def test_create_context_with_empty_tags(context_client_with_roles):
    """Test creating a context with empty tags."""
    client, _ = context_client_with_roles

    response = client.post(
        "/api/v1/studio/prompt-library/",
        json={"title": "Test Context", "content": "Test Content", "tags": []},
    )

    assert response.status_code == 201
    raw = response.json()
    data = raw.get("data", raw)
    assert data["tags"] == []


def test_create_context_editor_can_create(context_client_editor):
    """Test that Editor role can create contexts."""
    client, _ = context_client_editor

    response = client.post(
        "/api/v1/studio/prompt-library/",
        json={"title": "Test Context", "content": "Test Content", "tags": []},
    )

    assert response.status_code == 201
    raw = response.json()
    data = raw.get("data", raw)
    assert data["title"] == "Test Context"


def test_create_context_viewer_cannot_create(context_client_viewer):
    """Test that Viewer role cannot create contexts."""
    client, _ = context_client_viewer

    response = client.post(
        "/api/v1/studio/prompt-library/",
        json={"title": "Test Context", "content": "Test Content", "tags": []},
    )

    assert response.status_code == 403
    assert "errorCode" in response.json()


def test_create_context_missing_fields(context_client_with_roles):
    """Test creating context with missing required fields."""
    client, _ = context_client_with_roles

    # Missing title
    response = client.post(
        "/api/v1/studio/prompt-library/",
        json={"content": "Test Content", "tags": []},
    )
    assert response.status_code == 422

    # Missing content
    response = client.post(
        "/api/v1/studio/prompt-library/",
        json={"title": "Test Context", "tags": []},
    )
    assert response.status_code == 422


# ==================== Get Project Prompt Selection Tests (future scope) ====================


def test_get_project_context_selection_exists(context_client_with_roles):
    """Test getting project prompt selection when it exists (future scope)."""
    client, _ = context_client_with_roles

    project_id = "project-123"

    # Create a selection first
    create_resp = client.put(
        f"/api/v1/studio/prompt-library/projects/{project_id}/selection",
        json={"selected_prompt_library_ids": ["context-1", "context-2"]},
    )
    assert create_resp.status_code == 200

    # Get the selection
    get_resp = client.get(f"/api/v1/studio/prompt-library/projects/{project_id}/selection")
    assert get_resp.status_code == 200
    raw = get_resp.json()
    data = raw.get("data", raw)
    assert data["project_id"] == project_id
    assert data["selected_prompt_library_ids"] == ["context-1", "context-2"]


def test_get_project_context_selection_not_exists(context_client_with_roles):
    """Test getting project prompt selection when selection record doesn't exist (future scope)."""
    client, _ = context_client_with_roles

    # Use a project id that may not have a selection record; if project doesn't exist we get 404
    project_id = "project-123"
    response = client.get(f"/api/v1/studio/prompt-library/projects/{project_id}/selection")
    # Project may not exist (404) or return empty selection (200)
    if response.status_code == 200:
        raw = response.json()
        data = raw.get("data", raw)
        assert data["selected_prompt_library_ids"] == [] or data["project_id"] == project_id
    else:
        assert response.status_code == 404


def test_get_project_context_selection_viewer_can_access(context_client_viewer):
    """Test that viewers can access project prompt selection (future scope; read access is open)."""
    client, _ = context_client_viewer

    response = client.get("/api/v1/studio/prompt-library/projects/project-123/selection")
    assert response.status_code == 200


def test_get_project_context_selection_tenant_isolation(context_client_with_roles, context_client_other_tenant):
    """Test that project selections are isolated by tenant."""
    # Create selection in first tenant
    client1, _ = context_client_with_roles
    project_id = "project-123"
    resp = client1.put(
        f"/api/v1/studio/prompt-library/projects/{project_id}/selection",
        json={"selected_prompt_library_ids": ["context-1"]},
    )
    assert resp.status_code == 200

    # Get selection in first tenant
    resp = client1.get(f"/api/v1/studio/prompt-library/projects/{project_id}/selection")
    assert resp.status_code == 200
    d = resp.json()
    data = d.get("data", d)
    assert data["selected_prompt_library_ids"] == ["context-1"]

    # Get selection in second tenant (should return empty)
    client2, _ = context_client_other_tenant
    resp = client2.get(f"/api/v1/studio/prompt-library/projects/{project_id}/selection")
    assert resp.status_code == 200
    d = resp.json()
    data = d.get("data", d)
    assert data["selected_prompt_library_ids"] == []  # Empty for different tenant


# ==================== Update Project Context Selection Tests ====================


def test_update_project_context_selection_create(context_client_with_roles):
    """Test creating a new project prompt selection (future scope)."""
    client, _ = context_client_with_roles

    project_id = "project-123"
    response = client.put(
        f"/api/v1/studio/prompt-library/projects/{project_id}/selection",
        json={"selected_prompt_library_ids": ["context-1", "context-2"]},
    )

    assert response.status_code == 200
    raw = response.json()
    data = raw.get("data", raw)
    assert data["project_id"] == project_id
    assert data["selected_prompt_library_ids"] == ["context-1", "context-2"]
    assert data["tenant_id"] == "test-tenant"
    assert "updated_by" in data
    assert "updated_at" in data


def test_update_project_context_selection_update(context_client_with_roles):
    """Test updating an existing project prompt selection (future scope)."""
    client, _ = context_client_with_roles

    project_id = "project-123"

    # Create selection
    create_resp = client.put(
        f"/api/v1/studio/prompt-library/projects/{project_id}/selection",
        json={"selected_prompt_library_ids": ["context-1"]},
    )
    assert create_resp.status_code == 200

    # Update selection
    update_resp = client.put(
        f"/api/v1/studio/prompt-library/projects/{project_id}/selection",
        json={"selected_prompt_library_ids": ["context-2", "context-3"]},
    )

    assert update_resp.status_code == 200
    raw = update_resp.json()
    data = raw.get("data", raw)
    assert data["selected_prompt_library_ids"] == ["context-2", "context-3"]


def test_update_project_context_selection_empty_list(context_client_with_roles):
    """Test updating project selection with empty list."""
    client, _ = context_client_with_roles

    project_id = "project-123"
    response = client.put(
        f"/api/v1/studio/prompt-library/projects/{project_id}/selection",
        json={"selected_prompt_library_ids": []},
    )

    assert response.status_code == 200
    raw = response.json()
    data = raw.get("data", raw)
    assert data["selected_prompt_library_ids"] == []


def test_update_project_context_selection_editor_can_update(context_client_editor):
    """Test that Editor role can update project prompt selection (future scope)."""
    client, _ = context_client_editor

    response = client.put(
        "/api/v1/studio/prompt-library/projects/project-123/selection",
        json={"selected_prompt_library_ids": ["context-1"]},
    )

    assert response.status_code == 200
    raw = response.json()
    data = raw.get("data", raw)
    assert data["selected_prompt_library_ids"] == ["context-1"]


def test_update_project_context_selection_viewer_cannot_update(context_client_viewer):
    """Test that Viewer role cannot update project prompt selection (future scope)."""
    client, _ = context_client_viewer

    response = client.put(
        "/api/v1/studio/prompt-library/projects/project-123/selection",
        json={"selected_prompt_library_ids": ["context-1"]},
    )

    assert response.status_code == 403
    assert "errorCode" in response.json()


def test_update_project_context_selection_tenant_isolation(context_client_with_roles, context_client_other_tenant):
    """Test that project selections are isolated by tenant."""
    # Create selection in first tenant
    client1, _ = context_client_with_roles
    project_id = "project-123"
    resp = client1.put(
        f"/api/v1/studio/prompt-library/projects/{project_id}/selection",
        json={"selected_prompt_library_ids": ["context-1"]},
    )
    assert resp.status_code == 200
    d = resp.json()
    data = d.get("data", d)
    assert data["tenant_id"] == "test-tenant"

    # Create selection in second tenant (same project_id, different tenant)
    client2, _ = context_client_other_tenant
    resp = client2.put(
        f"/api/v1/studio/prompt-library/projects/{project_id}/selection",
        json={"selected_prompt_library_ids": ["context-2"]},
    )
    assert resp.status_code == 200
    d = resp.json()
    data = d.get("data", d)
    assert data["tenant_id"] == "other-tenant"

    # Verify they're separate
    resp1 = client1.get(f"/api/v1/studio/prompt-library/projects/{project_id}/selection")
    resp2 = client2.get(f"/api/v1/studio/prompt-library/projects/{project_id}/selection")
    d1 = resp1.json()
    d2 = resp2.json()
    data1 = d1.get("data", d1)
    data2 = d2.get("data", d2)
    assert data1["selected_prompt_library_ids"] == ["context-1"]
    assert data2["selected_prompt_library_ids"] == ["context-2"]


