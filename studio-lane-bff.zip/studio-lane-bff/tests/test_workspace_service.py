"""Tests for workspace service."""


import pytest


def test_create_and_list_workspaces_via_api(test_client):
    """Create and list workspaces via the gateway API (Cosmos-backed)."""
    # Create
    resp = test_client.post(
        "/api/v1/studio/workspaces/workspaces",
        json={"name": "Test Workspace", "description": "A test workspace"},
    )
    assert resp.status_code == 201
    body = resp.json()
    assert "data" in body and "meta" in body
    assert body["data"]["name"] == "Test Workspace"

    # List
    resp = test_client.get("/api/v1/studio/workspaces/workspaces")
    assert resp.status_code == 200
    body = resp.json()
    assert isinstance(body["data"], list)
    assert len(body["data"]) == 1
    assert body["data"][0]["name"] == "Test Workspace"


