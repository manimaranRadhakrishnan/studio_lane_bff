import io
import types
import pytest

# Adjust this import to match your real module path
# If running from repo root:
# import services.workspace_service.handlers.image_handler as image_mod
# from services.workspace_service.handlers.image_handler import ImageHandler

import sys
import importlib

# Import the class under test
from services.workspace_service.handlers.image_handler import ImageHandler

# Get the ACTUAL module where ImageHandler is defined
image_mod = sys.modules.get(ImageHandler.__module__)
if image_mod is None:
    image_mod = importlib.import_module(ImageHandler.__module__)

@pytest.fixture
def ctx():
    # Minimal RequestContext substitute
    return types.SimpleNamespace(tenant_id="tenant-1")

@pytest.fixture
def settings():
    # Minimal Settings substitute (not used by handler directly)
    return types.SimpleNamespace()

class DummyUploadFile:
    """Minimal async-capable UploadFile stand-in."""
    def __init__(self, content: bytes, filename: str | None, content_type: str | None):
        self.filename = filename
        self.content_type = content_type
        self._content = content
        self.read_called = False

    async def read(self) -> bytes:
        self.read_called = True
        return self._content

class FakeRepo:
    def __init__(self, project):
        self.project = project
        self.last_project_id = None

    async def get(self, project_id: str):
        self.last_project_id = project_id
        return self.project

class FakeBlobStorageClient:
    """Fake blob client that records calls and ensures close() is awaited."""
    def __init__(self, settings):
        self.settings = settings
        self.closed = False
        self.upload_called_with = None
        self.raise_on_upload = None
        self.return_value = {
            "image_id": "img-123",
            "image_url": "https://blob.example.com/t1/p1/images/img-123.png",
            "content_type": "image/png",
            "size": 5,
        }

    async def upload_image(
        self,
        tenant_id: str,
        project_id: str,
        image_data: bytes,
        content_type: str,
        file_extension: str | None,
    ):
        # Record the inputs
        self.upload_called_with = {
            "tenant_id": tenant_id,
            "project_id": project_id,
            "image_data": image_data,
            "content_type": content_type,
            "file_extension": file_extension,
        }
        if self.raise_on_upload:
            raise self.raise_on_upload
        return self.return_value

    async def close(self):
        self.closed = True


@pytest.mark.asyncio
async def test_upload_success_with_filename_extension(monkeypatch, ctx, settings):
    """Happy path: valid PNG/JPEG, filename present -> extension extracted; blob upload succeeds."""
    # Arrange
    project = types.SimpleNamespace(tenant_id="tenant-1")
    repo = FakeRepo(project=project)

    # ensure_project_not_deleted should be called once
    called = {"count": 0}
    def ensure_ok(p):
        called["count"] += 1
    monkeypatch.setattr(image_mod, "ensure_project_not_deleted", ensure_ok)

    fake_client = FakeBlobStorageClient(settings)
    monkeypatch.setattr(image_mod, "BlobStorageClient", lambda s: fake_client)

    file = DummyUploadFile(content=b"12345", filename="pic.jpeg", content_type="image/jpeg")

    # Act
    result = await ImageHandler.upload_project_image(
        project_id="project-1",
        file=file,
        ctx=ctx,
        project_repo=repo,
        settings=settings,
    )

    # Assert
    assert result == fake_client.return_value
    assert fake_client.closed is True, "close() must be awaited in finally{}"
    # Validate upload args recorded
    assert fake_client.upload_called_with["tenant_id"] == "tenant-1"
    assert fake_client.upload_called_with["project_id"] == "project-1"
    assert fake_client.upload_called_with["image_data"] == b"12345"
    assert fake_client.upload_called_with["content_type"] == "image/jpeg"
    assert fake_client.upload_called_with["file_extension"] == "jpeg"
    assert called["count"] == 1, "ensure_project_not_deleted must be called exactly once"


@pytest.mark.asyncio
async def test_upload_invalid_content_type_raises_400(monkeypatch, ctx, settings):
    """Invalid content type should raise HTTPException(400) before reading or uploading."""
    project = types.SimpleNamespace(tenant_id="tenant-1")
    repo = FakeRepo(project=project)

    # ensure_project_not_deleted stub
    monkeypatch.setattr(image_mod, "ensure_project_not_deleted", lambda p: None)

    # Guard: BlobStorageClient must NOT be constructed on invalid content type
    def _fail_client_ctor(_):
        raise AssertionError("BlobStorageClient must not be created for invalid content type")
    monkeypatch.setattr(image_mod, "BlobStorageClient", _fail_client_ctor)

    file = DummyUploadFile(content=b"pdf", filename="doc.pdf", content_type="application/pdf")

    with pytest.raises(image_mod.HTTPException) as ei:
        await ImageHandler.upload_project_image(
            project_id="p1",
            file=file,
            ctx=ctx,
            project_repo=repo,
            settings=settings,
        )

    assert ei.value.status_code == 400
    assert "Invalid file type" in ei.value.detail
    assert file.read_called is False, "read() should not be called when content type is invalid"


@pytest.mark.asyncio
async def test_tenant_mismatch_raises_not_found(monkeypatch, settings):
    """If project.tenant_id != ctx.tenant_id -> NotFoundError should be raised."""
    # Prepare a fake NotFoundError to assert on

    class DummyNotFoundError(Exception):
        def __init__(self, message=None, *args, **kwargs):
            super().__init__(message)


    monkeypatch.setattr(image_mod, "NotFoundError", DummyNotFoundError)
    # ensure_project_not_deleted stub
    monkeypatch.setattr(image_mod, "ensure_project_not_deleted", lambda p: None)

    project = types.SimpleNamespace(tenant_id="tenant-2")
    repo = FakeRepo(project=project)
    ctx = types.SimpleNamespace(tenant_id="tenant-1")  # mismatch

    # Guard: Blob client should not be constructed on tenant mismatch
    def _fail_client_ctor(_):
        raise AssertionError("BlobStorageClient must not be created for tenant mismatch")
    monkeypatch.setattr(image_mod, "BlobStorageClient", _fail_client_ctor)

    file = DummyUploadFile(content=b"aaa", filename="a.png", content_type="image/png")

    with pytest.raises(DummyNotFoundError):
        await ImageHandler.upload_project_image(
            project_id="p1",
            file=file,
            ctx=ctx,
            project_repo=repo,
            settings=settings,
        )


@pytest.mark.asyncio
async def test_project_deleted_raises(monkeypatch, ctx, settings):
    """If ensure_project_not_deleted raises, the handler should propagate and not touch blob."""
    project = types.SimpleNamespace(tenant_id="tenant-1")
    repo = FakeRepo(project=project)

    def ensure_raises(_):
        raise image_mod.HTTPException(status_code=404, detail="Deleted")

    monkeypatch.setattr(image_mod, "ensure_project_not_deleted", ensure_raises)

    # Guard: Blob client should not be created
    def _fail_client_ctor(_):
        raise AssertionError("BlobStorageClient must not be created when project is deleted")
    monkeypatch.setattr(image_mod, "BlobStorageClient", _fail_client_ctor)

    file = DummyUploadFile(content=b"aaa", filename="a.png", content_type="image/png")

    with pytest.raises(image_mod.HTTPException) as ei:
        await ImageHandler.upload_project_image(
            project_id="p1",
            file=file,
            ctx=ctx,
            project_repo=repo,
            settings=settings,
        )
    assert ei.value.status_code == 404
    assert "Deleted" in ei.value.detail
    assert file.read_called is False, "Should not read file when project is deleted"


@pytest.mark.asyncio
async def test_blob_upload_exception_still_closes_client(monkeypatch, ctx, settings):
    """If upload_image raises, the handler must still await close() in finally and re-raise."""
    project = types.SimpleNamespace(tenant_id="tenant-1")
    repo = FakeRepo(project=project)

    # ensure_project_not_deleted ok
    monkeypatch.setattr(image_mod, "ensure_project_not_deleted", lambda p: None)

    fake_client = FakeBlobStorageClient(settings)
    fake_client.raise_on_upload = RuntimeError("simulate upload failure")
    monkeypatch.setattr(image_mod, "BlobStorageClient", lambda s: fake_client)

    file = DummyUploadFile(content=b"123", filename="good.png", content_type="image/png")

    with pytest.raises(RuntimeError, match="simulate upload failure"):
        await ImageHandler.upload_project_image(
            project_id="p1",
            file=file,
            ctx=ctx,
            project_repo=repo,
            settings=settings,
        )

    assert fake_client.closed is True, "Client.close() must be awaited even when upload fails"
    assert file.read_called is True, "File content should be read before upload"


@pytest.mark.asyncio
async def test_no_filename_extension_passes_none(monkeypatch, ctx, settings):
    """When filename is None, file_extension should be None in upload call."""
    project = types.SimpleNamespace(tenant_id="tenant-1")
    repo = FakeRepo(project=project)

    monkeypatch.setattr(image_mod, "ensure_project_not_deleted", lambda p: None)

    fake_client = FakeBlobStorageClient(settings)
    monkeypatch.setattr(image_mod, "BlobStorageClient", lambda s: fake_client)

    file = DummyUploadFile(content=b"xyz", filename=None, content_type="image/webp")

    result = await ImageHandler.upload_project_image(
        project_id="proj-xyz",
        file=file,
        ctx=ctx,
        project_repo=repo,
        settings=settings,
    )

    assert result == fake_client.return_value
    assert fake_client.upload_called_with["file_extension"] is None
    assert fake_client.upload_called_with["content_type"] == "image/webp"