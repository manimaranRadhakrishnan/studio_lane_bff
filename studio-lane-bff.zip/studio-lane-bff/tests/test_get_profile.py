"""
Comprehensive unit tests for get_profile method.
Tests all code paths and edge cases with 100% coverage.
"""

import pytest
from unittest.mock import AsyncMock, MagicMock, patch
from datetime import datetime, timezone
from typing import Optional

# ============================================================================
# Mock Classes
# ============================================================================


class UserProfile:
    """Mock UserProfile class."""

    def __init__(
        self,
        id: str,
        email: str,
        created_at: datetime,
        updated_at: datetime,
    ):
        self.id = id
        self.email = email
        self.created_at = created_at
        self.updated_at = updated_at

    def __eq__(self, other):
        if not isinstance(other, UserProfile):
            return False
        return (
            self.id == other.id
            and self.email == other.email
            and self.created_at == other.created_at
            and self.updated_at == other.updated_at
        )

    def __repr__(self):
        return f"UserProfile(id={self.id}, email={self.email})"


class RequestContext:
    """Mock RequestContext class."""

    def __init__(self, user_id: str):
        self.user_id = user_id


class BaseRepository:
    """Mock BaseRepository class."""

    async def get(self, user_id: str) -> Optional[UserProfile]:
        """Retrieve a user profile by ID."""
        pass

    async def create(self, profile: UserProfile) -> UserProfile:
        """Create a new user profile."""
        pass


# ============================================================================
# Function Under Test (from the provided code)
# ============================================================================


async def get_profile(
    ctx: RequestContext,
    repo: BaseRepository,
) -> UserProfile:
    """Get current user profile."""
    # Try to get existing profile
    profile = await repo.get(ctx.user_id)

    if profile:
        return profile

    # Create new profile if doesn't exist
    # In production, profile should be created during first login
    new_profile = UserProfile(
        id=ctx.user_id,
        email=f"{ctx.user_id}@temenos.com",  # Placeholder
        created_at=datetime.now(timezone.utc),
        updated_at=datetime.now(timezone.utc),
    )
    return await repo.create(new_profile)


# ============================================================================
# Test Fixtures
# ============================================================================


@pytest.fixture
def mock_request_context():
    """Create a mock RequestContext."""
    return RequestContext(user_id="user123")


@pytest.fixture
def mock_repository():
    """Create a mock BaseRepository."""
    repo = AsyncMock(spec=BaseRepository)
    return repo


@pytest.fixture
def existing_user_profile():
    """Create an existing UserProfile for testing."""
    return UserProfile(
        id="user123",
        email="user123@example.com",
        created_at=datetime(2024, 1, 1, 10, 0, 0),
        updated_at=datetime(2024, 1, 1, 10, 0, 0),
    )


# ============================================================================
# Test Cases - Existing Profile Retrieval (Path 1: profile exists)
# ============================================================================


@pytest.mark.asyncio
async def test_get_profile_returns_existing_profile(
    mock_request_context, mock_repository, existing_user_profile
):
    """Test that an existing profile is returned without creating a new one."""
    # Arrange
    mock_repository.get.return_value = existing_user_profile

    # Act
    result = await get_profile(mock_request_context, mock_repository)

    # Assert
    assert result == existing_user_profile
    assert result.id == "user123"
    assert result.email == "user123@example.com"
    mock_repository.get.assert_called_once_with("user123")
    mock_repository.create.assert_not_called()


@pytest.mark.asyncio
async def test_get_profile_existing_profile_preserves_original_data(
    mock_request_context, mock_repository
):
    """Test that existing profile data is preserved exactly."""
    # Arrange
    original_profile = UserProfile(
        id="user456",
        email="original@custom.com",
        created_at=datetime(2023, 6, 15, 14, 30, 45),
        updated_at=datetime(2024, 1, 20, 9, 15, 30),
    )
    mock_repository.get.return_value = original_profile
    mock_request_context.user_id = "user456"

    # Act
    result = await get_profile(mock_request_context, mock_repository)

    # Assert
    assert result.id == original_profile.id
    assert result.email == original_profile.email
    assert result.created_at == original_profile.created_at
    assert result.updated_at == original_profile.updated_at


@pytest.mark.asyncio
async def test_get_profile_existing_profile_calls_get_with_correct_user_id(
    mock_repository,
):
    """Test that get is called with the correct user ID."""
    # Arrange
    test_user_id = "test_user_xyz"
    ctx = RequestContext(user_id=test_user_id)
    existing_profile = UserProfile(
        id=test_user_id,
        email="test@test.com",
        created_at=datetime.now(timezone.utc),
        updated_at=datetime.now(timezone.utc),
    )
    mock_repository.get.return_value = existing_profile

    # Act
    await get_profile(ctx, mock_repository)

    # Assert
    mock_repository.get.assert_called_once_with(test_user_id)


@pytest.mark.asyncio
async def test_get_profile_returns_immediately_without_create_call(
    mock_request_context, mock_repository, existing_user_profile
):
    """Test that create is not called when profile exists."""
    # Arrange
    mock_repository.get.return_value = existing_user_profile
    mock_repository.create = AsyncMock()

    # Act
    result = await get_profile(mock_request_context, mock_repository)

    # Assert
    assert result is not None
    mock_repository.create.assert_not_called()


# ============================================================================
# Test Cases - New Profile Creation (Path 2: profile doesn't exist)
# ============================================================================


@pytest.mark.asyncio
async def test_get_profile_creates_new_profile_when_not_found(
    mock_request_context, mock_repository
):
    """Test that a new profile is created when no existing profile is found."""
    # Arrange
    mock_repository.get.return_value = None
    new_profile = UserProfile(
        id="user123",
        email="user123@temenos.com",
        created_at=datetime(2024, 1, 1, 10, 0, 0),
        updated_at=datetime(2024, 1, 1, 10, 0, 0),
    )
    mock_repository.create.return_value = new_profile

    # Act
    result = await get_profile(mock_request_context, mock_repository)

    # Assert
    assert result is not None
    assert result.id == "user123"
    assert result.email == "user123@temenos.com"
    mock_repository.create.assert_called_once()


@pytest.mark.asyncio
async def test_get_profile_new_profile_has_correct_id(
    mock_request_context, mock_repository
):
    """Test that the new profile is created with the correct user ID."""
    # Arrange
    mock_request_context.user_id = "new_user_abc"
    mock_repository.get.return_value = None
    created_profile = UserProfile(
        id="new_user_abc",
        email="new_user_abc@temenos.com",
        created_at=datetime.now(timezone.utc),
        updated_at=datetime.now(timezone.utc),
    )
    mock_repository.create.return_value = created_profile

    # Act
    result = await get_profile(mock_request_context, mock_repository)

    # Assert
    assert result.id == "new_user_abc"


@pytest.mark.asyncio
async def test_get_profile_new_profile_has_correct_email_format(
    mock_request_context, mock_repository
):
    """Test that the new profile has the correct email format (user_id@temenos.com)."""
    # Arrange
    mock_request_context.user_id = "john_doe"
    mock_repository.get.return_value = None
    created_profile = UserProfile(
        id="john_doe",
        email="john_doe@temenos.com",
        created_at=datetime.now(timezone.utc),
        updated_at=datetime.now(timezone.utc),
    )
    mock_repository.create.return_value = created_profile

    # Act
    result = await get_profile(mock_request_context, mock_repository)

    # Assert
    assert result.email == "john_doe@temenos.com"
    assert "@temenos.com" in result.email
    assert result.email.startswith("john_doe")


@pytest.mark.asyncio
async def test_get_profile_new_profile_has_timestamps(
    mock_request_context, mock_repository
):
    """Test that the new profile has created_at and updated_at timestamps."""
    # Arrange
    mock_repository.get.return_value = None
    now = datetime(2024, 1, 15, 12, 0, 0)
    created_profile = UserProfile(
        id="user123",
        email="user123@temenos.com",
        created_at=now,
        updated_at=now,
    )
    mock_repository.create.return_value = created_profile

    # Act
    result = await get_profile(mock_request_context, mock_repository)

    # Assert
    assert result.created_at is not None
    assert result.updated_at is not None
    assert isinstance(result.created_at, datetime)
    assert isinstance(result.updated_at, datetime)


@pytest.mark.asyncio
async def test_get_profile_new_profile_created_and_updated_timestamps_equal(
    mock_request_context, mock_repository
):
    """Test that created_at and updated_at are equal for new profiles."""
    # Arrange
    mock_repository.get.return_value = None
    now = datetime.now(timezone.utc)
    created_profile = UserProfile(
        id="user123",
        email="user123@temenos.com",
        created_at=now,
        updated_at=now,
    )
    mock_repository.create.return_value = created_profile

    # Act
    result = await get_profile(mock_request_context, mock_repository)

    # Assert
    assert result.created_at == result.updated_at


@pytest.mark.asyncio
async def test_get_profile_calls_repo_get_before_create(
    mock_request_context, mock_repository
):
    """Test that repo.get is called before repo.create."""
    # Arrange
    mock_repository.get.return_value = None
    created_profile = UserProfile(
        id="user123",
        email="user123@temenos.com",
        created_at=datetime.now(timezone.utc),
        updated_at=datetime.now(timezone.utc),
    )
    mock_repository.create.return_value = created_profile
    call_order = []

    async def track_get(*args):
        call_order.append("get")
        return None

    async def track_create(*args):
        call_order.append("create")
        return created_profile

    mock_repository.get.side_effect = track_get
    mock_repository.create.side_effect = track_create

    # Act
    await get_profile(mock_request_context, mock_repository)

    # Assert
    assert call_order == ["get", "create"]


@pytest.mark.asyncio
async def test_get_profile_new_profile_returned_from_create(
    mock_request_context, mock_repository
):
    """Test that the profile returned from create is returned to the caller."""
    # Arrange
    mock_repository.get.return_value = None
    created_profile = UserProfile(
        id="user123",
        email="user123@temenos.com",
        created_at=datetime.now(timezone.utc),
        updated_at=datetime.now(timezone.utc),
    )
    mock_repository.create.return_value = created_profile

    # Act
    result = await get_profile(mock_request_context, mock_repository)

    # Assert
    assert result is created_profile


# ============================================================================
# Test Cases - Edge Cases and Special Scenarios
# ============================================================================


@pytest.mark.asyncio
async def test_get_profile_with_special_characters_in_user_id(
    mock_repository,
):
    """Test that special characters in user_id are handled correctly."""
    # Arrange
    special_user_id = "user@domain.com"
    ctx = RequestContext(user_id=special_user_id)
    mock_repository.get.return_value = None
    created_profile = UserProfile(
        id=special_user_id,
        email=f"{special_user_id}@temenos.com",
        created_at=datetime.now(timezone.utc),
        updated_at=datetime.now(timezone.utc),
    )
    mock_repository.create.return_value = created_profile

    # Act
    result = await get_profile(ctx, mock_repository)

    # Assert
    assert result.email == f"{special_user_id}@temenos.com"


@pytest.mark.asyncio
async def test_get_profile_with_numeric_user_id(mock_repository):
    """Test that numeric user IDs are handled correctly."""
    # Arrange
    numeric_user_id = "12345"
    ctx = RequestContext(user_id=numeric_user_id)
    mock_repository.get.return_value = None
    created_profile = UserProfile(
        id=numeric_user_id,
        email=f"{numeric_user_id}@temenos.com",
        created_at=datetime.now(timezone.utc),
        updated_at=datetime.now(timezone.utc),
    )
    mock_repository.create.return_value = created_profile

    # Act
    result = await get_profile(ctx, mock_repository)

    # Assert
    assert result.id == "12345"
    assert result.email == "12345@temenos.com"


@pytest.mark.asyncio
async def test_get_profile_with_empty_string_user_id(mock_repository):
    """Test that empty string user IDs are handled."""
    # Arrange
    ctx = RequestContext(user_id="")
    mock_repository.get.return_value = None
    created_profile = UserProfile(
        id="",
        email="@temenos.com",
        created_at=datetime.now(timezone.utc),
        updated_at=datetime.now(timezone.utc),
    )
    mock_repository.create.return_value = created_profile

    # Act
    result = await get_profile(ctx, mock_repository)

    # Assert
    assert result.id == ""
    assert result.email == "@temenos.com"


@pytest.mark.asyncio
async def test_get_profile_with_very_long_user_id(mock_repository):
    """Test that very long user IDs are handled correctly."""
    # Arrange
    long_user_id = "a" * 1000
    ctx = RequestContext(user_id=long_user_id)
    mock_repository.get.return_value = None
    created_profile = UserProfile(
        id=long_user_id,
        email=f"{long_user_id}@temenos.com",
        created_at=datetime.now(timezone.utc),
        updated_at=datetime.now(timezone.utc),
    )
    mock_repository.create.return_value = created_profile

    # Act
    result = await get_profile(ctx, mock_repository)

    # Assert
    assert result.id == long_user_id
    assert len(result.email) > 1000


@pytest.mark.asyncio
async def test_get_profile_multiple_calls_same_existing_user(
    mock_request_context, mock_repository, existing_user_profile
):
    """Test multiple calls for the same user that exists."""
    # Arrange
    mock_repository.get.return_value = existing_user_profile

    # Act
    result1 = await get_profile(mock_request_context, mock_repository)
    result2 = await get_profile(mock_request_context, mock_repository)

    # Assert
    assert result1 == result2
    assert mock_repository.get.call_count == 2
    assert mock_repository.create.call_count == 0


@pytest.mark.asyncio
async def test_get_profile_multiple_calls_different_users(mock_repository):
    """Test multiple calls for different users."""
    # Arrange
    user1_profile = UserProfile(
        id="user1",
        email="user1@example.com",
        created_at=datetime.now(timezone.utc),
        updated_at=datetime.now(timezone.utc),
    )
    user2_profile = UserProfile(
        id="user2",
        email="user2@temenos.com",
        created_at=datetime.now(timezone.utc),
        updated_at=datetime.now(timezone.utc),
    )
    mock_repository.get.side_effect = [user1_profile, user2_profile]

    ctx1 = RequestContext(user_id="user1")
    ctx2 = RequestContext(user_id="user2")

    # Act
    result1 = await get_profile(ctx1, mock_repository)
    result2 = await get_profile(ctx2, mock_repository)

    # Assert
    assert result1.id == "user1"
    assert result2.id == "user2"
    assert result1 != result2


@pytest.mark.asyncio
async def test_get_profile_create_called_with_correct_profile_object(
    mock_request_context, mock_repository
):
    """Test that create is called with a UserProfile object with correct properties."""
    # Arrange
    mock_repository.get.return_value = None
    created_profile = UserProfile(
        id="user123",
        email="user123@temenos.com",
        created_at=datetime.now(timezone.utc),
        updated_at=datetime.now(timezone.utc),
    )
    mock_repository.create.return_value = created_profile

    # Act
    await get_profile(mock_request_context, mock_repository)

    # Assert
    mock_repository.create.assert_called_once()
    call_args = mock_repository.create.call_args
    created_obj = call_args[0][0]
    assert isinstance(created_obj, UserProfile)
    assert created_obj.id == "user123"
    assert created_obj.email == "user123@temenos.com"


@pytest.mark.asyncio
async def test_get_profile_none_return_from_get_triggers_create(
    mock_request_context, mock_repository
):
    """Test that None return from get triggers profile creation."""
    # Arrange
    mock_repository.get.return_value = None
    mock_repository.create.return_value = UserProfile(
        id="user123",
        email="user123@temenos.com",
        created_at=datetime.now(timezone.utc),
        updated_at=datetime.now(timezone.utc),
    )

    # Act
    result = await get_profile(mock_request_context, mock_repository)

    # Assert
    assert result is not None
    mock_repository.get.assert_called_once()
    mock_repository.create.assert_called_once()


@pytest.mark.asyncio
async def test_get_profile_falsy_non_none_value_treated_as_not_found(
    mock_request_context, mock_repository
):
    """Test that falsy values (but not None) would still cause creation attempt."""
    # This tests the if profile check - only None is falsy in this context
    # Arrange
    mock_repository.get.return_value = None

    created_profile = UserProfile(
        id="user123",
        email="user123@temenos.com",
        created_at=datetime.now(timezone.utc),
        updated_at=datetime.now(timezone.utc),
    )
    mock_repository.create.return_value = created_profile

    # Act
    result = await get_profile(mock_request_context, mock_repository)

    # Assert
    assert result is not None
    mock_repository.create.assert_called_once()


@pytest.mark.asyncio
async def test_get_profile_preserves_context_user_id(mock_repository):
    """Test that the context's user_id is used correctly throughout."""
    # Arrange
    user_ids = ["alice", "bob", "charlie"]

    for user_id in user_ids:
        ctx = RequestContext(user_id=user_id)
        mock_repository.get.return_value = None
        created_profile = UserProfile(
            id=user_id,
            email=f"{user_id}@temenos.com",
            created_at=datetime.now(timezone.utc),
            updated_at=datetime.now(timezone.utc),
        )
        mock_repository.create.return_value = created_profile

        # Act
        result = await get_profile(ctx, mock_repository)

        # Assert
        assert result.id == user_id
        mock_repository.get.assert_called_with(user_id)


@pytest.mark.asyncio
async def test_get_profile_return_type_is_user_profile(
    mock_request_context, mock_repository, existing_user_profile
):
    """Test that the return type is always UserProfile."""
    # Arrange
    mock_repository.get.return_value = existing_user_profile

    # Act
    result = await get_profile(mock_request_context, mock_repository)

    # Assert
    assert isinstance(result, UserProfile)


@pytest.mark.asyncio
async def test_get_profile_return_type_is_user_profile_on_create(
    mock_request_context, mock_repository
):
    """Test that the return type is UserProfile even when creating new."""
    # Arrange
    mock_repository.get.return_value = None
    created_profile = UserProfile(
        id="user123",
        email="user123@temenos.com",
        created_at=datetime.now(timezone.utc),
        updated_at=datetime.now(timezone.utc),
    )
    mock_repository.create.return_value = created_profile

    # Act
    result = await get_profile(mock_request_context, mock_repository)

    # Assert
    assert isinstance(result, UserProfile)


@pytest.mark.asyncio
async def test_get_profile_repo_get_raises_exception_propagates(
    mock_request_context, mock_repository
):
    """Test that exceptions from repo.get propagate correctly."""
    # Arrange
    mock_repository.get.side_effect = Exception("Database error")

    # Act & Assert
    with pytest.raises(Exception, match="Database error"):
        await get_profile(mock_request_context, mock_repository)


@pytest.mark.asyncio
async def test_get_profile_repo_create_raises_exception_propagates(
    mock_request_context, mock_repository
):
    """Test that exceptions from repo.create propagate correctly."""
    # Arrange
    mock_repository.get.return_value = None
    mock_repository.create.side_effect = Exception("Create failed")

    # Act & Assert
    with pytest.raises(Exception, match="Create failed"):
        await get_profile(mock_request_context, mock_repository)


# ============================================================================
# Integration Tests
# ============================================================================


@pytest.mark.asyncio
async def test_get_profile_integration_existing_user_workflow(
    mock_repository,
):
    """Integration test: Existing user retrieval workflow."""
    # Arrange
    user_profile = UserProfile(
        id="integration_user",
        email="integration_user@company.com",
        created_at=datetime(2024, 1, 1, 10, 0, 0),
        updated_at=datetime(2024, 1, 1, 10, 0, 0),
    )
    mock_repository.get.return_value = user_profile
    ctx = RequestContext(user_id="integration_user")

    # Act
    result = await get_profile(ctx, mock_repository)

    # Assert
    assert result == user_profile
    assert result.id == "integration_user"
    mock_repository.create.assert_not_called()


@pytest.mark.asyncio
async def test_get_profile_integration_new_user_workflow(
    mock_repository,
):
    """Integration test: New user creation workflow."""
    # Arrange
    mock_repository.get.return_value = None
    ctx = RequestContext(user_id="new_user")
    new_profile = UserProfile(
        id="new_user",
        email="new_user@temenos.com",
        created_at=datetime.now(timezone.utc),
        updated_at=datetime.now(timezone.utc),
    )
    mock_repository.create.return_value = new_profile

    # Act
    result = await get_profile(ctx, mock_repository)

    # Assert
    assert result == new_profile
    assert result.id == "new_user"
    assert result.email == "new_user@temenos.com"
    mock_repository.get.assert_called_once_with("new_user")
    mock_repository.create.assert_called_once()


@pytest.mark.asyncio
async def test_get_profile_integration_sequential_calls(mock_repository):
    """Integration test: Sequential calls with different outcomes."""
    # Arrange
    existing_profile = UserProfile(
        id="user1",
        email="user1@example.com",
        created_at=datetime.now(timezone.utc),
        updated_at=datetime.now(timezone.utc),
    )
    new_profile = UserProfile(
        id="user2",
        email="user2@temenos.com",
        created_at=datetime.now(timezone.utc),
        updated_at=datetime.now(timezone.utc),
    )

    # First call: existing user
    mock_repository.get.return_value = existing_profile
    ctx1 = RequestContext(user_id="user1")
    result1 = await get_profile(ctx1, mock_repository)

    # Second call: new user
    mock_repository.get.return_value = None
    mock_repository.create.return_value = new_profile
    ctx2 = RequestContext(user_id="user2")
    result2 = await get_profile(ctx2, mock_repository)

    # Assert
    assert result1 == existing_profile
    assert result2 == new_profile
    assert result1.id != result2.id


# ============================================================================
# Test Configuration
# ============================================================================


if __name__ == "__main__":
    # Run tests with: python -m pytest test_get_profile.py -v --cov
    pytest.main([__file__, "-v", "--tb=short"])