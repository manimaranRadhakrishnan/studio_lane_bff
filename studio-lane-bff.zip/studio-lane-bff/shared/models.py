"""Common domain models and enums."""

from datetime import datetime, timezone
from enum import Enum
from typing import Literal

from pydantic import AliasChoices, BaseModel, EmailStr, Field


# ==================== Enums ====================


class UserRole(str, Enum):
    """User roles for RBAC."""

    OWNER = "Owner"
    EDITOR = "Editor"
    VIEWER = "Viewer"


class ProjectStatus(str, Enum):
    """Project status."""

    DRAFT = "draft"
    ACTIVE = "active"
    ARCHIVED = "archived"


class PermissionLevel(str, Enum):
    """Project sharing permission level."""

    VIEW = "view"
    EDIT = "edit"


class TaskStatus(str, Enum):
    """Task planner status."""

    PENDING = "pending"
    IN_PROGRESS = "in_progress"
    COMPLETED = "completed"
    FAILED = "failed"


class PreviewStatus(str, Enum):
    """Preview deployment status."""

    STARTING = "starting"
    RUNNING = "running"
    FAILED = "failed"
    STOPPED = "stopped"


class BuildStatus(str, Enum):
    """Build status."""

    QUEUED = "queued"
    BUILDING = "building"
    SUCCESS = "success"
    FAILED = "failed"


class ReleaseStatus(str, Enum):
    """Release status."""

    PENDING = "pending"
    DEPLOYING = "deploying"
    COMPLETED = "completed"
    FAILED = "failed"


class GitProvider(str, Enum):
    """Git provider types."""

    GITHUB = "github"
    GITLAB = "gitlab"
    AZURE_DEVOPS = "azure_devops"
    BITBUCKET = "bitbucket"


# ==================== User Models ====================


class UserProfile(BaseModel):
    """User profile model."""

    id: str
    full_name: str | None = None
    email: EmailStr
    avatar_url: str | None = None
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    updated_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))


class UserRoleAssignment(BaseModel):
    """User role assignment (for workspace/project)."""

    id: str
    user_id: str
    workspace_id: str | None = None
    project_id: str | None = None
    role: UserRole
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))


# ==================== Workspace & Project Models ====================


class Workspace(BaseModel):
    """Workspace model (top-level organization unit)."""

    id: str
    name: str
    description: str | None = None
    tenant_id: str
    owner_id: str
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    updated_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))


class Folder(BaseModel):
    """Folder model for organizing projects within workspace."""

    id: str
    name: str
    workspace_id: str  # Alias for tenant_id; always set workspace_id = tenant_id
    user_id: str
    tenant_id: str
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    updated_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))


class Project(BaseModel):
    """Project model."""

    id: str
    name: str
    description: str | None = None
    type: str | None = None  # Project type: "Mobile App", "Responsive Web", etc.
    status: ProjectStatus = ProjectStatus.DRAFT
    workspace_id: str  # Alias for tenant_id; always set workspace_id = tenant_id
    folder_id: str | None = None
    tenant_id: str
    user_id: str  # owner
    repo_binding_id: str | None = None  # Reference to ProjectRepoBinding
    title_image: str | None = None  # Blob URI for project title/landing page image
    deleted_at: datetime | None = None  # Soft delete timestamp (API-owned, never from caller)
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    updated_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    updated_by: str | None = None  # API-owned, never from caller


class Favorite(BaseModel):
    """Favorite project model."""

    id: str
    user_id: str
    project_id: str
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))


class ProjectShare(BaseModel):
    """Project sharing model."""

    id: str
    project_id: str
    shared_by_user_id: str
    shared_with_email: EmailStr
    shared_with_user_id: str | None = None
    permission: PermissionLevel = PermissionLevel.VIEW
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))


# ==================== Design System Models ====================


class DesignSystem(BaseModel):
    """Design system model."""

    id: str
    name: str
    version: str
    description: str | None = None
    project_id: str | None = None  # Linked project
    tenant_id: str
    created_by: str
    config: dict = Field(default_factory=dict)
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    updated_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))


# ==================== Theme Models ====================


class Theme(BaseModel):
    """Theme model (colors/typography).

    Supports hierarchy: global (platform), tenant, project.
    Global themes are read-only platform defaults.
    """

    id: str
    name: str
    tenant_id: str  # "platform" for global themes
    created_by: str
    description: str | None = None
    scope: Literal["global", "tenant", "project"] = "tenant"
    colors: dict = Field(default_factory=dict)
    typography: dict = Field(default_factory=dict)
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    updated_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

    @property
    def is_global(self) -> bool:
        """Check if theme is global (platform-level)."""
        return self.scope == "global"


# ==================== Platform Configuration Models ====================


class PlatformConfig(BaseModel):
    """Global platform configuration (single document).

    Contains platform-wide settings: global themes, default typography,
    default Bitbucket repo, and platform limits.
    """

    id: str = "platform"  # Single document, partition key: /id (uses PLATFORM_TENANT_ID)
    global_themes: list[str] = Field(
        default_factory=lambda: ["light", "dark", "temenos-default"]
    )  # Read-only platform themes
    default_typography: dict = Field(
        default_factory=lambda: {
            "font_family": "Temenos Sans, system-ui, sans-serif",
            "font_sizes": {"xs": "12px", "sm": "14px", "base": "16px", "lg": "18px", "xl": "20px"},
            "font_weights": {"normal": 400, "medium": 500, "semibold": 600, "bold": 700},
            "line_heights": {"tight": 1.25, "normal": 1.5, "relaxed": 1.75},
        }
    )
    default_bitbucket_repo: str = ""  # Platform default repo URL
    platform_limits: dict = Field(default_factory=dict)  # Default limits (overridden per tenant)
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    updated_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))


class TenantConfig(BaseModel):
    """Tenant configuration (onboarding and tenant-specific defaults).

    Created automatically on first SSO login.
    """

    id: str  # Use tenant_id as id
    tenant_id: str
    onboarding_status: Literal["pending", "completed"] = "pending"
    onboarding_completed_at: datetime | None = None
    default_workspace_id: str | None = None  # Auto-created on onboarding
    tenant_limits: dict | None = None  # Tenant-specific limit overrides
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    updated_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))


class FabricConnection(BaseModel):
    """Tenant-scoped Fabric connection settings (BFF-owned). No raw secrets in API; use secret_ref for connect."""

    id: str = "fabric-connection"
    tenant_id: str
    conn_name: str = "default"
    fabric_core_base_url: str = ""
    app_id: str = ""
    env: str = ""
    auth_url: str = ""
    secret_ref: str | None = None  # Key Vault reference for attempt connect only; never returned to GenAI
    last_connection_status: Literal["unknown", "connected", "failed"] = "unknown"
    last_connected_at: datetime | None = None
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    updated_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))


class PlatformLimit(BaseModel):
    """Platform limit configuration (tenant override support).

    tenant_id=None: Platform default (uses PLATFORM_TENANT_ID as partition key)
    tenant_id set: Tenant-specific override
    """

    id: str  # Use limit_type as id (e.g., "prompt_text", "image_upload")
    tenant_id: str | None = None  # None = platform default (uses PLATFORM_TENANT_ID)
    limit_type: str  # e.g., "prompt_text", "image_upload", "image_count", "image_extensions"
    value: str | int  # Limit value
    unit: str | None = None  # e.g., "chars", "bytes", "count"
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    updated_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))


# ==================== Prompt Library Models ====================


class PromptLibraryItem(BaseModel):
    """Prompt library item (list of prompts)."""

    id: str
    tenant_id: str = Field(..., alias="tenantId")
    title: str
    content: str
    tags: list[str] = Field(default_factory=list)
    version: int = 1
    created_by: str | None = None   # optional since DB doesn’t have it
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc), alias="createdAt")
    updated_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc), alias="updatedAt")

    class Config:
        allow_population_by_field_name = True
        extra = "ignore"   # ignore Cosmos system fields (_rid, _self, etc.)

class ProjectPromptSelection(BaseModel):
    """Prompt selection state stored on a project (future scope: single-select in UX)."""

    id: str  # use project_id as id for simple upsert semantics
    project_id: str
    tenant_id: str
    selected_prompt_library_ids: list[str] = Field(
        default_factory=list,
        validation_alias=AliasChoices("selected_prompt_library_ids", "selected_context_ids"),
    )
    updated_by: str
    updated_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))


# ==================== Session Models ====================


class StudioSession(BaseModel):
    """Session projection for Studio Web (does not replace SSO)."""

    id: str
    tenant_id: str
    user_id: str
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    last_seen_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))


# ==================== Conversation Models ====================


class ChatSession(BaseModel):
    """AI chat session model."""

    id: str
    project_id: str
    workspace_id: str  # Alias for tenant_id; always set workspace_id = tenant_id
    user_id: str
    title: str = "New Chat"
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    updated_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))


class ChatMessage(BaseModel):
    """Chat message model.

    Messages are linked to gen_run_id and project_id to build complete chat history.
    Assistant messages include change_summary and followups from job completion.
    """

    id: str
    session_id: str
    project_id: str  # Always linked to a project
    gen_run_id: str | None = None  # Linked to GenAI job (set after job starts)
    role: Literal["user", "assistant"]
    content: str
    change_summary: str | None = None  # From gen.run.completed event (assistant only)
    followups: list[str] | None = None  # Suggested followup prompts (assistant only)
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))


class Task(BaseModel):
    """Task planner task model."""

    id: str
    session_id: str
    title: str
    description: str | None = None
    status: TaskStatus = TaskStatus.PENDING
    agent: str | None = None  # Agent responsible for task
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    updated_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    completed_at: datetime | None = None


class SessionEvent(BaseModel):
    """Session event model (plan outputs, task events, etc.)."""

    id: str
    session_id: str
    event_type: Literal["plan_created", "task_started", "task_completed", "code_generated", "error"]
    payload: dict = Field(default_factory=dict)  # Flexible event data
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))


# ==================== Delivery Models ====================


class Preview(BaseModel):
    """Preview deployment model."""

    id: str
    project_id: str
    environment_id: str
    status: PreviewStatus
    url: str | None = None
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    updated_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))


class Build(BaseModel):
    """Build model."""

    id: str
    project_id: str
    branch: str = "main"
    status: BuildStatus
    artifacts: list[dict] = Field(default_factory=list)
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    completed_at: datetime | None = None


class Release(BaseModel):
    """Release model."""

    id: str
    project_id: str
    build_id: str
    target_environment: str
    status: ReleaseStatus
    deployed_at: datetime | None = None
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))


# ==================== File Models ====================


class File(BaseModel):
    """File model."""

    id: str
    name: str
    path: str
    project_id: str
    content: str | None = None
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    updated_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))


# ==================== Working Copy Models ====================


class WorkingCopyRef(BaseModel):
    """Working copy reference (pointer to Blob storage)."""

    blob_base_uri: str
    wc_version_stamp: str
    branch: str


class WorkingCopyMetadata(BaseModel):
    """Working copy metadata (BFF-owned pointers only; GenAI owns actual code in Blob)."""

    id: str  # Use wc_version_stamp as id
    tenant_id: str
    project_id: str
    branch: str
    wc_version_stamp: str
    blob_base_uri: str
    base_wc_version_stamp: str | None = None  # Parent version if cloned
    git_commit_sha: str | None = None  # Git commit SHA if synced from Git
    created_by: str | None = None
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    updated_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))


# ==================== Job Projection Models ====================


class GenRunStatus(str, Enum):
    """GenAI run status."""

    QUEUED = "queued"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"


class JobProjection(BaseModel):
    """BFF projection of GenAI run status/progress (UI-friendly view)."""

    id: str  # Use genRunId as id
    tenant_id: str
    project_id: str
    gen_run_id: str
    session_id: str | None = None
    status: GenRunStatus = GenRunStatus.QUEUED
    progress_percent: int = 0
    current_task_id: str | None = None
    tasks_completed: int = 0
    tasks_total: int = 0
    patch_set_id: str | None = None
    error_message: str | None = None
    preview_url: str | None = None
    title_image: str | None = None
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    updated_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    completed_at: datetime | None = None


# ==================== Lifecycle Timeline Models ====================


class PreviewTimelineEntry(BaseModel):
    """Preview environment timeline entry."""

    env_id: str
    status: PreviewStatus
    preview_url: str | None = None
    wc_version_stamp: str | None = None
    triggered_by: str | None = None
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    updated_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))


class BuildTimelineEntry(BaseModel):
    """Build timeline entry."""

    build_id: str
    status: BuildStatus
    platform: str | None = None
    logs_url: str | None = None
    artifact_id: str | None = None
    wc_version_stamp: str | None = None
    triggered_by: str | None = None
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    updated_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    completed_at: datetime | None = None


class PublishTimelineEntry(BaseModel):
    """Publish timeline entry."""

    publish_id: str
    status: ReleaseStatus
    platforms: list[str] = Field(default_factory=list)
    artifacts: list[dict] = Field(default_factory=list)
    release_notes: str | None = None
    wc_version_stamp: str | None = None
    triggered_by: str | None = None
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    updated_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    completed_at: datetime | None = None


class LifecycleTimeline(BaseModel):
    """UI-friendly lifecycle timeline per project (preview/build/publish history)."""

    id: str  # Use project_id as id for simple upsert semantics
    tenant_id: str
    project_id: str
    previews: list[PreviewTimelineEntry] = Field(default_factory=list)
    builds: list[BuildTimelineEntry] = Field(default_factory=list)
    publishes: list[PublishTimelineEntry] = Field(default_factory=list)
    updated_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))


# ==================== Git Connection Models ====================


class GitConnection(BaseModel):
    """
    Git connection model (tenant-level provider authentication).

    One per tenant (1 tenant = 1 workspace). Holds provider auth + allowed orgs.
    Multiple projects can share tenant provider auth.
    """

    id: str  # Format: {tenant_id}:{provider}
    tenant_id: str
    workspace_id: str  # workspace_id = tenant_id (1 tenant = 1 workspace, kept for backward compatibility)
    provider: GitProvider
    token_ref: str | None = None  # KeyVault secret reference (no tokens in Cosmos)
    allowed_orgs: list[str] = Field(default_factory=list)  # Allowed organizations/repos
    webhook_secret_ref: str | None = None  # KeyVault secret reference for webhook validation
    webhook_url: str | None = None  # Delivery webhook URL for this connection
    created_by: str | None = None
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    updated_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    is_active: bool = True


class ProjectRepoBinding(BaseModel):
    """
    Project repository binding (project → repo + branch lockable lane).

    BFF-owned binding metadata. Each project has its own binding.
    Conflict strategy: optimistic concurrency with version stamps.
    """

    id: str  # Format: {tenant_id}:{project_id}
    tenant_id: str
    project_id: str
    workspace_id: str  # Alias for tenant_id; always set workspace_id = tenant_id
    git_connection_id: str | None = None  # None = use internal managed repo
    repo_url: str | None = None  # None = use internal managed repo
    branch: str = "main"
    git_head_commit_id: str | None = None  # Tracked Git HEAD commit (for conflict detection)
    last_synced_at: datetime | None = None  # Last sync timestamp
    is_locked: bool = False  # Lock branch if Studio is generating (conflict prevention)
    is_internal_repo: bool = True  # True = internal managed repo, False = external repo
    created_by: str | None = None
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    updated_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))


