"""Role-Based Access Control (RBAC) helpers."""

from collections.abc import Callable

from fastapi import Depends

from shared.context import RequestContext
from shared.errors import PermissionError


def require_role(*required_roles: str) -> Callable:
    """
    Dependency factory for role-based access control.

    Usage:
        @router.get("/admin")
        async def admin_endpoint(ctx: RequestContext = Depends(require_role("Owner"))):
            ...

        @router.post("/edit")
        async def edit_endpoint(ctx: RequestContext = Depends(require_role("Owner", "Editor"))):
            ...

    Args:
        *required_roles: One or more role names. User must have at least one.

    Returns:
        A FastAPI dependency that validates roles and returns RequestContext.

    Raises:
        PermissionError: If user doesn't have any of the required roles.
    """
    from shared.auth import get_request_context

    async def role_checker(
        ctx: RequestContext = Depends(get_request_context),  # noqa: B008
    ) -> RequestContext:
        """Check if user has required role."""
        if not required_roles:
            # No roles required, just return context
            return ctx

        if not ctx.has_role(*required_roles):
            raise PermissionError(
                message=f"Required role: {' or '.join(required_roles)}",
                details={
                    "required_roles": list(required_roles),
                    "user_roles": list(ctx.roles),
                },
            )

        return ctx

    return role_checker


def require_all_roles(*required_roles: str) -> Callable:
    """
    Dependency factory requiring ALL specified roles.

    Similar to require_role, but user must have ALL roles, not just one.
    """
    from shared.auth import get_request_context

    async def role_checker(
        ctx: RequestContext = Depends(get_request_context),  # noqa: B008
    ) -> RequestContext:
        """Check if user has all required roles."""
        if not required_roles:
            return ctx

        if not ctx.has_all_roles(*required_roles):
            raise PermissionError(
                message=f"Required roles: {', '.join(required_roles)}",
                details={
                    "required_roles": list(required_roles),
                    "user_roles": list(ctx.roles),
                },
            )

        return ctx

    return role_checker


def is_owner(ctx: RequestContext) -> bool:
    """Check if user has Owner role."""
    return "Owner" in ctx.roles


def is_editor(ctx: RequestContext) -> bool:
    """Check if user has Editor role."""
    return "Editor" in ctx.roles


def can_edit(ctx: RequestContext) -> bool:
    """Check if user can edit (Owner or Editor)."""
    return is_owner(ctx) or is_editor(ctx)


