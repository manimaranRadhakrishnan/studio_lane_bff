"""Platform limits helpers for validation."""

DEFAULT_IMAGE_UPLOAD_MAX_BYTES = 20 * 1024 * 1024  # 20MB


async def get_image_upload_max_size(
    cosmos_client: "CosmosDBClient",
    tenant_id: str | None = None,
) -> int:
    """
    Get image_upload_max_size limit from platform_limits (Cosmos).
    Falls back to DEFAULT_IMAGE_UPLOAD_MAX_BYTES if not found.

    Args:
        cosmos_client: Cosmos DB client
        tenant_id: Tenant for tenant-specific override; None for platform default

    Returns:
        Max size in bytes
    """
    from shared.constants import PLATFORM_TENANT_ID

    try:
        from shared.document_models import from_cosmos_document, get_container_for_type
        from shared.models import PlatformLimit

        container = get_container_for_type("platform_limit")
        partition = tenant_id or PLATFORM_TENANT_ID
        doc = await cosmos_client.read_item(
            item_id="image_upload_max_size",
            partition_key=partition,
            container_name=container,
        )
        if doc:
            limit = from_cosmos_document(doc, PlatformLimit)
            if isinstance(limit.value, (int, float)):
                return int(limit.value)
    except Exception:
        pass
    return DEFAULT_IMAGE_UPLOAD_MAX_BYTES

