"""Configuration management using Pydantic Settings."""

from functools import lru_cache

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict

from dotenv import load_dotenv
load_dotenv()


class Settings(BaseSettings):
    """Application settings loaded from environment variables and Azure services."""

    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=False,
        extra="ignore",
    )

    # Environment
    studio_env: str = Field(default="dev", alias="STUDIO_ENV")
    require_tenant_header: bool = Field(
        default=True,
        alias="STUDIO_REQUIRE_TENANT_HEADER",
        description="When True, all authenticated routes require X-CS-Tenant-Id header. Bootstrap paths (auth config, callback, user) are exempt.",
    )

    # Downstream service URLs
    gen_base_url: str = Field(
        default="http://gen-lane-api:8080",
        alias="GEN_BASE_URL",
    )
    delivery_base_url: str = Field(
        default="http://delivery-api:8080",
        alias="DELIVERY_BASE_URL",
    )
    fabric_base_url: str = Field(
        default="http://gen-lane-api:8080",
        alias="FABRIC_BASE_URL",
        description="GenAI Fabric API base URL (BFF proxies to GenAI for API Hub; read-only)",
    )
    audit_base_url: str = Field(
        default="http://audit-api:8080",
        alias="AUDIT_BASE_URL",
    )

    # HTTP client settings
    http_timeout: int = Field(default=30, alias="HTTP_TIMEOUT")
    http_max_retries: int = Field(default=3, alias="HTTP_MAX_RETRIES")

    # Service Bus (event pipeline - infra IMPLEMENTATION_PLAN Phase 4)
    service_bus_enabled: bool = Field(
        default=False,
        alias="SERVICE_BUS_ENABLED",
        description="Enable Service Bus consumer for gen-run-events and delivery-events. When false, HTTP ingestion routes are used.",
    )
    service_bus_connection_string: str = Field(
        default="",
        alias="SERVICE_BUS_CONNECTION_STRING",
        description="Azure Service Bus connection string. Required when SERVICE_BUS_ENABLED=true.",
    )
    service_bus_gen_run_topic: str = Field(
        default="gen-run-events",
        alias="SERVICE_BUS_GEN_RUN_TOPIC",
        description="Service Bus topic for gen.run.* events from GenAI.",
    )
    service_bus_delivery_topic: str = Field(
        default="delivery-events",
        alias="SERVICE_BUS_DELIVERY_TOPIC",
        description="Service Bus topic for preview.ready, build.status.changed from Delivery.",
    )

    # Keycloak SSO (all creds from env vars; no Azure AD)
    keycloak_url: str = Field(
        default="http://localhost:8080",
        alias="KEYCLOAK_URL",
        description="Keycloak server base URL",
    )
    keycloak_realm: str = Field(
        default="temenos-studio",
        alias="KEYCLOAK_REALM",
        description="Keycloak realm name",
    )
    keycloak_client_id: str = Field(
        default="studio-bff",
        alias="KEYCLOAK_CLIENT_ID",
        description="Keycloak client ID (BFF / callback)",
    )
    keycloak_client_id_web: str | None = Field(
        default=None,
        alias="KEYCLOAK_CLIENT_ID_WEB",
        description="Keycloak public client ID for SPA; default KEYCLOAK_CLIENT_ID",
    )
    keycloak_client_secret: str = Field(
        default="",
        alias="KEYCLOAK_CLIENT_SECRET",
        description="Keycloak client secret (confidential)",
    )
    keycloak_redirect_uri: str = Field(
        default="http://localhost:8000/api/v1/studio/auth/callback",
        alias="KEYCLOAK_REDIRECT_URI",
        description="BFF callback URL after Keycloak login",
    )
    keycloak_frontend_redirect_uri: str = Field(
        default="http://localhost:3000",
        alias="KEYCLOAK_FRONTEND_REDIRECT_URI",
        description="Frontend base URL (used to derive login/success redirects if not set)",
    )
    keycloak_login_error_redirect: str = Field(
        default="",
        alias="KEYCLOAK_LOGIN_ERROR_REDIRECT",
        description="Redirect on callback failure; default {KEYCLOAK_FRONTEND_REDIRECT_URI}/login",
    )
    keycloak_success_redirect: str = Field(
        default="",
        alias="KEYCLOAK_SUCCESS_REDIRECT",
        description="Redirect on callback success (workspace / project list); default {KEYCLOAK_FRONTEND_REDIRECT_URI}/",
    )
    keycloak_issuer: str | None = Field(
        default=None,
        alias="KEYCLOAK_ISSUER",
        description="Issuer override; default {KEYCLOAK_URL}/realms/{KEYCLOAK_REALM}",
    )
    keycloak_audience: str | None = Field(
        default=None,
        alias="KEYCLOAK_AUDIENCE",
        description="JWT audience; default KEYCLOAK_CLIENT_ID",
    )
    keycloak_skip_verify: bool = Field(
        default=False,
        alias="KEYCLOAK_SKIP_VERIFY",
        description="Dev only: skip JWT signature verification when True",
    )

    @property
    def keycloak_jwks_url(self) -> str:
        """Keycloak JWKS URL (openid-connect certs)."""
        base = f"{self.keycloak_url.rstrip('/')}/realms/{self.keycloak_realm}"
        return f"{base}/protocol/openid-connect/certs"

    @property
    def keycloak_issuer_resolved(self) -> str:
        """Resolved Keycloak issuer for JWT validation."""
        if self.keycloak_issuer:
            return self.keycloak_issuer.rstrip("/")
        base = f"{self.keycloak_url.rstrip('/')}/realms/{self.keycloak_realm}"
        return base

    @property
    def keycloak_audience_resolved(self) -> str:
        """Resolved JWT audience (for verification)."""
        return self.keycloak_audience or self.keycloak_client_id

    @property
    def keycloak_login_error_redirect_resolved(self) -> str:
        """Redirect on callback failure; default {frontend}/login."""
        base = self.keycloak_frontend_redirect_uri.rstrip("/")
        return self.keycloak_login_error_redirect or f"{base}/login"

    @property
    def keycloak_success_redirect_resolved(self) -> str:
        """Redirect on callback success (workspace); default {frontend}/."""
        base = self.keycloak_frontend_redirect_uri.rstrip("/")
        return self.keycloak_success_redirect.rstrip("/") if self.keycloak_success_redirect else f"{base}/"

    # Cosmos DB settings
    cosmos_connection_string: str = Field(
        default="",
        alias="COSMOS_CONNECTION_STRING",
    )
    cosmos_database_name: str = Field(
        default="studio_lane",
        alias="COSMOS_DATABASE_NAME",
    )
    cosmos_partition_key_path: str = Field(
        default="/partitionKey",
        alias="COSMOS_PARTITION_KEY_PATH",
    )
    cosmos_max_retry_attempts: int = Field(
        default=3,
        alias="COSMOS_MAX_RETRY_ATTEMPTS",
    )
    cosmos_request_timeout: int = Field(
        default=30,
        alias="COSMOS_REQUEST_TIMEOUT",
    )

    # RBAC: require auth globally by default (page/action-level RBAC)
    require_auth_globally: bool = Field(
        default=True,
        alias="REQUIRE_AUTH_GLOBALLY",
        description="If True, reject unauthenticated requests to /api/v1/studio/*",
    )

    # Azure infrastructure (optional)
    azure_app_config_endpoint: str | None = Field(
        default=None,
        alias="AZURE_APP_CONFIG_ENDPOINT",
    )
    azure_key_vault_url: str | None = Field(
        default=None,
        alias="AZURE_KEY_VAULT_URL",
    )
    azure_storage_connection_string: str = Field(
        default="",
        alias="AZURE_STORAGE_CONNECTION_STRING",
    )

    # Observability
    otel_exporter_otlp_endpoint: str | None = Field(
        default=None,
        alias="OTEL_EXPORTER_OTLP_ENDPOINT",
    )
    log_level: str = Field(default="INFO", alias="LOG_LEVEL")

    # Security
    cors_origins: str = Field(
        default="http://localhost:3000,http://localhost:3001",
        alias="CORS_ORIGINS",
    )

    @property
    def cors_origins_list(self) -> list[str]:
        """Parse CORS origins into a list."""
        return [origin.strip() for origin in self.cors_origins.split(",")]

    @property
    def cosmos_container_config(self) -> dict[str, str]:
        """Get Cosmos DB container configuration mapping entity types to container names."""
        return {
            "user_profile": "users",
            "user_role_assignment": "users",
            "workspace": "workspaces",
            "folder": "workspaces",
            "project": "projects",
            "favorite": "projects",
            "project_share": "projects",
            "design_system": "design_systems",
            "theme": "themes",
            "context_item": "contexts",
            "project_context_selection": "projects",
            "studio_session": "sessions",
            "chat_session": "conversations",
            "chat_message": "conversations",
            "task": "tasks",
            "file": "files",
            "working_copy_metadata": "wcMetadata",
            "job_projection": "jobProjections",
            "lifecycle_timeline": "lifecycleTimelines",
            "git_connection": "gitConnections",
            "project_repo_binding": "projectRepoBindings",
            "platform_config": "platform_config",
            "tenant_config": "tenant_config",
            "platform_limit": "platform_limits",
        }


@lru_cache
def get_settings() -> Settings:
    """Get cached settings instance."""
    return Settings()


