"""GenAI reindex client for BFF (trigger code index refresh after WC sync)."""

from __future__ import annotations

import os
from typing import Any

from shared.config import Settings, get_settings
from shared.http_client import get_http_client
#from shared.logging import get_logger

#logger = get_logger(__name__)


class GenReindexClient:
    """
    HTTP client for triggering GenAI code index refresh.

    BFF triggers reindex after Git → WC sync to ensure GenAI has latest code.
    """

    def __init__(self, base_url: str | None = None):
        """
        Initialize GenAI reindex client.

        Args:
            base_url: GenAI base URL (or from env GEN_BASE_URL)
        """
        settings = get_settings()
        self.base_url = base_url or settings.gen_base_url
        self.timeout = 30.0
        self.max_retries = 2  # Best effort

    async def trigger_code_refresh(
        self,
        *,
        tenant_id: str,
        project_id: str,
        wc_version_stamp: str | None = None,
        correlation_id: str | None = None,
    ) -> dict[str, Any]:
        """
        Trigger GenAI code index refresh.

        Args:
            tenant_id: Tenant ID
            project_id: Project ID
            wc_version_stamp: WC version stamp (optional)
            correlation_id: Correlation ID for tracing

        Returns:
            Response dict from GenAI
        """
        headers = {
            "X-CS-Tenant-Id": tenant_id,
        }
        if correlation_id:
            headers["X-Correlation-ID"] = correlation_id

        payload = {
            "project_id": project_id,
        }
        if wc_version_stamp:
            payload["wc_version_stamp"] = wc_version_stamp

        async with get_http_client(
            base_url=self.base_url,
            timeout=self.timeout,
            max_retries=self.max_retries,
        ) as client:
            try:
                response = await client.post(
                    "/v1/index/code:refresh",
                    json=payload,
                    headers=headers,
                )
                # logger.info(
                #     "Triggered GenAI code index refresh",
                #     extra={
                #         "tenant_id": tenant_id,
                #         "project_id": project_id,
                #         "wc_version_stamp": wc_version_stamp,
                #         "status_code": response.status_code,
                #     },
                # )
                return response.json() if response.content else {}
            except Exception as e:
                # Log but don't fail - reindex is best-effort
                # logger.warning(
                #     "Failed to trigger GenAI code index refresh",
                #     extra={
                #         "tenant_id": tenant_id,
                #         "project_id": project_id,
                #         "wc_version_stamp": wc_version_stamp,
                #         "error": str(e),
                #     },
                # )
                return {"status": "failed", "error": str(e)}


def get_gen_reindex_client(base_url: str | None = None) -> GenReindexClient:
    """Factory for GenAI reindex client."""
    return GenReindexClient(base_url=base_url)


