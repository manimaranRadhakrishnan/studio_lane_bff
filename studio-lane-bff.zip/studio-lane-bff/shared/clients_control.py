"""Control Plane HTTP clients for Fabric and Audit services."""

from typing import Any

import httpx

from shared.config import Settings
from shared.context import RequestContext
from shared.http_utils import HttpClientContextManager
from shared.observability import LatencyTracker


class FabricClient:
    """
    HTTP client for Fabric API catalog service.

    Handles API discovery, details, and configuration.

    Can be used as async context manager:
        async with FabricClient(settings) as client:
            result = await client.list_apis(...)
    """

    def __init__(self, settings: Settings):
        self.base_url = settings.fabric_base_url
        self.timeout = settings.http_timeout
        self.settings = settings
        self.client: httpx.AsyncClient | None = None
        self._context_manager: HttpClientContextManager | None = None

    async def __aenter__(self) -> "FabricClient":
        """Enter async context manager."""
        self._context_manager = HttpClientContextManager(
            base_url=self.base_url,
            timeout=self.timeout,
            max_retries=self.settings.http_max_retries,
        )
        self.client = await self._context_manager.__aenter__()
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb) -> None:
        """Exit async context manager."""
        if self._context_manager:
            await self._context_manager.__aexit__(exc_type, exc_val, exc_tb)
            self.client = None
            self._context_manager = None

    def _ensure_client(self) -> httpx.AsyncClient:
        """Ensure client is initialized."""
        if self.client is None:
            # Fallback to manual initialization for backward compatibility
            self.client = httpx.AsyncClient(
                base_url=self.base_url,
                timeout=httpx.Timeout(self.timeout),
            )
        return self.client

    async def close(self) -> None:
        """Close HTTP client (for manual management)."""
        if self.client:
            await self.client.aclose()
            self.client = None

    async def list_apis(
        self,
        ctx: RequestContext,
    ) -> list[dict[str, Any]]:
        """
        List available Fabric APIs.

        Reads from Cosmos fabric registry (updated by GenAI scheduler).
        For search/filter, use GenAI Lane Core's fabric discovery index.
        """
        client = self._ensure_client()
        with LatencyTracker("fabric", "list_apis"):
            use_mock = getattr(self.settings, "fabric_use_mock", True)

            if use_mock:
                # STUB: Return mock response
                return [
                    {
                        "api_id": "api-001",
                        "name": "Customer API",
                        "version": "1.0.0",
                        "endpoint": "https://api.temenos.com/customer/v1",
                        "category": "customer",
                        "tags": ["customer", "data"],
                    },
                    {
                        "api_id": "api-002",
                        "name": "Account API",
                        "version": "2.1.0",
                        "endpoint": "https://api.temenos.com/account/v2",
                        "category": "account",
                        "tags": ["account", "financial"],
                    },
                ]

            # Real API call - GenAI Fabric API (reads from GenAI Cosmos)
            response = await client.get(
                "/fabric/apis",
                params={"tenant_id": ctx.tenant_id},
                headers={
                    "X-Correlation-ID": ctx.correlation_id or "",
                    "X-CS-Tenant-Id": ctx.tenant_id,
                },
            )
            response.raise_for_status()
            data = response.json()
            return data.get("data", data) if isinstance(data, dict) else data

    async def get_api_details(
        self,
        ctx: RequestContext,
        api_id: str,
    ) -> dict[str, Any]:
        """
        Get detailed information about a Fabric API.
        """
        client = self._ensure_client()
        with LatencyTracker("fabric", "get_api_details"):
            use_mock = getattr(self.settings, "fabric_use_mock", True)

            if use_mock:
                # STUB: Return mock response
                return {
                    "api_id": api_id,
                    "name": "Customer API",
                    "version": "1.0.0",
                    "endpoint": "https://api.temenos.com/customer/v1",
                    "schema": {
                        "openapi": "3.0.0",
                        "info": {"title": "Customer API", "version": "1.0.0"},
                    },
                    "authentication": {
                        "type": "oauth2",
                        "scopes": ["read:customers", "write:customers"],
                    },
                }

            # Real API call - GenAI Fabric API
            response = await client.get(
                f"/fabric/apis/{api_id}",
                params={"tenant_id": ctx.tenant_id},
                headers={
                    "X-Correlation-ID": ctx.correlation_id or "",
                    "X-CS-Tenant-Id": ctx.tenant_id,
                },
            )
            response.raise_for_status()
            return response.json()

    async def save_config(
        self,
        ctx: RequestContext,
        project_id: str,
        api_id: str,
        config: dict[str, Any],
    ) -> dict[str, Any]:
        """
        Save Fabric API configuration for a project.
        """
        client = self._ensure_client()
        with LatencyTracker("fabric", "save_config"):
            use_mock = getattr(self.settings, "fabric_use_mock", True)

            if use_mock:
                # STUB: Return mock response
                return {
                    "config_id": f"config-{project_id}-{api_id}",
                    "project_id": project_id,
                    "api_id": api_id,
                    "status": "saved",
                }

            # Real API call
            response = await client.post(
                "/api/fabric/apis/config",
                json={
                    "project_id": project_id,
                    "api_id": api_id,
                    "config": config,
                },
                headers={"X-Correlation-ID": ctx.correlation_id or ""},
            )
            response.raise_for_status()
            return response.json()


class AuditClient:
    """
    HTTP client for Audit service.

    Write-only relay for user actions to audit ledger.

    Can be used as async context manager:
        async with AuditClient(settings) as client:
            result = await client.write_event(...)
    """

    def __init__(self, settings: Settings):
        self.base_url = settings.audit_base_url
        self.timeout = settings.http_timeout
        self.settings = settings
        self.client: httpx.AsyncClient | None = None
        self._context_manager: HttpClientContextManager | None = None

    async def __aenter__(self) -> "AuditClient":
        """Enter async context manager."""
        self._context_manager = HttpClientContextManager(
            base_url=self.base_url,
            timeout=self.timeout,
            max_retries=self.settings.http_max_retries,
        )
        self.client = await self._context_manager.__aenter__()
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb) -> None:
        """Exit async context manager."""
        if self._context_manager:
            await self._context_manager.__aexit__(exc_type, exc_val, exc_tb)
            self.client = None
            self._context_manager = None

    def _ensure_client(self) -> httpx.AsyncClient:
        """Ensure client is initialized."""
        if self.client is None:
            # Fallback to manual initialization for backward compatibility
            self.client = httpx.AsyncClient(
                base_url=self.base_url,
                timeout=httpx.Timeout(self.timeout),
            )
        return self.client

    async def close(self) -> None:
        """Close HTTP client (for manual management)."""
        if self.client:
            await self.client.aclose()
            self.client = None

    async def write_event(
        self,
        ctx: RequestContext,
        event_type: str,
        resource_type: str,
        resource_id: str,
        action: str,
        details: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """
        Write audit event to ledger.
        """
        client = self._ensure_client()
        with LatencyTracker("audit", "write_event"):
            use_mock = getattr(self.settings, "audit_use_mock", True)

            if use_mock:
                # STUB: Return mock response
                return {
                    "event_id": f"audit-{ctx.tenant_id}-001",
                    "status": "recorded",
                }

            # Real API call
            response = await client.post(
                "/api/audit/events",
                json={
                    "event_type": event_type,
                    "resource_type": resource_type,
                    "resource_id": resource_id,
                    "action": action,
                    "details": details or {},
                },
                headers={"X-Correlation-ID": ctx.correlation_id or ""},
            )
            response.raise_for_status()
            return response.json()

    async def ping(self) -> dict[str, str]:
        """Health check for audit service."""
        client = self._ensure_client()
        with LatencyTracker("audit", "ping"):
            use_mock = getattr(self.settings, "audit_use_mock", True)

            if use_mock:
                # STUB: Return mock response
                return {"status": "healthy"}

            # Real API call
            response = await client.get("/api/audit/ping")
            response.raise_for_status()
            return response.json()


async def get_fabric_client(settings: Settings) -> FabricClient:
    """Dependency to get Fabric client."""
    return FabricClient(settings)


async def get_audit_client(settings: Settings) -> AuditClient:
    """Dependency to get Audit client."""
    return AuditClient(settings)


