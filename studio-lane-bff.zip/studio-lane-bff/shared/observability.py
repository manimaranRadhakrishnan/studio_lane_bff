"""Observability helpers: OpenTelemetry tracing, structured logging, metrics."""

import logging
import os
import time
from contextvars import ContextVar
from typing import Any

from opentelemetry import trace
from opentelemetry.instrumentation.fastapi import FastAPIInstrumentor
from opentelemetry.instrumentation.logging import LoggingInstrumentor
from opentelemetry.sdk.trace import TracerProvider
from opentelemetry.sdk.trace.export import BatchSpanProcessor, ConsoleSpanExporter

# Optional OpenTelemetry logs SDK (may not be available in all versions)
try:
    from opentelemetry.sdk.logs import LoggerProvider, LoggingHandler
    from opentelemetry.sdk.logs.export import BatchLogRecordProcessor, ConsoleLogExporter
    OTEL_LOGS_AVAILABLE = True
except ImportError:
    OTEL_LOGS_AVAILABLE = False
    # Create dummy classes for type checking
    LoggerProvider = None  # type: ignore
    LoggingHandler = None  # type: ignore
    BatchLogRecordProcessor = None  # type: ignore
    ConsoleLogExporter = None  # type: ignore


try:
    from azure.monitor.opentelemetry.exporter import (
        AzureMonitorLogExporter,
        AzureMonitorTraceExporter,
    )
    AZURE_MONITOR_AVAILABLE = True
except ImportError:
    AZURE_MONITOR_AVAILABLE = False

from shared.context import RequestContext


# Context variable to store request context for logging
request_context_var: ContextVar[RequestContext | None] = ContextVar(
    "request_context", default=None
)


def setup_tracing(
    service_name: str,
    endpoint: str | None = None,
    connection_string: str | None = None,
) -> None:
    """
    Setup OpenTelemetry tracing with Azure Application Insights support.

    Args:
        service_name: Name of the service (e.g., "studio-gateway-api")
        endpoint: OTLP exporter endpoint (e.g., "http://otel-collector:4317")
        connection_string: Azure Application Insights connection string (optional)
    """
    # Get connection string from environment if not provided
    if not connection_string:
        connection_string = os.getenv("APPLICATIONINSIGHTS_CONNECTION_STRING")

    provider = TracerProvider()

    if connection_string and AZURE_MONITOR_AVAILABLE:
        # Use Azure Monitor exporter for traces
        trace_exporter = AzureMonitorTraceExporter(connection_string=connection_string)
        provider.add_span_processor(BatchSpanProcessor(trace_exporter))
    elif endpoint:
        # TODO: Add OTLP exporter when endpoint is configured
        # from opentelemetry.exporter.otlp.proto.grpc.trace_exporter import OTLPSpanExporter  # noqa: ERA001
        # otlp_exporter = OTLPSpanExporter(endpoint=endpoint)  # noqa: ERA001
        # provider.add_span_processor(BatchSpanProcessor(otlp_exporter))  # noqa: ERA001
        pass
    else:
        # Development: use console exporter
        console_exporter = ConsoleSpanExporter()
        provider.add_span_processor(BatchSpanProcessor(console_exporter))

    trace.set_tracer_provider(provider)

    # Setup OpenTelemetry logging (if available)
    if OTEL_LOGS_AVAILABLE and LoggerProvider:
        logger_provider = LoggerProvider()

        if connection_string and AZURE_MONITOR_AVAILABLE:
            # Use Azure Monitor exporter for logs
            log_exporter = AzureMonitorLogExporter(connection_string=connection_string)
            logger_provider.add_log_record_processor(BatchLogRecordProcessor(log_exporter))
        else:
            # Development: use console exporter
            console_log_exporter = ConsoleLogExporter()
            logger_provider.add_log_record_processor(BatchLogRecordProcessor(console_log_exporter))

        # Configure Python logging with OpenTelemetry handler
        root_logger = logging.getLogger()

        # Remove existing OpenTelemetry handlers to avoid duplicates
        root_logger.handlers = [
            h for h in root_logger.handlers
            if not isinstance(h, LoggingHandler)
        ]

        # Add OpenTelemetry logging handler
        otel_handler = LoggingHandler(logger_provider=logger_provider)
        root_logger.addHandler(otel_handler)

        # Enable OpenTelemetry logging instrumentation
        # This automatically captures Python logging module logs
        LoggingInstrumentor().instrument()

    # Set service name for OpenTelemetry
    os.environ.setdefault("OTEL_SERVICE_NAME", service_name)


def get_tracer(service_name: str) -> trace.Tracer:
    """Get OpenTelemetry tracer for a service."""
    return trace.get_tracer(service_name)


def instrument_fastapi_app(app: Any) -> None:
    """
    Instrument FastAPI app with OpenTelemetry.

    Automatically creates spans for all HTTP requests.
    """
    FastAPIInstrumentor.instrument_app(app)


def add_span_attributes(ctx: RequestContext) -> None:
    """
    Add request context attributes to current span.

    Adds tenantId, userId, sessionId, correlationId as span attributes.
    """
    current_span = trace.get_current_span()
    if current_span:
        current_span.set_attribute("tenant_id", ctx.tenant_id)
        current_span.set_attribute("user_id", ctx.user_id)
        if ctx.session_id:
            current_span.set_attribute("session_id", ctx.session_id)
        if ctx.correlation_id:
            current_span.set_attribute("correlation_id", ctx.correlation_id)
        current_span.set_attribute("roles", ",".join(ctx.roles))


class StructuredLogger:
    """Structured logger with request context."""

    def __init__(self, name: str):
        self.logger = logging.getLogger(name)

    def _log(
        self,
        level: int,
        message: str,
        extra_fields: dict[str, Any] | None = None,
    ) -> None:
        """Log with structured fields."""
        ctx = request_context_var.get()

        extra = extra_fields or {}
        if ctx:
            extra.update({
                "tenant_id": ctx.tenant_id,
                "user_id": ctx.user_id,
                "correlation_id": ctx.correlation_id,
                "session_id": ctx.session_id,
            })

        self.logger.log(level, message, extra=extra)

    def debug(self, message: str, **kwargs: Any) -> None:
        """Log debug message."""
        self._log(logging.DEBUG, message, kwargs)

    def info(self, message: str, **kwargs: Any) -> None:
        """Log info message."""
        self._log(logging.INFO, message, kwargs)

    def warning(self, message: str, **kwargs: Any) -> None:
        """Log warning message."""
        self._log(logging.WARNING, message, kwargs)

    def error(self, message: str, **kwargs: Any) -> None:
        """Log error message."""
        self._log(logging.ERROR, message, kwargs)

    def exception(self, message: str, **kwargs: Any) -> None:
        """Log exception with traceback."""
        ctx = request_context_var.get()
        extra = kwargs or {}
        if ctx:
            extra.update({
                "tenant_id": ctx.tenant_id,
                "user_id": ctx.user_id,
                "correlation_id": ctx.correlation_id,
            })
        self.logger.exception(message, extra=extra)


def get_logger(name: str) -> StructuredLogger:
    """Get structured logger for a module."""
    return StructuredLogger(name)


def setup_logging(log_level: str = "INFO") -> None:
    """
    Setup structured JSON logging.

    Args:
        log_level: Log level (DEBUG, INFO, WARNING, ERROR)
    """
    logging.basicConfig(
        level=getattr(logging, log_level.upper()),
        format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    )

    # TODO: Add JSON formatter for production
    # from pythonjsonlogger import jsonlogger  # noqa: ERA001
    # formatter = jsonlogger.JsonFormatter()  # noqa: ERA001


class LatencyTracker:
    """Track and log latency for downstream calls with OpenTelemetry spans."""

    def __init__(self, service: str, operation: str):
        self.service = service
        self.operation = operation
        self.start_time: float | None = None
        self.logger = get_logger(f"latency.{service}")
        self.tracer = trace.get_tracer(__name__)
        self.span: trace.Span | None = None

    def __enter__(self) -> "LatencyTracker":
        """Start tracking with OpenTelemetry span."""
        self.start_time = time.time()
        # Create span for downstream call
        self.span = self.tracer.start_span(f"{self.service}.{self.operation}")
        self.span.set_attribute("service", self.service)
        self.span.set_attribute("operation", self.operation)
        return self

    def __exit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> None:
        """Stop tracking and log latency."""
        if self.start_time:
            duration_ms = (time.time() - self.start_time) * 1000

            # Update span
            if self.span:
                self.span.set_attribute("duration_ms", duration_ms)
                if exc_type is None:
                    self.span.set_status(trace.Status(trace.StatusCode.OK))
                else:
                    self.span.set_status(
                        trace.Status(trace.StatusCode.ERROR, str(exc_val))
                    )
                    self.span.record_exception(exc_val)
                self.span.end()

            # Log latency
            self.logger.info(
                f"{self.service}.{self.operation}",
                duration_ms=duration_ms,
                service=self.service,
                operation=self.operation,
                success=exc_type is None,
            )

            # Record metrics
            from shared.metrics import get_metrics
            metrics = get_metrics()
            metrics.record_downstream_latency(self.service, self.operation, duration_ms)


