"""Health check utilities for liveness, readiness, and startup probes."""

from typing import Any

from shared.config import Settings, get_settings
from shared.cosmosdb import get_cosmosdb_client


class HealthChecker:
    """Health check utilities for Kubernetes probes."""

    def __init__(self, settings: Settings):
        """Initialize health checker."""
        self.settings = settings

    async def check_liveness(self) -> dict[str, Any]:
        """
        Liveness probe - checks if application is running.

        Returns:
            Health status dict
        """
        return {
            "status": "healthy",
            "service": "studio-gateway-api",
            "probe": "liveness",
        }

    async def check_readiness(self) -> dict[str, Any]:
        """
        Readiness probe - checks if application is ready to serve traffic.

        Checks:
        - Database connectivity
        - Downstream service availability (optional)

        Returns:
            Health status dict with component statuses
        """
        components = {
            "database": await self._check_database(),
        }

        # Check if all critical components are healthy
        all_healthy = all(
            status["status"] == "healthy" for status in components.values()
        )

        return {
            "status": "healthy" if all_healthy else "unhealthy",
            "service": "studio-gateway-api",
            "probe": "readiness",
            "components": components,
        }

    async def check_startup(self) -> dict[str, Any]:
        """
        Startup probe - checks if application has finished initializing.

        Similar to readiness but used during startup phase.

        Returns:
            Health status dict
        """
        return await self.check_readiness()

    async def _check_database(self) -> dict[str, Any]:
        """
        Check Cosmos DB connectivity.

        Returns:
            Component status dict
        """
        try:
            cosmos_client = get_cosmosdb_client()
            is_healthy = await cosmos_client.health_check()

            if is_healthy:
                return {
                    "status": "healthy",
                    "message": "Cosmos DB connection successful",
                }
            return {
                "status": "unhealthy",
                "message": "Cosmos DB health check failed",
            }
        except RuntimeError:
            return {
                "status": "unhealthy",
                "message": "Cosmos DB not initialized",
            }
        except Exception as e:
            return {
                "status": "unhealthy",
                "message": f"Cosmos DB connection failed: {e!s}",
            }

    async def _check_downstream_service(
        self, service_name: str, base_url: str
    ) -> dict[str, Any]:
        """
        Check downstream service availability.

        Args:
            service_name: Name of the service
            base_url: Base URL of the service

        Returns:
            Component status dict
        """
        try:
            import httpx

            async with httpx.AsyncClient(timeout=5.0) as client:
                response = await client.get(f"{base_url}/health")
                if response.status_code == 200:
                    return {
                        "status": "healthy",
                        "message": f"{service_name} is available",
                    }
                return {
                    "status": "unhealthy",
                    "message": f"{service_name} returned {response.status_code}",
                }
        except Exception as e:
            return {
                "status": "unhealthy",
                "message": f"{service_name} check failed: {e!s}",
            }


def get_health_checker() -> HealthChecker:
    """Get health checker instance."""
    settings = get_settings()
    return HealthChecker(settings)


