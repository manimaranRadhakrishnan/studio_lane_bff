"""Base repository pattern for data access with Cosmos DB and tenant isolation."""

from typing import Any, Generic, TypeVar

from pydantic import BaseModel

from shared.context import RequestContext
from shared.cosmosdb import CosmosDBClient
from shared.document_models import (
    from_cosmos_document,
    get_container_for_type,
    get_tenant_id_from_document,
    to_cosmos_document,
)
from shared.pagination import PaginatedResponse, PaginationParams


# Type variables for repository pattern
DomainType = TypeVar("DomainType", bound=BaseModel)


class BaseRepository(Generic[DomainType]):
    """
    Base repository with common CRUD operations and tenant isolation using Cosmos DB.

    Provides:
    - Automatic tenant filtering via partition key
    - CRUD operations (create, get, list, update, delete)
    - Pagination support
    - Document type management
    """

    def __init__(
        self,
        cosmos_client: CosmosDBClient,
        ctx: RequestContext,
        domain_model: type[DomainType],
        doc_type: str,
    ):
        """
        Initialize repository.

        Args:
            cosmos_client: Cosmos DB client instance
            ctx: Request context (for tenant isolation)
            domain_model: Pydantic domain model class
            doc_type: Document type (e.g., "workspace", "project")
        """
        self.cosmos_client = cosmos_client
        self.ctx = ctx
        self.domain_model = domain_model
        self.doc_type = doc_type
        self.container_name = get_container_for_type(doc_type)

    def _to_domain(self, doc: dict[str, Any]) -> DomainType:
        """
        Convert Cosmos DB document to domain model.

        Args:
            doc: Cosmos DB document

        Returns:
            Domain model instance
        """
        return from_cosmos_document(doc, self.domain_model)

    def _to_document(self, instance: DomainType, tenant_id: str) -> dict[str, Any]:
        """
        Convert domain model to Cosmos DB document.

        Args:
            instance: Domain model instance
            tenant_id: Tenant ID for partition key

        Returns:
            Cosmos DB document
        """
        return to_cosmos_document(instance, self.doc_type, tenant_id)

    async def create(self, instance: DomainType) -> DomainType:
        """
        Create a new entity.

        Args:
            instance: Domain model instance to create

        Returns:
            Created domain entity
        """
        # Determine partition key for special cases
        from shared.constants import PLATFORM_TENANT_ID

        if self.doc_type == "platform_config":
            tenant_id = PLATFORM_TENANT_ID
        elif self.doc_type == "platform_limit":
            # Use tenant_id from instance, or PLATFORM_TENANT_ID for platform defaults
            instance_dict = instance.model_dump() if hasattr(instance, "model_dump") else dict(instance)
            tenant_id = instance_dict.get("tenant_id") or PLATFORM_TENANT_ID
        else:
            tenant_id = self.ctx.tenant_id

        doc = self._to_document(instance, tenant_id)

        created_doc = await self.cosmos_client.create_item(
            item=doc,
            container_name=self.container_name,
        )

        return self._to_domain(created_doc)

    async def get(self, id: str, partition_key: str | None = None) -> DomainType | None:
        """
        Get entity by ID with tenant isolation.

        Args:
            id: Entity ID
            partition_key: Optional partition key override (for special cases like PlatformConfig)

        Returns:
            Domain entity or None if not found
        """
        # Determine partition key
        from shared.constants import PLATFORM_TENANT_ID

        if partition_key is not None:
            pk = partition_key
        elif self.doc_type == "platform_config":
            pk = PLATFORM_TENANT_ID
        else:
            pk = self.ctx.tenant_id

        doc = await self.cosmos_client.read_item(
            item_id=id,
            partition_key=pk,
            container_name=self.container_name,
        )

        if not doc:
            return None

        # Verify tenant isolation (skip for platform_config and platform_limit with platform partition)
        if self.doc_type not in ("platform_config", "platform_limit"):
            doc_tenant_id = get_tenant_id_from_document(doc)
            if doc_tenant_id != self.ctx.tenant_id:
                return None

        return self._to_domain(doc)

    async def list(
        self,
        pagination: PaginationParams | None = None,
        filters: dict[str, Any] | None = None,
        order_by: str | None = None,
    ) -> PaginatedResponse[DomainType] | list[DomainType]:
        """
        List entities with optional pagination, filtering, and ordering.

        Args:
            pagination: Pagination parameters
            filters: Filter dictionary (field: value)
            order_by: Field to order by (e.g., "created_at DESC")

        Returns:
            PaginatedResponse if pagination provided, else list of entities
        """
        
        # Determine partition key for special cases
        from shared.constants import PLATFORM_TENANT_ID
        print("hhhhhhhhhhhhhhhhhhhhh")
        if self.doc_type == "platform_config":
            tenant_id = PLATFORM_TENANT_ID
        elif self.doc_type == "platform_limit":
            # For platform limits, use tenant_id from context or PLATFORM_TENANT_ID for defaults
            tenant_id = self.ctx.tenant_id
        else:
            tenant_id = self.ctx.tenant_id

        # Build query
        query_parts = [
            "SELECT * FROM c",
            "WHERE c.type = @doc_type"
        ]
        parameters = [
            {"name": "@doc_type", "value": self.doc_type},
            {"name": "@tenant_id", "value": tenant_id},
        ]
        print(parameters,"cccccccccccccccccccccccccccc")
        # Add filters
        if filters:
            for idx, (field, value) in enumerate(filters.items()):
                param_name = f"@filter_{idx}"
                query_parts.append(f"AND c.{field} = {param_name}")
                parameters.append({"name": param_name, "value": value})

        # Add ordering
        if order_by:
            # Parse order_by (format: "field ASC" or "field DESC")
            order_field = order_by.split()[0] if order_by else "createdAt"
            order_direction = "DESC" if "DESC" in order_by.upper() else "ASC"
            query_parts.append(f"ORDER BY c.{order_field} {order_direction}")
        else:
            query_parts.append("ORDER BY c.createdAt DESC")

        # Execute query
        query = " ".join(query_parts)
        items = await self.cosmos_client.query_items(
            query=query,
            container_name=self.container_name,
            parameters=parameters,
            partition_key=tenant_id,
        )

        # Convert to domain models
        entities = [self._to_domain(item) for item in items]

        print(entities,"hhhhhhhhhhhhhhhhhhhhhhhhh")

        # Handle pagination
        if pagination:
            # Cosmos DB doesn't support efficient OFFSET, so we'll do it in memory
            # For better performance, use continuation tokens (future enhancement)
            total_count = len(entities)
            offset = pagination.offset or 0
            limit = pagination.limit or 50

            paginated_items = entities[offset:offset + limit]

            # Calculate page from offset
            page = (offset // limit) + 1 if limit > 0 else 1

            return PaginatedResponse.create(
                items=paginated_items,
                total=total_count,
                page=page,
                page_size=limit,
            )

        return entities

    async def update(self, id: str, **kwargs) -> DomainType | None:
        """
        Update entity by ID.

        Args:
            id: Entity ID
            **kwargs: Fields to update

        Returns:
            Updated domain entity or None if not found
        """
        # Get existing entity (with proper partition key)
        from shared.constants import PLATFORM_TENANT_ID

        partition_key = None
        if self.doc_type == "platform_config":
            partition_key = PLATFORM_TENANT_ID
        existing = await self.get(id, partition_key=partition_key)
        if not existing:
            return None

        # Update fields
        updated_dict = existing.model_dump() if hasattr(existing, "model_dump") else dict(existing)

        updated_dict.update(kwargs)

        # Create updated instance
        updated_instance = self.domain_model(**updated_dict)

        # Determine partition key for special cases
        from shared.constants import PLATFORM_TENANT_ID

        if self.doc_type == "platform_config":
            tenant_id = PLATFORM_TENANT_ID
        elif self.doc_type == "platform_limit":
            instance_dict = updated_instance.model_dump() if hasattr(updated_instance, "model_dump") else dict(updated_instance)
            tenant_id = instance_dict.get("tenant_id") or PLATFORM_TENANT_ID
        else:
            tenant_id = self.ctx.tenant_id

        updated_doc = self._to_document(updated_instance, tenant_id)

        # Determine partition key for reading existing doc
        from shared.constants import PLATFORM_TENANT_ID

        read_partition_key = tenant_id
        if self.doc_type == "platform_config":
            read_partition_key = PLATFORM_TENANT_ID

        # Read existing to preserve metadata
        existing_doc = await self.cosmos_client.read_item(
            item_id=id,
            partition_key=read_partition_key,
            container_name=self.container_name,
        )

        if existing_doc:
            # Preserve Cosmos DB metadata
            updated_doc["_rid"] = existing_doc.get("_rid")
            updated_doc["_self"] = existing_doc.get("_self")
            updated_doc["_etag"] = existing_doc.get("_etag")
            updated_doc["_ts"] = existing_doc.get("_ts")

        # Upsert updated document
        upserted_doc = await self.cosmos_client.upsert_item(
            item=updated_doc,
            container_name=self.container_name,
        )

        return self._to_domain(upserted_doc)

    async def delete(self, id: str) -> bool:
        """
        Delete entity by ID.

        Args:
            id: Entity ID

        Returns:
            True if deleted, False if not found
        """
        tenant_id = self.ctx.tenant_id

        try:
            await self.cosmos_client.delete_item(
                item_id=id,
                partition_key=tenant_id,
                container_name=self.container_name,
            )
            return True
        except Exception:
            return False

    async def exists(self, id: str) -> bool:
        """
        Check if entity exists.

        Args:
            id: Entity ID

        Returns:
            True if exists, False otherwise
        """
        entity = await self.get(id)
        return entity is not None

    async def count(
        self,
        filters: dict[str, Any] | None = None,
    ) -> int:
        """
        Count entities matching filters.

        Args:
            filters: Filter dictionary (field: value)

        Returns:
            Count of matching entities
        """
        tenant_id = self.ctx.tenant_id

        # Build query
        query_parts = [
            "SELECT VALUE COUNT(1) FROM c",
            "WHERE c.type = @doc_type",
            "AND c.partitionKey = @tenant_id",
        ]
        parameters = [
            {"name": "@doc_type", "value": self.doc_type},
            {"name": "@tenant_id", "value": tenant_id},
        ]

        # Add filters
        if filters:
            for idx, (field, value) in enumerate(filters.items()):
                param_name = f"@filter_{idx}"
                query_parts.append(f"AND c.{field} = {param_name}")
                parameters.append({"name": param_name, "value": value})

        query = " ".join(query_parts)
        results = await self.cosmos_client.query_items(
            query=query,
            container_name=self.container_name,
            parameters=parameters,
            partition_key=tenant_id,
        )

        # COUNT query returns a single value
        return results[0] if results else 0

