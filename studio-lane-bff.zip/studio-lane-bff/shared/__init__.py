"""Shared infrastructure for Studio BFF."""

from shared.auth import get_optional_request_context, get_request_context
from shared.config import Settings, get_settings
from shared.context import RequestContext
from shared.cosmosdb import CosmosDBClient, get_cosmosdb, get_cosmosdb_client, init_cosmosdb
from shared.errors import (
    AppError,
    AuthError,
    DownstreamError,
    NotFoundError,
    PermissionError,
    ValidationError,
    global_exception_handler,
    to_error_response,
)
from shared.rbac import can_edit, is_editor, is_owner, require_all_roles, require_role


__all__ = [
    # Config
    "Settings",
    "get_settings",
    # Context
    "RequestContext",
    "get_request_context",
    "get_optional_request_context",
    # Cosmos DB
    "get_cosmosdb",
    "get_cosmosdb_client",
    "init_cosmosdb",
    "CosmosDBClient",
    # Errors
    "AppError",
    "AuthError",
    "PermissionError",
    "NotFoundError",
    "ValidationError",
    "DownstreamError",
    "to_error_response",
    "global_exception_handler",
    # RBAC
    "require_role",
    "require_all_roles",
    "is_owner",
    "is_editor",
    "can_edit",
]


