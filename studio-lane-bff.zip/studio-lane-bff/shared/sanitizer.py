"""PII (Personally Identifiable Information) sanitization for logs."""

import re
from typing import Any


# Patterns for common PII
EMAIL_PATTERN = re.compile(r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b')
PHONE_PATTERN = re.compile(r'\b\d{3}[-.]?\d{3}[-.]?\d{4}\b')
SSN_PATTERN = re.compile(r'\b\d{3}-\d{2}-\d{4}\b')
CREDIT_CARD_PATTERN = re.compile(r'\b\d{4}[- ]?\d{4}[- ]?\d{4}[- ]?\d{4}\b')
JWT_PATTERN = re.compile(r'\beyJ[A-Za-z0-9_-]+\.eyJ[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\b')

# Fields that commonly contain sensitive data
SENSITIVE_FIELDS = {
    'password', 'passwd', 'pwd', 'secret', 'token', 'api_key', 'apikey',
    'access_token', 'refresh_token', 'authorization', 'auth',
    'credit_card', 'card_number', 'cvv', 'ssn', 'social_security',
    'email', 'phone', 'phone_number', 'mobile', 'address',
}


def sanitize_string(value: str) -> str:
    """
    Sanitize a string value by redacting PII.

    Args:
        value: String to sanitize

    Returns:
        Sanitized string with PII redacted
    """
    if not isinstance(value, str):
        return value

    result = value

    # Replace emails
    result = EMAIL_PATTERN.sub('[EMAIL_REDACTED]', result)

    # Replace phone numbers
    result = PHONE_PATTERN.sub('[PHONE_REDACTED]', result)

    # Replace SSN
    result = SSN_PATTERN.sub('[SSN_REDACTED]', result)

    # Replace credit cards
    result = CREDIT_CARD_PATTERN.sub('[CARD_REDACTED]', result)

    # Replace JWT tokens
    return JWT_PATTERN.sub('[JWT_REDACTED]', result)



def sanitize_dict(data: dict[str, Any], max_depth: int = 10) -> dict[str, Any]:
    """
    Recursively sanitize a dictionary, redacting sensitive fields and PII.

    Args:
        data: Dictionary to sanitize
        max_depth: Maximum recursion depth to prevent infinite loops

    Returns:
        Sanitized dictionary
    """
    if max_depth <= 0:
        return {'[MAX_DEPTH_REACHED]': True}

    sanitized = {}
    for key, value in data.items():
        key_lower = key.lower()

        # Check if field name suggests sensitive data
        if any(sensitive in key_lower for sensitive in SENSITIVE_FIELDS):
            sanitized[key] = '[REDACTED]'
        elif isinstance(value, str):
            sanitized[key] = sanitize_string(value)
        elif isinstance(value, dict):
            sanitized[key] = sanitize_dict(value, max_depth - 1)
        elif isinstance(value, list):
            sanitized[key] = [
                sanitize_dict(item, max_depth - 1) if isinstance(item, dict)
                else sanitize_string(item) if isinstance(item, str)
                else item
                for item in value
            ]
        else:
            sanitized[key] = value

    return sanitized


def sanitize_for_logging(data: Any) -> Any:
    """
    Sanitize data for logging, handling various types.

    Args:
        data: Data to sanitize (dict, list, str, or other)

    Returns:
        Sanitized data
    """
    if isinstance(data, dict):
        return sanitize_dict(data)
    if isinstance(data, list):
        return [
            sanitize_dict(item, max_depth=10) if isinstance(item, dict)
            else sanitize_string(item) if isinstance(item, str)
            else item
            for item in data
        ]
    if isinstance(data, str):
        return sanitize_string(data)
    return data


