"""Shared constants for platform-level identifiers."""

# Platform-level identifier for global/platform objects
# Used as partition key and tenant_id for platform-wide configurations
PLATFORM_TENANT_ID = "platform"

# Platform config document ID (single document)
PLATFORM_CONFIG_ID = "platform"




