"""Blob storage client for project assets (images, title images, etc.)."""

import uuid
from pathlib import Path
from typing import Any

from azure.storage.blob.aio import BlobServiceClient
from azure.core.exceptions import AzureError

from shared.config import Settings
#from shared.logging import get_logger

#logger = get_logger(__name__)


class BlobStorageClient:
    """
    Azure Blob Storage client for project assets.

    Container: project-assets
    Path pattern: {tenant_id}/projects/{project_id}/images/{image_id}.{ext}
    """

    def __init__(self, settings: Settings):
        """Initialize blob storage client."""
        self.connection_string = settings.azure_storage_connection_string
        self.container_name = "project-assets"
        self._client: BlobServiceClient | None = None

    async def _ensure_client(self) -> BlobServiceClient:
        """Ensure blob service client is initialized."""
        if self._client is None:
            if not self.connection_string:
                raise ValueError("Azure Storage connection string not configured")
            self._client = BlobServiceClient.from_connection_string(self.connection_string)
        return self._client

    async def _ensure_container(self) -> None:
        """Ensure container exists."""
        client = await self._ensure_client()
        try:
            container_client = client.get_container_client(self.container_name)
            # await container_client.create_container(exist_ok=True)
        except AzureError as e:
            #logger.error(f"Failed to ensure container exists: {e}", exc_info=True)
            raise

    async def upload_image(
        self,
        tenant_id: str,
        project_id: str,
        image_data: bytes,
        content_type: str,
        file_extension: str | None = None,
    ) -> dict[str, Any]:
        """
        Upload image to blob storage.

        Args:
            tenant_id: Tenant ID
            project_id: Project ID
            image_data: Image file bytes
            content_type: MIME type (e.g., "image/png")
            file_extension: File extension (e.g., "png"). If None, inferred from content_type.

        Returns:
            dict with image_id, blob_uri, image_url, content_type, size
        """
        await self._ensure_container()
        client = await self._ensure_client()

        # Generate image ID
        image_id = str(uuid.uuid4())

        # Determine file extension
        if not file_extension:
            # Infer from content_type
            ext_map = {
                "image/png": "png",
                "image/jpeg": "jpg",
                "image/jpg": "jpg",
                "image/gif": "gif",
                "image/webp": "webp",
            }
            file_extension = ext_map.get(content_type, "bin")

        # Build blob path
        blob_path = f"{tenant_id}/projects/{project_id}/images/{image_id}.{file_extension}"

        # Upload to blob
        blob_client = client.get_blob_client(container=self.container_name, blob=blob_path)
        await blob_client.upload_blob(
            data=image_data,
            content_type=content_type,
            overwrite=True,
        )

        # Get blob URI
        blob_uri = blob_client.url

        # logger.info(
        #     "Uploaded image to blob storage",
        #     extra={
        #         "tenant_id": tenant_id,
        #         "project_id": project_id,
        #         "image_id": image_id,
        #         "blob_path": blob_path,
        #         "size": len(image_data),
        #     },
        # )

        return {
            "image_id": image_id,
            "blob_uri": blob_uri,
            "image_url": blob_uri,  # Same as blob_uri for UI to use
            "content_type": content_type,
            "size": len(image_data),
        }

    async def get_image_uri(self, tenant_id: str, project_id: str, image_id: str) -> str | None:
        """
        Get image blob URI.

        Args:
            tenant_id: Tenant ID
            project_id: Project ID
            image_id: Image ID

        Returns:
            Blob URI or None if not found
        """
        client = await self._ensure_client()

        # Try common extensions
        extensions = ["png", "jpg", "jpeg", "gif", "webp"]
        for ext in extensions:
            blob_path = f"{tenant_id}/projects/{project_id}/images/{image_id}.{ext}"
            blob_client = client.get_blob_client(container=self.container_name, blob=blob_path)
            try:
                if await blob_client.exists():
                    return blob_client.url
            except AzureError:
                continue

        return None

    async def delete_image(self, tenant_id: str, project_id: str, image_id: str) -> bool:
        """
        Delete image from blob storage.

        Args:
            tenant_id: Tenant ID
            project_id: Project ID
            image_id: Image ID

        Returns:
            True if deleted, False if not found
        """
        client = await self._ensure_client()

        # Try common extensions
        extensions = ["png", "jpg", "jpeg", "gif", "webp"]
        for ext in extensions:
            blob_path = f"{tenant_id}/projects/{project_id}/images/{image_id}.{ext}"
            blob_client = client.get_blob_client(container=self.container_name, blob=blob_path)
            try:
                if await blob_client.exists():
                    await blob_client.delete_blob()
                    # logger.info(
                    #     "Deleted image from blob storage",
                    #     extra={
                    #         "tenant_id": tenant_id,
                    #         "project_id": project_id,
                    #         "image_id": image_id,
                    #         "blob_path": blob_path,
                    #     },
                    # )
                    return True
            except AzureError as e:
                #logger.warning(f"Failed to delete image {image_id}: {e}")
                continue

        return False

    async def close(self) -> None:
        """Close blob service client."""
        if self._client:
            await self._client.close()
            self._client = None


