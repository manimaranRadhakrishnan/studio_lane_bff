"""Standardized error codes catalog for consistent error responses."""

from enum import Enum


class ErrorCode(str, Enum):
    """Standardized error codes for API responses."""

    # Authentication & Authorization (1xxx)
    AUTH_ERROR = "AUTH_ERROR"
    AUTH_TOKEN_MISSING = "AUTH_TOKEN_MISSING"
    AUTH_TOKEN_INVALID = "AUTH_TOKEN_INVALID"
    AUTH_TOKEN_EXPIRED = "AUTH_TOKEN_EXPIRED"
    PERMISSION_DENIED = "PERMISSION_DENIED"
    INSUFFICIENT_ROLES = "INSUFFICIENT_ROLES"

    # Validation Errors (2xxx)
    VALIDATION_ERROR = "VALIDATION_ERROR"
    INVALID_JSON = "INVALID_JSON"
    MISSING_REQUIRED_FIELD = "MISSING_REQUIRED_FIELD"
    INVALID_FIELD_VALUE = "INVALID_FIELD_VALUE"
    REQUEST_TOO_LARGE = "REQUEST_TOO_LARGE"

    # Resource Errors (3xxx)
    NOT_FOUND = "NOT_FOUND"
    RESOURCE_NOT_FOUND = "RESOURCE_NOT_FOUND"
    ALREADY_EXISTS = "ALREADY_EXISTS"
    CONFLICT = "CONFLICT"

    # Rate Limiting (4xxx)
    RATE_LIMIT_EXCEEDED = "RATE_LIMIT_EXCEEDED"
    POLICY_LIMIT_EXCEEDED = "POLICY_LIMIT_EXCEEDED"

    # Downstream Service Errors (5xxx)
    DOWNSTREAM_ERROR = "DOWNSTREAM_ERROR"
    GEN_DOWNSTREAM_ERROR = "GEN_DOWNSTREAM_ERROR"
    DELIVERY_DOWNSTREAM_ERROR = "DELIVERY_DOWNSTREAM_ERROR"
    FABRIC_DOWNSTREAM_ERROR = "FABRIC_DOWNSTREAM_ERROR"
    AUDIT_DOWNSTREAM_ERROR = "AUDIT_DOWNSTREAM_ERROR"
    CIRCUIT_BREAKER_OPEN = "CIRCUIT_BREAKER_OPEN"

    # Database Errors (6xxx)
    DATABASE_ERROR = "DATABASE_ERROR"
    DATABASE_CONNECTION_ERROR = "DATABASE_CONNECTION_ERROR"
    DATABASE_QUERY_ERROR = "DATABASE_QUERY_ERROR"
    DATABASE_TRANSACTION_ERROR = "DATABASE_TRANSACTION_ERROR"

    # Internal Errors (9xxx)
    INTERNAL_ERROR = "INTERNAL_ERROR"
    UNEXPECTED_ERROR = "UNEXPECTED_ERROR"
    SERVICE_UNAVAILABLE = "SERVICE_UNAVAILABLE"


# User-friendly error messages
ERROR_MESSAGES: dict[ErrorCode, str] = {
    ErrorCode.AUTH_ERROR: "Authentication failed",
    ErrorCode.AUTH_TOKEN_MISSING: "Authorization token is required",
    ErrorCode.AUTH_TOKEN_INVALID: "Invalid authorization token",
    ErrorCode.AUTH_TOKEN_EXPIRED: "Authorization token has expired",
    ErrorCode.PERMISSION_DENIED: "You do not have permission to perform this action",
    ErrorCode.INSUFFICIENT_ROLES: "Insufficient roles to perform this action",
    ErrorCode.VALIDATION_ERROR: "Request validation failed",
    ErrorCode.INVALID_JSON: "Invalid JSON in request body",
    ErrorCode.MISSING_REQUIRED_FIELD: "Required field is missing",
    ErrorCode.INVALID_FIELD_VALUE: "Invalid value for field",
    ErrorCode.REQUEST_TOO_LARGE: "Request body exceeds maximum size",
    ErrorCode.NOT_FOUND: "Resource not found",
    ErrorCode.RESOURCE_NOT_FOUND: "The requested resource does not exist",
    ErrorCode.ALREADY_EXISTS: "Resource already exists",
    ErrorCode.CONFLICT: "Resource conflict",
    ErrorCode.RATE_LIMIT_EXCEEDED: "Rate limit exceeded. Please try again later.",
    ErrorCode.POLICY_LIMIT_EXCEEDED: "File exceeds maximum allowed size",
    ErrorCode.DOWNSTREAM_ERROR: "Downstream service error",
    ErrorCode.GEN_DOWNSTREAM_ERROR: "Gen service is temporarily unavailable",
    ErrorCode.DELIVERY_DOWNSTREAM_ERROR: "Delivery service is temporarily unavailable",
    ErrorCode.FABRIC_DOWNSTREAM_ERROR: "Fabric service is temporarily unavailable",
    ErrorCode.AUDIT_DOWNSTREAM_ERROR: "Audit service is temporarily unavailable",
    ErrorCode.CIRCUIT_BREAKER_OPEN: "Service is temporarily unavailable due to high error rate",
    ErrorCode.DATABASE_ERROR: "Database error occurred",
    ErrorCode.DATABASE_CONNECTION_ERROR: "Unable to connect to database",
    ErrorCode.DATABASE_QUERY_ERROR: "Database query failed",
    ErrorCode.DATABASE_TRANSACTION_ERROR: "Database transaction failed",
    ErrorCode.INTERNAL_ERROR: "An internal error occurred",
    ErrorCode.UNEXPECTED_ERROR: "An unexpected error occurred",
    ErrorCode.SERVICE_UNAVAILABLE: "Service is temporarily unavailable",
}


def get_error_message(error_code: ErrorCode | str) -> str:
    """
    Get user-friendly error message for error code.

    Args:
        error_code: Error code enum or string

    Returns:
        User-friendly error message
    """
    if isinstance(error_code, str):
        try:
            error_code = ErrorCode(error_code)
        except ValueError:
            return "An error occurred"

    return ERROR_MESSAGES.get(error_code, "An error occurred")


def get_support_contact() -> dict[str, str]:
    """
    Get support contact information for critical errors.

    Returns:
        Dictionary with support contact details
    """
    return {
        "support_email": "support@temenos.com",
        "support_url": "https://support.temenos.com",
        "documentation": "https://docs.temenos.com/studio",
    }


