"""Cosmos DB document models and conversion helpers."""

from datetime import datetime, timezone
from typing import Any

from shared.models import (
    ChatMessage,
    ChatSession,
    DesignSystem,
    Favorite,
    File,
    Folder,
    GitConnection,
    JobProjection,
    LifecycleTimeline,
    PlatformConfig,
    PlatformLimit,
    Project,
    ProjectPromptSelection,
    ProjectRepoBinding,
    ProjectShare,
    PromptLibraryItem,
    StudioSession,
    Task,
    TenantConfig,
    Theme,
    UserProfile,
    UserRoleAssignment,
    WorkingCopyMetadata,
    Workspace,
)


# Container mapping for document types
DOCUMENT_TYPE_TO_CONTAINER = {
    "user_profile": "users",
    "user_role_assignment": "users",
    "workspace": "workspaces",
    "folder": "workspaces",
    "project": "projects",
    "favorite": "projects",
    "project_share": "projects",
    "design_system": "design_systems",
    "theme": "themes",
    "context_item": "contexts",
    "project_context_selection": "projects",
    "studio_session": "sessions",
    "chat_session": "conversations",
    "chat_message": "conversations",
    "task": "tasks",
    "file": "files",
    "working_copy_metadata": "wcMetadata",
    "job_projection": "jobProjections",
    "lifecycle_timeline": "lifecycleTimelines",
    "git_connection": "gitConnections",
    "project_repo_binding": "projectRepoBindings",
    "platform_config": "platform_config",
    "tenant_config": "tenant_config",
    "platform_limit": "platform_limits",
    "fabric_connection": "fabricConnections",
}


def to_cosmos_document(
    model_instance: Any,
    doc_type: str,
    tenant_id: str,
    ttl: int = -1,
) -> dict[str, Any]:
    """
    Convert a Pydantic domain model to a Cosmos DB document.

    Args:
        model_instance: Domain model instance
        doc_type: Document type (e.g., "workspace", "project")
        tenant_id: Tenant ID for partition key (or special values like "global", None for platform defaults)
        ttl: Time to live in seconds (-1 means never expire)

    Returns:
        Cosmos DB document dictionary
    """
    # Convert model to dict
    if hasattr(model_instance, "model_dump"):
        doc = model_instance.model_dump()
    elif hasattr(model_instance, "dict"):
        doc = model_instance.dict()
    else:
        doc = dict(model_instance)

    # Ensure id exists
    if "id" not in doc:
        raise ValueError(f"Model {doc_type} must have an 'id' field")

    # Special partition key handling
    from shared.constants import PLATFORM_TENANT_ID

    partition_key = tenant_id
    if doc_type == "platform_config":
        # PlatformConfig uses PLATFORM_TENANT_ID as partition key (single document)
        partition_key = PLATFORM_TENANT_ID
    elif doc_type == "platform_limit":
        # PlatformLimit: None tenant_id = platform default (use PLATFORM_TENANT_ID)
        if doc.get("tenant_id") is None:
            partition_key = PLATFORM_TENANT_ID
        else:
            partition_key = doc.get("tenant_id") or tenant_id

    # Add Cosmos DB required fields
    doc["type"] = doc_type
    doc["partitionKey"] = partition_key

    # Convert datetime to ISO8601 strings
    for key, value in doc.items():
        if isinstance(value, datetime):
            doc[key] = value.isoformat()

    # Add TTL
    doc["ttl"] = ttl

    return doc


def from_cosmos_document(
    doc: dict[str, Any],
    model_class: type,
) -> Any:
    """
    Convert a Cosmos DB document to a Pydantic domain model.

    Args:
        doc: Cosmos DB document dictionary
        model_class: Pydantic model class to convert to

    Returns:
        Domain model instance
    """
    # Create a copy to avoid mutating the original
    model_dict = doc.copy()

    # Remove Cosmos DB specific fields
    model_dict.pop("type", None)
    model_dict.pop("partitionKey", None)
    model_dict.pop("_rid", None)
    model_dict.pop("_self", None)
    model_dict.pop("_etag", None)
    model_dict.pop("_attachments", None)
    model_dict.pop("_ts", None)
    model_dict.pop("ttl", None)

    # Convert ISO8601 strings back to datetime
    for key, value in model_dict.items():
        if isinstance(value, str):
            # Try to parse as ISO8601 datetime
            try:
                # Handle both with and without timezone
                if "T" in value and ("+" in value or value.endswith("Z")):
                    model_dict[key] = datetime.fromisoformat(value.replace("Z", "+00:00"))
                elif "T" in value:
                    model_dict[key] = datetime.fromisoformat(value)
            except (ValueError, AttributeError):
                pass  # Not a datetime string, keep as is

    return model_class(**model_dict)


def get_container_for_type(doc_type: str) -> str:
    """Get container name for a document type."""
    return DOCUMENT_TYPE_TO_CONTAINER.get(doc_type, "default")


def get_tenant_id_from_document(doc: dict[str, Any]) -> str:
    """Extract tenant ID from document (from partitionKey or tenantId field)."""
    return doc.get("partitionKey") or doc.get("tenantId") or doc.get("tenant_id")


# Helper functions for each model type

def workspace_to_document(workspace: Workspace, tenant_id: str) -> dict[str, Any]:
    """Convert Workspace to Cosmos DB document."""
    return to_cosmos_document(workspace, "workspace", tenant_id)


def workspace_from_document(doc: dict[str, Any]) -> Workspace:
    """Convert Cosmos DB document to Workspace."""
    return from_cosmos_document(doc, Workspace)


def folder_to_document(folder: Folder, tenant_id: str) -> dict[str, Any]:
    """Convert Folder to Cosmos DB document."""
    return to_cosmos_document(folder, "folder", tenant_id)


def folder_from_document(doc: dict[str, Any]) -> Folder:
    """Convert Cosmos DB document to Folder."""
    return from_cosmos_document(doc, Folder)


def project_to_document(project: Project, tenant_id: str) -> dict[str, Any]:
    """Convert Project to Cosmos DB document."""
    return to_cosmos_document(project, "project", tenant_id)


def project_from_document(doc: dict[str, Any]) -> Project:
    """Convert Cosmos DB document to Project."""
    return from_cosmos_document(doc, Project)


def favorite_to_document(favorite: Favorite, tenant_id: str) -> dict[str, Any]:
    """Convert Favorite to Cosmos DB document."""
    return to_cosmos_document(favorite, "favorite", tenant_id)


def favorite_from_document(doc: dict[str, Any]) -> Favorite:
    """Convert Cosmos DB document to Favorite."""
    return from_cosmos_document(doc, Favorite)


def project_share_to_document(share: ProjectShare, tenant_id: str) -> dict[str, Any]:
    """Convert ProjectShare to Cosmos DB document."""
    return to_cosmos_document(share, "project_share", tenant_id)


def project_share_from_document(doc: dict[str, Any]) -> ProjectShare:
    """Convert Cosmos DB document to ProjectShare."""
    return from_cosmos_document(doc, ProjectShare)


def user_profile_to_document(profile: UserProfile, tenant_id: str) -> dict[str, Any]:
    """Convert UserProfile to Cosmos DB document."""
    return to_cosmos_document(profile, "user_profile", tenant_id)


def user_profile_from_document(doc: dict[str, Any]) -> UserProfile:
    """Convert Cosmos DB document to UserProfile."""
    return from_cosmos_document(doc, UserProfile)


def user_role_assignment_to_document(
    assignment: UserRoleAssignment,
    tenant_id: str,
) -> dict[str, Any]:
    """Convert UserRoleAssignment to Cosmos DB document."""
    return to_cosmos_document(assignment, "user_role_assignment", tenant_id)


def user_role_assignment_from_document(doc: dict[str, Any]) -> UserRoleAssignment:
    """Convert Cosmos DB document to UserRoleAssignment."""
    return from_cosmos_document(doc, UserRoleAssignment)


def design_system_to_document(design_system: DesignSystem, tenant_id: str) -> dict[str, Any]:
    """Convert DesignSystem to Cosmos DB document."""
    return to_cosmos_document(design_system, "design_system", tenant_id)


def design_system_from_document(doc: dict[str, Any]) -> DesignSystem:
    """Convert Cosmos DB document to DesignSystem."""
    return from_cosmos_document(doc, DesignSystem)


def chat_session_to_document(session: ChatSession, tenant_id: str) -> dict[str, Any]:
    """Convert ChatSession to Cosmos DB document."""
    return to_cosmos_document(session, "chat_session", tenant_id)


def chat_session_from_document(doc: dict[str, Any]) -> ChatSession:
    """Convert Cosmos DB document to ChatSession."""
    return from_cosmos_document(doc, ChatSession)


def chat_message_to_document(message: ChatMessage, tenant_id: str) -> dict[str, Any]:
    """Convert ChatMessage to Cosmos DB document."""
    return to_cosmos_document(message, "chat_message", tenant_id)


def chat_message_from_document(doc: dict[str, Any]) -> ChatMessage:
    """Convert Cosmos DB document to ChatMessage."""
    return from_cosmos_document(doc, ChatMessage)


def task_to_document(task: Task, tenant_id: str) -> dict[str, Any]:
    """Convert Task to Cosmos DB document."""
    return to_cosmos_document(task, "task", tenant_id)


def task_from_document(doc: dict[str, Any]) -> Task:
    """Convert Cosmos DB document to Task."""
    return from_cosmos_document(doc, Task)


def file_to_document(file: File, tenant_id: str) -> dict[str, Any]:
    """Convert File to Cosmos DB document."""
    return to_cosmos_document(file, "file", tenant_id)


def file_from_document(doc: dict[str, Any]) -> File:
    """Convert Cosmos DB document to File."""
    return from_cosmos_document(doc, File)


def working_copy_metadata_to_document(wc_meta: WorkingCopyMetadata, tenant_id: str) -> dict[str, Any]:
    """Convert WorkingCopyMetadata to Cosmos DB document."""
    return to_cosmos_document(wc_meta, "working_copy_metadata", tenant_id)


def working_copy_metadata_from_document(doc: dict[str, Any]) -> WorkingCopyMetadata:
    """Convert Cosmos DB document to WorkingCopyMetadata."""
    return from_cosmos_document(doc, WorkingCopyMetadata)


def job_projection_to_document(projection: JobProjection, tenant_id: str) -> dict[str, Any]:
    """Convert JobProjection to Cosmos DB document."""
    return to_cosmos_document(projection, "job_projection", tenant_id)


def job_projection_from_document(doc: dict[str, Any]) -> JobProjection:
    """Convert Cosmos DB document to JobProjection."""
    return from_cosmos_document(doc, JobProjection)


def lifecycle_timeline_to_document(timeline: LifecycleTimeline, tenant_id: str) -> dict[str, Any]:
    """Convert LifecycleTimeline to Cosmos DB document."""
    return to_cosmos_document(timeline, "lifecycle_timeline", tenant_id)


def lifecycle_timeline_from_document(doc: dict[str, Any]) -> LifecycleTimeline:
    """Convert Cosmos DB document to LifecycleTimeline."""
    return from_cosmos_document(doc, LifecycleTimeline)


def git_connection_to_document(connection: GitConnection, tenant_id: str) -> dict[str, Any]:
    """Convert GitConnection to Cosmos DB document."""
    return to_cosmos_document(connection, "git_connection", tenant_id)


def git_connection_from_document(doc: dict[str, Any]) -> GitConnection:
    """Convert Cosmos DB document to GitConnection."""
    return from_cosmos_document(doc, GitConnection)


def project_repo_binding_to_document(binding: ProjectRepoBinding, tenant_id: str) -> dict[str, Any]:
    """Convert ProjectRepoBinding to Cosmos DB document."""
    return to_cosmos_document(binding, "project_repo_binding", tenant_id)


def project_repo_binding_from_document(doc: dict[str, Any]) -> ProjectRepoBinding:
    """Convert Cosmos DB document to ProjectRepoBinding."""
    return from_cosmos_document(doc, ProjectRepoBinding)


