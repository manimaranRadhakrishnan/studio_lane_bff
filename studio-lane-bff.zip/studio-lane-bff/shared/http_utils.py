"""HTTP client utilities: context managers, circuit breakers, retry logic."""

import asyncio
import time
from collections.abc import Callable
from enum import Enum
from typing import Any

import httpx

from shared.errors import DownstreamError


class CircuitState(str, Enum):
    """Circuit breaker states."""

    CLOSED = "closed"  # Normal operation
    OPEN = "open"  # Failing, reject requests
    HALF_OPEN = "half_open"  # Testing if service recovered


class CircuitBreaker:
    """
    Circuit breaker pattern for downstream service calls.

    Prevents cascading failures by stopping requests to failing services.
    Automatically attempts recovery after timeout period.
    """

    def __init__(
        self,
        failure_threshold: int = 5,
        recovery_timeout: float = 60.0,
        success_threshold: int = 2,
    ):
        """
        Initialize circuit breaker.

        Args:
            failure_threshold: Number of failures before opening circuit
            recovery_timeout: Seconds to wait before attempting recovery
            success_threshold: Successes needed in half-open to close circuit
        """
        self.failure_threshold = failure_threshold
        self.recovery_timeout = recovery_timeout
        self.success_threshold = success_threshold

        self.state = CircuitState.CLOSED
        self.failure_count = 0
        self.success_count = 0
        self.last_failure_time: float | None = None
        self._lock = asyncio.Lock()

    async def call(self, func: Callable, *args, **kwargs) -> Any:
        """
        Execute function call with circuit breaker protection.

        Args:
            func: Async function to call
            *args, **kwargs: Arguments to pass to function

        Returns:
            Result from function call

        Raises:
            DownstreamError: If circuit is open or call fails
        """
        async with self._lock:
            # Check if circuit should transition
            await self._check_state_transition()

            # Reject if circuit is open
            if self.state == CircuitState.OPEN:
                raise DownstreamError(
                    service="circuit_breaker",
                    message="Circuit breaker is OPEN - service unavailable",
                    status_code=503,
                )

        try:
            # Attempt call
            result = await func(*args, **kwargs)

            # Record success
            async with self._lock:
                await self._record_success()

            return result

        except Exception:
            # Record failure
            async with self._lock:
                await self._record_failure()

            # Re-raise original exception
            raise

    async def _check_state_transition(self) -> None:
        """Check and update circuit breaker state."""
        now = time.time()

        if self.state == CircuitState.OPEN:
            # Check if recovery timeout has passed
            if (
                self.last_failure_time
                and (now - self.last_failure_time) >= self.recovery_timeout
            ):
                self.state = CircuitState.HALF_OPEN
                self.success_count = 0

        elif self.state == CircuitState.HALF_OPEN:
            # Already transitioning, no action needed
            pass

    async def _record_success(self) -> None:
        """Record successful call."""
        if self.state == CircuitState.HALF_OPEN:
            self.success_count += 1
            if self.success_count >= self.success_threshold:
                # Circuit recovered
                self.state = CircuitState.CLOSED
                self.failure_count = 0
                self.success_count = 0
        elif self.state == CircuitState.CLOSED:
            # Reset failure count on success
            self.failure_count = 0

    async def _record_failure(self) -> None:
        """Record failed call."""
        self.failure_count += 1
        self.last_failure_time = time.time()

        if self.state == CircuitState.HALF_OPEN:
            # Failed during recovery attempt, open again
            self.state = CircuitState.OPEN
            self.success_count = 0
        elif (
            self.state == CircuitState.CLOSED
            and self.failure_count >= self.failure_threshold
        ):
            # Too many failures, open circuit
            self.state = CircuitState.OPEN


class HttpClientContextManager:
    """
    Async context manager for HTTP clients with automatic resource cleanup.

    Usage:
        async with HttpClientContextManager(settings) as client:
            response = await client.get("/endpoint")
        # Client automatically closed
    """

    def __init__(
        self,
        base_url: str,
        timeout: int = 30,
        max_retries: int = 3,
        circuit_breaker: CircuitBreaker | None = None,
    ):
        """
        Initialize HTTP client context manager.

        Args:
            base_url: Base URL for client
            timeout: Request timeout in seconds
            max_retries: Maximum retry attempts
            circuit_breaker: Optional circuit breaker instance
        """
        self.base_url = base_url
        self.timeout = timeout
        self.max_retries = max_retries
        self.circuit_breaker = circuit_breaker or CircuitBreaker()
        self.client: httpx.AsyncClient | None = None

    async def __aenter__(self) -> httpx.AsyncClient:
        """Enter context, create client."""
        self.client = httpx.AsyncClient(
            base_url=self.base_url,
            timeout=httpx.Timeout(self.timeout),
            limits=httpx.Limits(
                max_keepalive_connections=10,
                max_connections=20,
            ),
        )
        return self.client

    async def __aexit__(self, exc_type, exc_val, exc_tb) -> None:
        """Exit context, close client."""
        if self.client:
            await self.client.aclose()
            self.client = None

    async def request_with_retry(
        self,
        method: str,
        url: str,
        *args,
        **kwargs,
    ) -> httpx.Response:
        """
        Make HTTP request with retry logic and circuit breaker.

        Args:
            method: HTTP method
            url: Request URL
            *args, **kwargs: Additional arguments for httpx request

        Returns:
            HTTP response

        Raises:
            DownstreamError: If request fails after retries
        """
        if not self.client:
            raise RuntimeError("Client not initialized. Use as async context manager.")

        async def _make_request():
            response = await self.client.request(method, url, *args, **kwargs)
            response.raise_for_status()
            return response

        # Use circuit breaker
        last_exception = None
        for attempt in range(self.max_retries + 1):
            try:
                return await self.circuit_breaker.call(_make_request)
            except httpx.HTTPStatusError as e:
                # Don't retry on client errors (4xx)
                if 400 <= e.response.status_code < 500:
                    raise DownstreamError(
                        service="http_client",
                        message=f"Client error: {e.response.text}",
                        status_code=e.response.status_code,
                    ) from e
                last_exception = e
            except httpx.RequestError as e:
                last_exception = e
                if attempt < self.max_retries:
                    # Exponential backoff
                    wait_time = 2**attempt
                    await asyncio.sleep(wait_time)
                else:
                    raise DownstreamError(
                        service="http_client",
                        message=f"Request failed after {self.max_retries} retries: {e!s}",
                    ) from e

        # Should not reach here, but handle just in case
        if last_exception:
            raise DownstreamError(
                service="http_client",
                message=f"Request failed: {last_exception!s}",
            )
        return None


