"""WebSocket connection manager for job progress fan-out.

Maintains genRunId -> Set[WebSocket] mapping. Used by event ingestion
to broadcast job updates to connected clients. Single-instance in-memory;
for multi-instance use Redis Pub/Sub (see COMBINED_CODEGEN §5).
"""

from __future__ import annotations

import asyncio
import json
from collections import defaultdict
from datetime import datetime, timezone
from typing import Any

from starlette.websockets import WebSocket


class ConnectionManager:
    """In-memory WebSocket connection manager keyed by gen_run_id."""

    def __init__(self) -> None:
        self._connections: dict[str, set[WebSocket]] = defaultdict(set)
        self._lock = asyncio.Lock()

    async def connect(
        self,
        websocket: WebSocket,
        gen_run_id: str,
    ) -> None:
        """Accept connection and register for gen_run_id."""
        await websocket.accept()
        async with self._lock:
            self._connections[gen_run_id].add(websocket)

    async def disconnect(
        self,
        websocket: WebSocket,
        gen_run_id: str,
    ) -> None:
        """Remove connection from gen_run_id set."""
        async with self._lock:
            conns = self._connections.get(gen_run_id)
            if conns:
                conns.discard(websocket)
                if not conns:
                    del self._connections[gen_run_id]

    async def broadcast(
        self,
        gen_run_id: str,
        message_type: str,
        payload: dict[str, Any],
    ) -> None:
        """Send JSON message to all clients subscribed to gen_run_id."""
        data = {
            "type": message_type,
            "genRunId": gen_run_id,
            "payload": payload,
            "timestamp": datetime.now(timezone.utc).isoformat() + "Z",
        }
        text = json.dumps(data)
        async with self._lock:
            conns = set(self._connections.get(gen_run_id, []))
        dead: set[WebSocket] = set()
        for ws in conns:
            try:
                await ws.send_text(text)
            except Exception:
                dead.add(ws)
        if dead:
            async with self._lock:
                conns = self._connections.get(gen_run_id)
                if conns:
                    for ws in dead:
                        conns.discard(ws)
                    if not conns:
                        del self._connections[gen_run_id]


_manager: ConnectionManager | None = None


def get_ws_manager() -> ConnectionManager:
    """Return singleton connection manager."""
    global _manager
    if _manager is None:
        _manager = ConnectionManager()
    return _manager

