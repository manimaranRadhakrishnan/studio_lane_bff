"""Authentication and JWT validation."""

import uuid

from cryptography.hazmat.primitives import serialization
from fastapi import Depends, Header
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from jose import JWTError, jwt

from shared.config import Settings, get_settings
from shared.context import RequestContext
from shared.errors import AuthError
from shared.jwt_cache import get_jwks_cache


security = HTTPBearer(auto_error=False)


async def verify_jwt_signature(token: str, settings: Settings) -> dict:
    """
    Verify and decode Keycloak JWT token with full validation.

    Validates:
    - Signature using public key from Keycloak JWKS
    - Issuer matches Keycloak realm issuer
    - Audience matches Keycloak client/audience
    - Token expiration

    Args:
        token: JWT token string
        settings: Application settings

    Returns:
        Decoded token claims

    Raises:
        AuthError: If token is invalid, expired, or signature verification fails
    """
    try:
        # Dev only: skip verification when KEYCLOAK_SKIP_VERIFY=true
        if settings.keycloak_skip_verify and settings.studio_env == "dev":
            return jwt.decode(
                token,
                key="",
                options={"verify_signature": False, "verify_aud": False, "verify_iss": False},
            )

        # Full verification via Keycloak JWKS
        jwks_cache = get_jwks_cache(settings)
        public_key = await jwks_cache.get_public_key(token)

        public_key_pem = public_key.public_key_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PublicFormat.SubjectPublicKeyInfo,
        )

        return jwt.decode(
            token,
            key=public_key_pem,
            algorithms=["RS256"],
            audience=settings.keycloak_audience_resolved,
            issuer=settings.keycloak_issuer_resolved,
            options={"verify_signature": True, "verify_aud": True, "verify_iss": True},
        )

    except JWTError as e:
        raise AuthError(message=f"Invalid JWT token: {e!s}") from e
    except Exception as e:
        raise AuthError(message=f"JWT verification failed: {e!s}") from e


def decode_temenos_jwt(token: str, settings: Settings) -> dict:
    """
    Decode and validate Keycloak JWT token.

    Synchronous wrapper around verify_jwt_signature. Prefer verify_jwt_signature in async code.
    """
    import asyncio

    try:
        loop = asyncio.get_event_loop()
        if loop.is_running():
            if settings.keycloak_skip_verify and settings.studio_env == "dev":
                return jwt.decode(token, key="", options={"verify_signature": False})
            raise AuthError(
                message="JWT verification requires async context. Use verify_jwt_signature in async functions."
            )
        return loop.run_until_complete(verify_jwt_signature(token, settings))
    except RuntimeError:
        return asyncio.run(verify_jwt_signature(token, settings))


def extract_roles_from_claims(claims: dict) -> set[str]:
    """
    Extract roles from Keycloak JWT claims.

    Maps Keycloak realm/client roles to Studio roles (Owner, Editor, Viewer).
    Supports realm_access.roles, resource_access.<client>.roles, and custom "roles" claim.
    """
    roles = set()
    studio_roles = {"Owner", "Editor", "Viewer"}

    def map_name(s: str) -> str | None:
        s = str(s).strip()
        if not s:
            return None
        lower = s.lower()
        if lower == "owner":
            return "Owner"
        if lower == "editor":
            return "Editor"
        if lower == "viewer":
            return "Viewer"
        return None

    # Keycloak realm roles
    realm = claims.get("realm_access") or {}
    for r in realm.get("roles") or []:
        if m := map_name(r):
            roles.add(m)

    # Keycloak resource_access (client roles)
    ra = claims.get("resource_access") or {}
    for _client, data in ra.items():
        if isinstance(data, dict):
            for r in (data.get("roles") or []):
                if m := map_name(r):
                    roles.add(m)

    # Custom "roles" claim
    for r in claims.get("roles") or []:
        if r in studio_roles:
            roles.add(r)
        elif m := map_name(r):
            roles.add(m)

    return roles


async def get_request_context(
    credentials: HTTPAuthorizationCredentials | None = Depends(security),  # noqa: B008
    x_correlation_id: str | None = Header(None),
    x_session_id: str | None = Header(None),
    x_cs_tenant_id: str | None = Header(None, alias="X-CS-Tenant-Id"),
    settings: Settings = Depends(get_settings),  # noqa: B008
) -> RequestContext:
    """
    FastAPI dependency to extract RequestContext from JWT.

    Validates JWT token, extracts tenant_id, user_id, and roles.
    Raises AuthError if token is missing or invalid.
    """
    if not credentials:
        raise AuthError(message="Missing Authorization header")

    token = credentials.credentials
    # Use async verification for proper signature checking
    claims = await verify_jwt_signature(token, settings)

    # Extract standard claims
    user_id = claims.get("sub") or claims.get("oid")
    if not user_id:
        raise AuthError(message="Missing user ID in token claims")

    # Extract tenant ID (from token) and validate against header (tenant scoping)
    tenant_id = claims.get("tenant_id") or claims.get("tid")
    tenant_id = tenant_id[0] if isinstance(tenant_id, list) and tenant_id else tenant_id
    if not tenant_id:
        raise AuthError(message="Missing tenant ID in token claims")

    # Tenant header required when STUDIO_REQUIRE_TENANT_HEADER=true (config-driven).
    if settings.require_tenant_header and not x_cs_tenant_id:
        raise AuthError(message="Missing tenant scope header", details={"header": "X-CS-Tenant-Id"})
    if x_cs_tenant_id and x_cs_tenant_id != tenant_id:
        raise AuthError(message="Tenant scope mismatch", details={"headerTenantId": x_cs_tenant_id})

    # Extract roles
    roles = extract_roles_from_claims(claims)

    # Generate correlation ID if not provided
    correlation_id = x_correlation_id or str(uuid.uuid4())

    return RequestContext(
        tenant_id=tenant_id,
        user_id=user_id,
        roles=roles,
        session_id=x_session_id,
        correlation_id=correlation_id,
    )


async def get_optional_request_context(
    credentials: HTTPAuthorizationCredentials | None = Depends(security),  # noqa: B008
    x_correlation_id: str | None = Header(None),
    x_session_id: str | None = Header(None),
    x_cs_tenant_id: str | None = Header(None, alias="X-CS-Tenant-Id"),
    settings: Settings = Depends(get_settings),  # noqa: B008
) -> RequestContext | None:
    """
    Optional auth dependency - returns None if no credentials provided.

    Useful for endpoints that support both authenticated and anonymous access.
    """
    if not credentials:
        return None

    try:
        return await get_request_context(credentials, x_correlation_id, x_session_id, x_cs_tenant_id, settings)
    except AuthError:
        return None


