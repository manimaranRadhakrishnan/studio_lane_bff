"""Configuration loader with Azure App Configuration and Key Vault support."""

import os

from azure.appconfiguration import AzureAppConfigurationClient
from azure.identity import DefaultAzureCredential
from azure.keyvault.secrets import SecretClient


class ConfigLoader:
    """Loads configuration from Azure App Configuration and Key Vault."""

    def __init__(
        self,
        app_config_connection_string: str | None = None,
        key_vault_url: str | None = None,
    ):
        self.app_config_client: AzureAppConfigurationClient | None = None
        self.key_vault_client: SecretClient | None = None

        # Initialize App Configuration client
        if app_config_connection_string:
            self.app_config_client = AzureAppConfigurationClient.from_connection_string(
                app_config_connection_string
            )
        elif os.getenv("AZURE_APP_CONFIG_ENDPOINT"):
            credential = DefaultAzureCredential()
            endpoint = os.getenv("AZURE_APP_CONFIG_ENDPOINT")
            self.app_config_client = AzureAppConfigurationClient(
                endpoint=endpoint, credential=credential
            )

        # Initialize Key Vault client
        if key_vault_url:
            credential = DefaultAzureCredential()
            self.key_vault_client = SecretClient(vault_url=key_vault_url, credential=credential)
        elif os.getenv("AZURE_KEY_VAULT_URL"):
            credential = DefaultAzureCredential()
            vault_url = os.getenv("AZURE_KEY_VAULT_URL")
            self.key_vault_client = SecretClient(vault_url=vault_url, credential=credential)

    def get_config(self, key: str, default: str | None = None) -> str | None:
        """Get configuration value from App Configuration."""
        if not self.app_config_client:
            return os.getenv(key, default)

        try:
            setting = self.app_config_client.get_configuration_setting(key=key)
            return setting.value if setting else default
        except Exception:
            return os.getenv(key, default)

    def get_secret(self, secret_name: str) -> str | None:
        """Get secret from Key Vault."""
        if not self.key_vault_client:
            return os.getenv(secret_name)

        try:
            secret = self.key_vault_client.get_secret(secret_name)
            return secret.value
        except Exception:
            return os.getenv(secret_name)


