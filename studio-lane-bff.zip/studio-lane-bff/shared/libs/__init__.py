"""Shared libraries for studio backend services."""


