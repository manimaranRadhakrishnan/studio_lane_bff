"""Metrics collection middleware for Prometheus/OpenTelemetry."""

import time
from collections.abc import Callable

from fastapi import Request, Response
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.types import ASGIApp

from shared.metrics import get_metrics


class MetricsMiddleware(BaseHTTPMiddleware):
    """
    Middleware to collect HTTP request metrics.

    Tracks:
    - Request count by endpoint, method, status code
    - Request duration histograms
    - Active requests gauge
    """

    def __init__(self, app: ASGIApp):
        """Initialize metrics middleware."""
        super().__init__(app)
        self.metrics = get_metrics()

    async def dispatch(self, request: Request, call_next: Callable) -> Response:
        """Process request and collect metrics."""
        start_time = time.time()

        # Increment active requests
        self.metrics.increment_active_requests()

        try:
            response = await call_next(request)
            status_code = response.status_code
        except Exception:
            status_code = 500
            raise
        finally:
            # Calculate duration
            duration_ms = (time.time() - start_time) * 1000

            # Decrement active requests
            self.metrics.decrement_active_requests()

            # Record metrics
            self.metrics.record_request(
                method=request.method,
                path=request.url.path,
                status_code=status_code,
                duration_ms=duration_ms,
            )

        return response


