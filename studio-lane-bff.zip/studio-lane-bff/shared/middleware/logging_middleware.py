"""Request/response logging middleware with PII sanitization."""

import time
from collections.abc import Callable

from fastapi import Request, Response
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.types import ASGIApp

from shared.observability import get_logger
from shared.sanitizer import sanitize_for_logging


class LoggingMiddleware(BaseHTTPMiddleware):
    """
    Middleware to log all HTTP requests and responses.

    Automatically sanitizes PII from logs.
    Excludes health check endpoints from detailed logging.
    """

    def __init__(self, app: ASGIApp, exclude_paths: list[str] | None = None):
        """
        Initialize logging middleware.

        Args:
            app: ASGI application
            exclude_paths: Paths to exclude from logging (e.g., health checks)
        """
        super().__init__(app)
        self.logger = get_logger("http.request")
        self.exclude_paths = exclude_paths or ["/health", "/health/live", "/health/ready", "/health/startup"]

    async def dispatch(self, request: Request, call_next: Callable) -> Response:
        """Process request and log details."""
        # Skip logging for excluded paths
        if any(request.url.path.startswith(path) for path in self.exclude_paths):
            return await call_next(request)

        start_time = time.time()

        # Log request
        request_body = None
        if request.method in ["POST", "PUT", "PATCH"]:
            try:
                body = await request.body()
                if body:
                    import json
                    try:
                        request_body = json.loads(body)
                    except json.JSONDecodeError:
                        request_body = body.decode("utf-8", errors="replace")
            except Exception:
                pass  # Ignore body parsing errors

        sanitized_body = sanitize_for_logging(request_body) if request_body else None

        self.logger.info(
            "Incoming request",
            method=request.method,
            path=request.url.path,
            query_params=dict(request.query_params),
            headers={k: v for k, v in request.headers.items() if k.lower() not in ["authorization", "cookie"]},
            body=sanitized_body,
            client_ip=request.client.host if request.client else None,
        )

        # Process request
        try:
            response = await call_next(request)
        except Exception as e:
            duration_ms = (time.time() - start_time) * 1000
            self.logger.error(
                "Request failed",
                method=request.method,
                path=request.url.path,
                duration_ms=duration_ms,
                error=str(e),
                error_type=type(e).__name__,
            )
            raise

        # Log response
        duration_ms = (time.time() - start_time) * 1000

        # Get response body if available
        response_body = None
        if hasattr(response, "body") and response.body:
            try:
                import json
                response_body = json.loads(response.body)
            except (json.JSONDecodeError, AttributeError):
                pass

        sanitized_response_body = sanitize_for_logging(response_body) if response_body else None

        self.logger.info(
            "Request completed",
            method=request.method,
            path=request.url.path,
            status_code=response.status_code,
            duration_ms=duration_ms,
            response_body=sanitized_response_body if response.status_code >= 400 else None,  # Only log errors
        )

        return response


