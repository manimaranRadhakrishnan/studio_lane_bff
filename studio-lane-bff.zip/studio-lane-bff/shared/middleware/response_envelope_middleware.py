"""Response envelope middleware for Studio APIs."""

from __future__ import annotations

import json
import uuid
from collections.abc import Callable
from typing import Any

from fastapi import Request, Response
from opentelemetry import trace
from starlette.middleware.base import BaseHTTPMiddleware


def _get_trace_id() -> str | None:
    """Return current OpenTelemetry trace id (hex) if available."""
    span = trace.get_current_span()
    ctx = span.get_span_context()
    if not ctx or not ctx.is_valid:
        return None
    return format(ctx.trace_id, "032x")


def _build_meta(request: Request) -> dict[str, Any]:
    request_id = request.headers.get("X-Request-Id") or getattr(request.state, "request_id", None) or str(uuid.uuid4())
    correlation_id = request.headers.get("X-Correlation-Id") or request.headers.get("X-Correlation-ID") or getattr(
        request.state, "correlation_id", None
    )
    trace_id = _get_trace_id() or request.headers.get("traceId") or correlation_id
    return {
        "requestId": request_id,
        "correlationId": correlation_id,
        "traceId": trace_id,
    }


def _should_wrap(path: str) -> bool:
    if path.startswith("/health") or path in ("/",):
        return False
    if path.startswith("/docs") or path.startswith("/redoc") or path.startswith("/openapi"):
        return False
    # Only wrap canonical Studio v1 API.
    return path.startswith("/api/v1/studio/")


class ResponseEnvelopeMiddleware(BaseHTTPMiddleware):
    """
    Wrap successful JSON responses in a stable envelope for Studio APIs:
      { "data": <original>, "meta": {...} }
    """

    async def dispatch(self, request: Request, call_next: Callable) -> Response:
        response = await call_next(request)

        if not _should_wrap(request.url.path):
            return response

        # Only wrap JSON responses.
        content_type = response.headers.get("content-type", "")
        if "application/json" not in content_type:
            return response

        # Starlette responses may stream; only wrap if body is available.
        body = getattr(response, "body", None)
        if body is None:
            return response

        try:
            payload = json.loads(body.decode("utf-8") or "null")
        except Exception:
            return response

        # If this already looks enveloped, do not double-wrap.
        if isinstance(payload, dict) and ("data" in payload or "error" in payload) and "meta" in payload:
            return response

        # Errors are handled by exception handler; do not wrap non-2xx here.
        if response.status_code >= 400:
            return response

        enveloped = {"data": payload, "meta": _build_meta(request)}
        response.body = json.dumps(enveloped).encode("utf-8")
        response.headers["content-length"] = str(len(response.body))
        return response



