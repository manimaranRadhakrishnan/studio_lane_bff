"""Distributed tracing middleware for OpenTelemetry."""

from collections.abc import Callable

from fastapi import Request, Response
from opentelemetry import trace
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.types import ASGIApp

from shared.context import RequestContext
from shared.observability import add_span_attributes


class TracingMiddleware(BaseHTTPMiddleware):
    """
    Middleware to automatically create and enrich OpenTelemetry spans.

    Creates spans for each request and automatically adds:
    - Request context (tenant_id, user_id, correlation_id)
    - HTTP method and path
    - Status code
    """

    def __init__(self, app: ASGIApp):
        """Initialize tracing middleware."""
        super().__init__(app)
        self.tracer = trace.get_tracer(__name__)

    async def dispatch(self, request: Request, call_next: Callable) -> Response:
        """Process request with tracing."""
        # Create span for request
        with self.tracer.start_as_current_span(
            f"{request.method} {request.url.path}"
        ) as span:
            # Add basic request attributes
            span.set_attribute("http.method", request.method)
            span.set_attribute("http.path", request.url.path)
            span.set_attribute("http.url", str(request.url))
            span.set_attribute("http.scheme", request.url.scheme)

            # Try to get request context if available
            ctx = getattr(request.state, "request_context", None)
            if ctx and isinstance(ctx, RequestContext):
                add_span_attributes(ctx)

            try:
                response = await call_next(request)
                span.set_attribute("http.status_code", response.status_code)
                span.set_status(trace.Status(trace.StatusCode.OK))
                return response
            except Exception as e:
                span.set_status(
                    trace.Status(trace.StatusCode.ERROR, str(e))
                )
                span.record_exception(e)
                raise


