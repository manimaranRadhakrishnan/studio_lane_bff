"""Gen Lane HTTP client for generative AI operations."""

from typing import Any

import httpx

from shared.config import Settings
from shared.context import RequestContext
from shared.errors import DownstreamError
from shared.http_utils import HttpClientContextManager
from shared.observability import LatencyTracker


class GenClient:
    """
    HTTP client for Gen Lane Public APIs.

    Handles prompt-to-code, inline edits, chat, and UI builder operations.
    Never calls LLMs directly - delegates to Gen Lane services.

    Can be used as async context manager:
        async with GenClient(settings) as client:
            result = await client.prompt_to_code(...)

    Or manually managed:
        client = GenClient(settings)
        try:
            result = await client.prompt_to_code(...)
        finally:
            await client.close()
    """

    def __init__(self, settings: Settings):
        self.base_url = settings.gen_base_url
        self.timeout = settings.http_timeout
        self.max_retries = settings.http_max_retries
        self.settings = settings
        self.client: httpx.AsyncClient | None = None
        self._context_manager: HttpClientContextManager | None = None

    async def __aenter__(self) -> "GenClient":
        """Enter async context manager."""
        self._context_manager = HttpClientContextManager(
            base_url=self.base_url,
            timeout=self.timeout,
            max_retries=self.max_retries,
        )
        self.client = await self._context_manager.__aenter__()
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb) -> None:
        """Exit async context manager."""
        if self._context_manager:
            await self._context_manager.__aexit__(exc_type, exc_val, exc_tb)
            self.client = None
            self._context_manager = None

    def _ensure_client(self) -> httpx.AsyncClient:
        """Ensure client is initialized."""
        if self.client is None:
            # Fallback to manual initialization for backward compatibility
            self.client = httpx.AsyncClient(
                base_url=self.base_url,
                timeout=httpx.Timeout(self.timeout),
            )
        return self.client

    async def close(self) -> None:
        """Close HTTP client (for manual management)."""
        if self.client:
            await self.client.aclose()
            self.client = None

    async def prompt_to_code(
        self,
        ctx: RequestContext,
        prompt_text: str,
        project_id: str,
        session_id: str,
        images: list[str] | None = None,
        selected_fabric_api_ids: list[str] | None = None,
        selected_component_id: str | None = None,
        design_system_ref: dict[str, str] | None = None,
        wc_ref: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """
        Generate code from natural language prompt using intentBundle contract.

        Calls Gen Public API for prompt-to-code generation with rich input support.
        """
        client = self._ensure_client()
        with LatencyTracker("gen", "prompt_to_code"):
            try:
                # Determine interactionMode based on input
                if selected_component_id:
                    interaction_mode = "visual-edit"
                elif images:
                    interaction_mode = "image"
                elif selected_fabric_api_ids:
                    interaction_mode = "api-bind"
                else:
                    interaction_mode = "prompt"

                # Build intentBundle per ms-apis.adr.md
                intent_bundle = {
                    "interactionMode": interaction_mode,
                    "executionMode": "llm",  # Default execution mode
                    "promptText": prompt_text,
                    "images": [{"uri": img} for img in (images or [])],  # ImageRef: {uri: string}
                    "selectedFabricAPIs": selected_fabric_api_ids or [],
                    "targetComponentId": selected_component_id,
                }

                # Add designSystemRef (REQUIRED per contract)
                if design_system_ref:
                    intent_bundle["designSystemRef"] = design_system_ref
                else:
                    # Default design system ref (TODO: fetch from project)
                    intent_bundle["designSystemRef"] = {"version": "1.0.0", "uri": None}

                # Build payload per ms-apis.adr.md
                payload = {
                    "tenantId": ctx.tenant_id,
                    "projectId": project_id,
                    "sessionId": session_id,
                    "intentBundle": intent_bundle,
                    "wcRef": wc_ref or {"wcVersionStamp": "unknown", "branch": "main", "blobBaseUri": None},
                    "locks": {},
                    "authContext": {"userId": ctx.user_id, "roles": list(ctx.roles), "locale": None, "region": None},
                }
                response = await client.post(
                    "/v1/gen/runs",
                    json=payload,
                    headers={"X-Correlation-Id": ctx.correlation_id or "", "X-CS-Tenant-Id": ctx.tenant_id},
                )
                response.raise_for_status()
                return response.json()
            except httpx.HTTPStatusError as e:
                raise DownstreamError(
                    service="gen",
                    message=f"Gen API error: {e.response.text}",
                    status_code=e.response.status_code,
                ) from e
            except httpx.RequestError as e:
                raise DownstreamError(
                    service="gen",
                    message=f"Failed to connect to Gen API: {e!s}",
                ) from e

    async def plan(self, ctx: RequestContext, payload: dict[str, Any]) -> dict[str, Any]:
        client = self._ensure_client()
        with LatencyTracker("gen", "plan"):
            response = await client.post(
                "/plan",
                json=payload,
                headers={"X-Correlation-Id": ctx.correlation_id or "", "X-CS-Tenant-Id": ctx.tenant_id},
            )
            response.raise_for_status()
            return response.json()

    async def start_run(self, ctx: RequestContext, payload: dict[str, Any]) -> dict[str, Any]:
        client = self._ensure_client()
        with LatencyTracker("gen", "start_run"):
            response = await client.post(
                "/v1/gen/runs",
                json=payload,
                headers={"X-Correlation-Id": ctx.correlation_id or "", "X-CS-Tenant-Id": ctx.tenant_id},
            )
            response.raise_for_status()
            return response.json()

    async def get_run(self, ctx: RequestContext, gen_run_id: str, tenant_id: str) -> dict[str, Any]:
        client = self._ensure_client()
        with LatencyTracker("gen", "get_run"):
            response = await client.get(
                f"/v1/gen/runs/{gen_run_id}",
                params={"tenantId": tenant_id},
                headers={"X-Correlation-Id": ctx.correlation_id or "", "X-CS-Tenant-Id": ctx.tenant_id},
            )
            response.raise_for_status()
            return response.json()

    async def get_tasks(self, ctx: RequestContext, gen_run_id: str, tenant_id: str) -> dict[str, Any]:
        client = self._ensure_client()
        with LatencyTracker("gen", "get_tasks"):
            response = await client.get(
                f"/v1/gen/runs/{gen_run_id}/tasks",
                params={"tenantId": tenant_id},
                headers={"X-Correlation-Id": ctx.correlation_id or "", "X-CS-Tenant-Id": ctx.tenant_id},
            )
            response.raise_for_status()
            return response.json()

    async def get_patches(self, ctx: RequestContext, gen_run_id: str, tenant_id: str) -> dict[str, Any]:
        client = self._ensure_client()
        with LatencyTracker("gen", "get_patches"):
            response = await client.get(
                f"/v1/gen/runs/{gen_run_id}/patches",
                params={"tenantId": tenant_id},
                headers={"X-Correlation-Id": ctx.correlation_id or "", "X-CS-Tenant-Id": ctx.tenant_id},
            )
            response.raise_for_status()
            return response.json()

    async def cancel_run(self, ctx: RequestContext, gen_run_id: str, tenant_id: str) -> dict[str, Any]:
        client = self._ensure_client()
        with LatencyTracker("gen", "cancel_run"):
            response = await client.post(
                f"/v1/gen/runs/{gen_run_id}:cancel",
                params={"tenantId": tenant_id},
                headers={"X-Correlation-Id": ctx.correlation_id or "", "X-CS-Tenant-Id": ctx.tenant_id},
            )
            response.raise_for_status()
            return response.json()

    async def inline_edit(
        self,
        _ctx: RequestContext,
        _file_path: str,
        _edit_instruction: str,
        project_id: str,
    ) -> dict[str, Any]:
        """
        Apply inline edit to existing code.

        TODO: Implement actual API call to Gen Lane.
        """
        with LatencyTracker("gen", "inline_edit"):
            # STUB: Return mock response
            return {
                "task_id": f"task-edit-{project_id}",
                "status": "processing",
                "message": "Inline edit started",
            }

    async def chat(
        self,
        ctx: RequestContext,
        message: str,
        session_id: str,
        project_id: str,
        images: list[str] | None = None,
        selected_fabric_api_ids: list[str] | None = None,
        selected_component_id: str | None = None,
        design_system_ref: dict[str, str] | None = None,
    ) -> dict[str, Any]:
        """
        Context-aware chat about project using intentBundle contract.

        Calls Gen Public API for chat with rich input support.
        """
        client = self._ensure_client()
        with LatencyTracker("gen", "chat"):
            try:
                # Determine interactionMode based on input
                if selected_component_id:
                    interaction_mode = "visual-edit"
                elif images:
                    interaction_mode = "image"
                elif selected_fabric_api_ids:
                    interaction_mode = "api-bind"
                else:
                    interaction_mode = "prompt"

                # Build intentBundle per ms-apis.adr.md
                intent_bundle = {
                    "interactionMode": interaction_mode,
                    "executionMode": "llm",
                    "promptText": message,
                    "images": [{"uri": img} for img in (images or [])],
                    "selectedFabricAPIs": selected_fabric_api_ids or [],
                    "targetComponentId": selected_component_id,
                }

                # Add designSystemRef (REQUIRED per contract)
                if design_system_ref:
                    intent_bundle["designSystemRef"] = design_system_ref
                else:
                    # Default design system ref (TODO: fetch from project)
                    intent_bundle["designSystemRef"] = {"version": "1.0.0", "uri": None}

                # Build payload per ms-apis.adr.md
                payload = {
                    "tenantId": ctx.tenant_id,
                    "projectId": project_id,
                    "sessionId": session_id,
                    "intentBundle": intent_bundle,
                    "wcRef": {"wcVersionStamp": "unknown", "branch": "main", "blobBaseUri": None},
                    "locks": {},
                    "authContext": {"userId": ctx.user_id, "roles": list(ctx.roles), "locale": None, "region": None},
                }
                response = await client.post(
                    "/v1/gen/runs",
                    json=payload,
                    headers={"X-Correlation-Id": ctx.correlation_id or "", "X-CS-Tenant-Id": ctx.tenant_id},
                )
                response.raise_for_status()
                return response.json()
            except httpx.HTTPStatusError as e:
                raise DownstreamError(
                    service="gen",
                    message=f"Gen API error: {e.response.text}",
                    status_code=e.response.status_code,
                ) from e
            except httpx.RequestError as e:
                raise DownstreamError(
                    service="gen",
                    message=f"Failed to connect to Gen API: {e!s}",
                ) from e

    async def apply_theme_delta(
        self,
        tenant_id: str,
        project_id: str,
        wc_ref: dict[str, Any],
        token_delta: dict[str, Any],
        correlation_id: str | None = None,
    ) -> dict[str, Any]:
        """Apply validated theme token delta to design-system in WC. Delegates to GenAI."""
        client = self._ensure_client()
        with LatencyTracker("gen", "apply_theme_delta"):
            response = await client.post(
                "/v1/theme/apply",
                json={
                    "tenantId": tenant_id,
                    "projectId": project_id,
                    "wcRef": wc_ref,
                    "tokenDelta": token_delta,
                },
                headers={
                    "X-Correlation-Id": correlation_id or "",
                    "X-CS-Tenant-Id": tenant_id,
                },
            )
            response.raise_for_status()
            return response.json()

    async def ui_builder(
        self,
        _ctx: RequestContext,
        _ui_prompt: str,
        project_id: str,
        _design_system_id: str | None = None,
    ) -> dict[str, Any]:
        """
        Generate UI components from prompt.

        TODO: Implement actual API call to Gen Lane.
        """
        with LatencyTracker("gen", "ui_builder"):
            # STUB: Return mock response
            return {
                "task_id": f"task-ui-{project_id}",
                "status": "processing",
                "message": "UI generation started",
            }


async def get_gen_client(settings: Settings) -> GenClient:
    """Dependency to get Gen client."""
    return GenClient(settings)


