"""Request context with tenant, user, and role information."""

from dataclasses import dataclass, field


@dataclass
class RequestContext:
    """
    Request context extracted from authenticated JWT.

    Carries tenant, user, roles, and session information through the request lifecycle.
    """

    tenant_id: str
    user_id: str
    roles: set[str] = field(default_factory=set)
    session_id: str | None = None
    correlation_id: str | None = None

    def has_role(self, *required_roles: str) -> bool:
        """Check if user has any of the required roles."""
        return bool(self.roles.intersection(required_roles))

    def has_all_roles(self, *required_roles: str) -> bool:
        """Check if user has all of the required roles."""
        return set(required_roles).issubset(self.roles)


